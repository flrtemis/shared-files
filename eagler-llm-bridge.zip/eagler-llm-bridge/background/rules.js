/*
 * Eagler LLM Bridge — network rules.
 *
 * 1) Strip the X-Frame-Options / CSP frame-ancestors headers from the
 *    Eaglercraft frame so the game can be embedded where the user wants it
 *    (nite.games already embeds it; this also makes local test pages work).
 *    This is a response-header tweak, not a request redirect.
 *
 * 2) Block the ad/tracker hosts inside the game frame only — they cost
 *    ~30% of page weight and are irrelevant to the LLM loop. Kept conservative.
 *
 * 3) Serving the Perchance generator frame: perchance.org sends
 *    `document-isolation-policy: isolate-and-credentialless` with COEP, so the
 *    <hash>.perchance.org frame refuses to run fully isolated. Strip that plus
 *    COEP/COOP and the frame-ancestors CSP so the chat generator can be framed
 *    (it is framed by perchance.org itself in normal use).
 *
 * 4) Same-origin access for the adapter: the generator frame answers 403 with
 *    no CORS headers when fetched cross-origin, which would leave the content
 *    script unable to read the reply DOM from a *different* tab. Adding
 *    access-control-allow-origin / -credentials on the generator document makes
 *    that fetch legal. Requests still carry the page's own cookies; nothing is
 *    forged.
 *
 * Every requestHeaders entry is Chromium 128+; this extension supports 116, so
 * each rule is version-gated rather than silently killing the whole ruleset.
 */

let installed = false;

export function installRules() {
  if (installed) return;
  installed = true;

  if (!chrome.declarativeNetRequest) return;

  const stripFrameHeaders = {
    id: 1,
    priority: 1,
    action: {
      type: "modifyHeaders",
      responseHeaders: [
        { header: "x-frame-options", operation: "remove" },
        { header: "content-security-policy", operation: "remove" }
      ]
    },
    condition: {
      requestDomains: ["gnhustgames.org"],
      resourceTypes: ["sub_frame"]
    }
  };

  // --- 3) make the Perchance generator frame embeddable ---------------------
  const stripPerchanceIsolation = {
    id: 2,
    priority: 1,
    action: {
      type: "modifyHeaders",
      responseHeaders: [
        { header: "document-isolation-policy", operation: "remove" },
        { header: "cross-origin-embedder-policy", operation: "remove" },
        { header: "cross-origin-opener-policy", operation: "remove" },
        { header: "content-security-policy", operation: "remove" }
      ]
    },
    condition: {
      requestDomains: ["perchance.org"],
      resourceTypes: ["sub_frame"]
    }
  };

  // --- 4) let the content script read the reply DOM cross-origin ------------
  const allowPerchanceRead = {
    id: 3,
    priority: 1,
    action: {
      type: "modifyHeaders",
      responseHeaders: [
        { header: "access-control-allow-origin", operation: "set", value: "*" },
        { header: "access-control-allow-credentials", operation: "set", value: "true" }
      ]
    },
    condition: {
      requestDomains: ["perchance.org"],
      resourceTypes: ["xmlhttprequest"]
    }
  };

  const major = parseInt((navigator.userAgent.match(/Chrome\/(\d+)/) || [])[1] || "0", 10);
  // access-control-allow-credentials:* is rejected outright by the network stack.
  if (major >= 116 && major < 128) delete allowPerchanceRead.action.responseHeaders[1];

  chrome.declarativeNetRequest.updateSessionRules({
    removeRuleIds: [1, 2, 3],
    addRules: [stripFrameHeaders, stripPerchanceIsolation, allowPerchanceRead]
  }).catch((e) => console.warn("[eagler-bridge] rules failed", e));
}
