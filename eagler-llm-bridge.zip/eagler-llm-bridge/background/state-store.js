/*
 * Eagler LLM Bridge — authoritative game state.
 *
 * Fed by page events (chat, HUD, position, handshake...) and canvas frames.
 * Provides the state the LLM reads back: recent chat, vitals, position, agent
 * status. Kept in memory; the service worker flushes a compact copy to
 * chrome.storage.local every few seconds so the popup and the bridge host can
 * show it even after a worker restart.
 */

const MAX_CHAT = 300;
const MAX_EVENTS = 200;
const MAX_FRAMES = 2;

export class StateStore {
  constructor() {
    this.chat = [];          // { seq, text, kind, from, at }
    this.events = [];        // protocol events of interest
    this.frames = [];        // { at, dataUrl, width, height, hash }
    this.lastFrame = null;
    this.transcripts = [];   // voice chat transcripts
    this.hud = { health: null, food: null, xp: null, header: null, footer: null };
    this.pos = null;
    this.score = {};
    this.server = null;
    this.username = null;
    this.connected = false;
    this.handshakeDone = false;
    this.serverBrand = null;
    this.serverVersion = null;
    this.clientBrand = null;
    this.eagProtocol = null;
    this.uuid = null;
    // ---- Perchance LLM (the "brain" side) ----
    this.llm = { ready: false, generating: false, assistantName: null, rows: 0, url: null, at: null };
    this.llmReplies = [];      // completed assistant messages, newest last
    this.llmSeq = 0;
    this.agents = new Map(); // frameKey -> { url, hasParser, at }
    this.chatSeq = 0;
    this.eventSeq = 0;
    this.capture = { supported: true, lastAt: null, fps: 0 };
    this.frameCount = 0;
    this.frameHashes = [];   // [{at, hash}] — lets the LLM detect visual change

    this.frameWindow = [];
    this.pendingCmds = new Map();
  }

  // ---------------------------------------------------------------------------
  // Agents
  // ---------------------------------------------------------------------------
  markAgent(evt) {
    if (!evt || !evt.frameKey) return;
    this.agents.set(evt.frameKey, { url: evt.url, hasParser: evt.hasParser, at: Date.now(), tab: evt.tab });
  }

  dropAgent(frameKey) {
    this.agents.delete(frameKey);
  }

  listAgents() {
    return Array.from(this.agents.entries()).map(([k, v]) => ({ frameKey: k, ...v }));
  }

  pending(id) {
    return this.pendingCmds.get(id);
  }

  setPending(id, cb) {
    this.pendingCmds.set(id, cb);
  }

  resolvePending(id, ok, result) {
    const cb = this.pendingCmds.get(id);
    if (!cb) return false;
    this.pendingCmds.delete(id);
    cb(ok, result);
    return true;
  }

  // ---------------------------------------------------------------------------
  // Frames
  // ---------------------------------------------------------------------------
  applyFrame(frame) {
    if (!frame || !frame.frame) return;
    const f = frame.frame;
    if (!f.ok || !f.dataUrl) return;
    const now = Date.now();
    this.frameCount++;
    this.frameWindow.push(now);
    while (this.frameWindow.length && now - this.frameWindow[0] > 5000) this.frameWindow.shift();
    this.capture.fps = +(this.frameWindow.length / 5).toFixed(2);
    this.capture.lastAt = now;
    const entry = { at: now, dataUrl: f.dataUrl, width: f.width, height: f.height, hash: f.hash || null };
    this.frames.push(entry);
    while (this.frames.length > MAX_FRAMES) this.frames.shift();
    this.lastFrame = entry;
    this.frameHashes.push({ at: now, hash: entry.hash });
    while (this.frameHashes.length > 40) this.frameHashes.shift();
  }

  // ---------------------------------------------------------------------------
  // Page events
  // ---------------------------------------------------------------------------
  applyPageEvent(evt) {
    const type = evt.type;
    const p = evt.payload || {};

    switch (type) {
      case "llm-status": {
        this.llm = {
          ready: !!p.ready, generating: !!p.generating, assistantName: p.assistantName || this.llm.assistantName,
          rows: p.rows || 0, url: p.url || this.llm.url, at: new Date().toISOString()
        };
        this.pushEvent(type, this.llm);
        break;
      }
      case "llm-message": {
        if (!p || !p.text) break;
        if (p.role === "user") { this.pushEvent(type, { id: p.id, role: "user", complete: p.complete }); break; }
        const last = this.llmReplies[this.llmReplies.length - 1];
        if (last && last.id === p.id) {
          last.text = p.text;              // streaming update replaces in place
          last.complete = !!p.complete;
          last.at = p.at || last.at;
        } else {
          this.llmReplies.push({ seq: ++this.llmSeq, id: p.id, from: p.name, text: p.text, complete: !!p.complete, at: p.at || new Date().toISOString() });
          while (this.llmReplies.length > MAX_CHAT) this.llmReplies.shift();
        }
        // Completed replies also land in the shared chat log so one /chat call
        // shows both Minecraft and AI lines, in order.
        if (p.complete) {
          this.chat.push({ seq: ++this.chatSeq, text: p.text, kind: "llm", from: p.name || "AI", at: p.at || new Date().toISOString() });
          while (this.chat.length > MAX_CHAT) this.chat.shift();
        }
        this.pushEvent(type, { id: p.id, role: "assistant", complete: !!p.complete, len: p.text.length });
        break;
      }
      case "state:chat": {
        const c = p.entry || {};
        this.chat.push({ seq: ++this.chatSeq, text: c.text, kind: c.kind, from: c.from, at: c.at || new Date().toISOString() });
        while (this.chat.length > MAX_CHAT) this.chat.shift();
        break;
      }
      case "state:handshake": {
        const d = p.data || {};
        if (p.kind === "server_version") {
          this.serverBrand = d.brand || this.serverBrand;
          this.serverVersion = d.version || this.serverVersion;
          this.eagProtocol = d.eag_protocol != null ? d.eag_protocol : this.eagProtocol;
        }
        if (p.kind === "client_version") this.clientBrand = d.brand || this.clientBrand;
        if (p.kind === "allow_login") { this.username = d.username || this.username; this.uuid = d.uuid || this.uuid; }
        if (p.kind === "login") { this.username = d.username || this.username; this.server = d.server || this.server; }
        if (p.kind === "play_start") { this.handshakeDone = true; this.username = p.username || d.username || this.username; }
        this.pushEvent(type, { kind: p.kind, data: p.kind === "client_version" ? { brand: d.brand, version: d.version, username: d.username } : d });
        break;
      }
      case "state:connect": {
        this.connected = true;
        this.server = p.url || this.server;
        this.handshakeDone = false;
        this.pushEvent(type, { url: p.url });
        break;
      }
      case "state:disconnect": {
        this.connected = false;
        this.handshakeDone = false;
        this.pushEvent(type, p);
        break;
      }
      case "state:hud": {
        if (p.health != null) this.hud.health = p.health;
        if (p.food != null) this.hud.food = p.food;
        if (p.xp_level != null) this.hud.xp = { level: p.xp_level, bar: p.xp_bar };
        if (p.header != null) { this.hud.header = p.header; this.hud.footer = p.footer; }
        break;
      }
      case "state:pos": {
        this.pos = p;
        break;
      }
      case "state:score": {
        if (p.entry) this.score[p.entry] = p.value;
        break;
      }
      case "state:game": {
        if (p.event === "joined" && p.data) { this.hud.gamemode = p.data.gamemode; this.hud.dimension = p.data.dimension; }
        this.pushEvent(type, p);
        break;
      }
      case "state:injected":
      case "state:chat_sent":
      case "mirror:open":
      case "mirror:ready":
      case "mirror:closed":
      case "mirror:error":
      case "state:socket_error":
      case "state:socket_open": {
        this.pushEvent(type, p);
        break;
      }
      case "packet": {
        // High-volume: only keep notable packets for the event log
        if (["join_game", "respawn", "disconnect", "change_game_state", "player_abilities"].includes(p.name)) {
          this.pushEvent(type, { name: p.name, data: p.data });
        }
        break;
      }
      default:
        break;
    }
  }

  pushEvent(type, payload) {
    const e = { seq: ++this.eventSeq, type, at: new Date().toISOString() };
    // Trim bulky fields
    if (payload) {
      for (const k of Object.keys(payload)) {
        const v = payload[k];
        if (typeof v === "string" && v.length > 500) e[k] = v.slice(0, 500) + "…";
        else e[k] = v;
      }
    }
    this.events.push(e);
    while (this.events.length > MAX_EVENTS) this.events.shift();
  }

  pushTranscript(t) {
    this.transcripts.push({ ...t, at: t.at || Date.now() });
    while (this.transcripts.length > 100) this.transcripts.shift();
  }

  // ---------------------------------------------------------------------------
  // Read models
  // ---------------------------------------------------------------------------
  summary({ chatLimit = 50, includeFrame = false } = {}) {
    return {
      connected: this.connected,
      handshakeDone: this.handshakeDone,
      protocol: this.eagProtocol,
      serverBrand: this.serverBrand,
      serverVersion: this.serverVersion,
      server: this.server,
      username: this.username,
      hud: this.hud,
      pos: this.pos,
      score: this.score,
      agents: this.listAgents(),
      capture: { fps: this.capture.fps, lastAt: this.capture.lastAt, screenChanged: this.screenChanged() },
      llm: this.llm,
      llmReplies: this.llmReplies.slice(-20),
      chat: this.chat.slice(-chatLimit),
      transcripts: this.transcripts.slice(-20),
      events: this.events.slice(-20),
      frame: includeFrame && this.lastFrame ? { at: this.lastFrame.at, dataUrl: this.lastFrame.dataUrl, width: this.lastFrame.width, height: this.lastFrame.height, hash: this.lastFrame.hash } : null,
      seq: { chat: this.chatSeq, events: this.eventSeq }
    };
  }

  /** True when the last two distinct frames differ (menus opening, etc.). */
  screenChanged() {
    if (this.frameHashes.length < 2) return null;
    const a = this.frameHashes[this.frameHashes.length - 1];
    const b = this.frameHashes[this.frameHashes.length - 2];
    return a.hash !== b.hash;
  }

  since(chatSeq, eventSeq, { chatLimit = 100 } = {}) {
    return {
      chat: this.chat.filter((c) => c.seq > (chatSeq || 0)).slice(-chatLimit),
      events: this.events.filter((e) => e.seq > (eventSeq || 0)).slice(-50),
      seq: { chat: this.chatSeq, events: this.eventSeq }
    };
  }
}
