/*
 * Eagler LLM Bridge — tab/frame manager.
 *
 * All privileged tab access lives here:
 *  - injects the MAIN-world page agent into every frame of the nite.games tab
 *    (the game frame is gnhustgames.org, a different origin than the top page,
 *    so this is exactly the "circumvent CORS" part of the brief: the extension
 *    is allowed to script both origins thanks to host_permissions);
 *  - routes JSON commands to the game frame and collects their replies;
 *  - keeps per-frame agent bookkeeping.
 */

const GAME_FRAME_HOSTS = ["gnhustgames.org"];

export class TabManager {
  constructor({ onPageEvent, onFrame, onAgentGone }) {
    this.onPageEvent = onPageEvent || (() => {});
    this.onFrame = onFrame || (() => {});
    this.onAgentGone = onAgentGone || (() => {});
    this.injected = new Map();        // tabId -> Set(frameId)
    this.lastInject = new Map();      // tabId -> timestamp
    this.pending = new Map();         // requestId -> {resolve, reject, timer}
    this.seq = 0;
  }

  newRequestId(prefix) {
    return (prefix || "r") + "-" + Date.now().toString(36) + "-" + (++this.seq);
  }

  // -------------------------------------------------------------------------
  // Injection
  // -------------------------------------------------------------------------
  async ensureTopInjected(tabId) {
    try {
      const pong = await this.pingTop(tabId);
      if (pong && pong.ok) return { ok: true, injected: 0, already: true };
    } catch (e) { /* not there yet */ }
    try {
      await chrome.scripting.executeScript({
        target: { tabId },
        files: ["content/content.js"]
      });
      return { ok: true, injected: 1 };
    } catch (e) {
      return { ok: false, error: String(e && e.message || e) };
    }
  }

  async injectIntoFrames(tabId, opts) {
    if (!tabId || tabId < 0) return { ok: false, error: "bad tabId" };
    const now = Date.now();
    const last = this.lastInject.get(tabId) || 0;
    // The self-test asks for a fresh injection so its "frames covered" assertion
    // is real work, not a throttled no-op.
    if (!(opts && opts.force) && now - last < 800) return { ok: true, injected: 0, throttled: true };
    this.lastInject.set(tabId, now);

    // 1) Ask the content script to hand us its token — required so the page
    //    agent accepts the commands we inject.
    let token = null;
    try {
      const res = await chrome.tabs.sendMessage(tabId, { kind: "eagler-bridge-to-page", type: "token" }, { frameId: 0 });
      if (res && res.token) token = res.token;
    } catch (e) { /* content script not ready */ }

    // 2) Inject parser + agent into every frame. chrome.scripting runs in the
    //    extension's isolated world by default; `world: "MAIN"` puts it in the
    //    page's realm, which is where window.WebSocket lives.
    let results = [];
    try {
      // Order matters: the parser must define window.EaglerV18 before the agent
      // loads, otherwise the agent disables sniffing for that document.
      const parserRes = await chrome.scripting.executeScript({
        target: { tabId, allFrames: true },
        files: ["page/v1_8_parser.js"],
        world: "MAIN",
        injectImmediately: true
      });
      const agentRes = await chrome.scripting.executeScript({
        target: { tabId, allFrames: true },
        files: ["page/page-bridge.js"],
        world: "MAIN",
        injectImmediately: true
      });
      results = agentRes || [];
      this.parserFrames = (parserRes || []).length;
    } catch (e) {
      return { ok: false, error: String(e && e.message || e) };
    }

    // 3) Tell each injected agent the token. Frame agents listen on their own
    //    window; we push the token from the MAIN world via a second tiny script
    //    that posts the token to its own window (content script relays it too).
    if (token) {
      try {
        await chrome.scripting.executeScript({
          target: { tabId, allFrames: true },
          world: "MAIN",
          args: [token],
          func: (tok) => {
            // viaExtension: the agent accepts this even when no page content
            // script could reach the frame (foreign or nested origin).
            window.postMessage({ source: "eagler-llm-bridge-content", type: "token", token: tok, viaExtension: true }, "*");
          }
        });
      } catch (e) { /* ignore */ }
    }

    // 4) The content script also knows the token; ask it to relay to frames.
    try {
      await chrome.tabs.sendMessage(tabId, { kind: "eagler-bridge-to-page", type: "relay", payload: { type: "token", payload: { token } } });
    } catch (e) { /* ignore */ }

    return { ok: true, injected: results.length, token: !!token };
  }

  async pingTop(tabId) {
    try {
      return await chrome.tabs.sendMessage(tabId, { kind: "eagler-bridge-to-page", type: "ping" });
    } catch (e) {
      return null;
    }
  }

  noteContentReady(tabId) {
    // Deliberately does NOT clear the throttle: doing so turned every
    // "content-ready" into a fresh injection, which reloaded the agent, threw
    // away the token it had just been given, and left the worker with no agent
    // registry entry. Injection is now driven by the throttle and by explicit
    // force calls.
    this.lastContentReady = this.lastContentReady || new Map();
    if (tabId != null) this.lastContentReady.set(tabId, Date.now());
  }

  // -------------------------------------------------------------------------
  // Command routing
  // -------------------------------------------------------------------------
  /**
   * Send a JSON command to the game frame and wait for its reply.
   * The game frame agent posts back through the content script, which forwards
   * `page-result` to the service worker; `resolvePending` matches ids.
   */
  sendCommand(tabId, command, { timeout = 15000, frameKey = null } = {}) {
    return new Promise((resolve, reject) => {
      const id = this.newRequestId("cmd");
      const timer = setTimeout(() => {
        this.pending.delete(id);
        reject(new Error("command timed out after " + timeout + "ms (is the game frame loaded?)"));
      }, timeout);
      this.pending.set(id, {
        resolve: (ok, result) => { clearTimeout(timer); ok ? resolve({ ok: true, result }) : resolve({ ok: false, result }); },
        reject,
        timer
      });
      const relay = (payload) => chrome.tabs.sendMessage(tabId, {
        kind: "eagler-bridge-to-page",
        type: "relay",
        payload
      });

      // Preferred path: ask the content script to relay to the game frame agent
      relay({ type: "cmd", payload: { id, command }, frameKey }).then(() => {
        // Direct MAIN-world fallback in case the frame never introduced itself
        // to the content script (e.g. injected after load).
        setTimeout(() => {
          if (!this.pending.has(id)) return;
          chrome.scripting.executeScript({
            target: { tabId, allFrames: true },
            world: "MAIN",
            args: [id, command],
            func: (reqId, cmd) => {
              window.postMessage({
                source: "eagler-llm-bridge-content",
                type: "cmd",
                payload: { id: reqId, command: cmd },
              }, "*");
            }
          }).catch(() => {});
        }, 220);
      }).catch((e) => {
        clearTimeout(timer);
        this.pending.delete(id);
        reject(e);
      });
    });
  }

  requestSnapshot(tabId, opts) {
    return this._request(tabId, "snapshot", opts || {});
  }

  requestStatus(tabId) {
    return this._request(tabId, "status", {});
  }

  async _request(tabId, type, payload) {
    const id = this.newRequestId(type);
    return new Promise((resolve) => {
      const timer = setTimeout(() => { this.pending.delete(id); resolve({ ok: false, error: "timeout" }); }, 4000);
      this.pending.set(id, {
        // resolve(ok, rawPayload)
        resolve: (ok, res) => { clearTimeout(timer); resolve(Object.assign({ ok }, res || {})); },
        reject: () => resolve({ ok: false }),
        timer
      });
      chrome.tabs.sendMessage(tabId, {
        kind: "eagler-bridge-to-page",
        type: "relay",
        payload: { type, payload: { id, ...payload } }
      }).catch(() => resolve({ ok: false, error: "no content script" }));
    });
  }

  relayToFrame(tabId, frameKey, type, payload) {
    return chrome.tabs.sendMessage(tabId, {
      kind: "eagler-bridge-to-page",
      type: "relay",
      payload: { type, payload, frameKey }
    });
  }

  /**
   * Find a tab holding a Perchance chat generator (the LLM side).
   * The generator URL is the one the user loaded; nothing about it is hardcoded
   * beyond the domain, so any ai-character-chat generator works.
   */
  async findPerchanceTab() {
    const tabs = await chrome.tabs.query({ url: ["*://*.perchance.org/*", "*://perchance.org/*"] });
    const live = tabs.filter((t) => t.id != null && !t.discarded);
    if (!live.length) return null;
    // Prefer an active tab, else the most recently accessed one.
    live.sort((a, b) => (b.active ? 1 : 0) - (a.active ? 1 : 0) || (b.lastAccessed || 0) - (a.lastAccessed || 0));
    return live[0].id;
  }

  /** Send a command to the Perchance adapter (content script) in that tab. */
  async sendToPerchance(tabId, type, payload, opts) {
    const timeout = (opts && opts.timeout) || 8000;
    const reply = await Promise.race([
      chrome.tabs.sendMessage(tabId, { kind: "eagler-perchance-to-page", type, payload }),
      new Promise((r) => setTimeout(() => r({ ok: false, error: "perchance adapter did not answer (is the chat page loaded?)" }), timeout))
    ]).catch((e) => ({ ok: false, error: String(e && e.message || e) }));
    return reply;
  }

  /** Called by the service worker when a page reply arrives. */
  resolvePending(id, ok, result) {
    if (!id || !this.pending.has(id)) return false;
    const p = this.pending.get(id);
    this.pending.delete(id);
    clearTimeout(p.timer);
    p.resolve(ok, result);
    return true;
  }
}
