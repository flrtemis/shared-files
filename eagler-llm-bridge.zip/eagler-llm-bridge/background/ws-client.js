/*
 * Eagler LLM Bridge — WebSocket client to the local bridge host.
 *
 * The bridge host (llm/ws-bridge.js) binds a WebSocket server on 127.0.0.1 and
 * exposes it to the LLM (HTTP + WS). This file speaks its protocol:
 *
 *   server -> extension          extension -> server
 *   { type:"welcome", protocol }   { type:"hello", protocol, session, settings }
 *   { type:"cmd", id, ... }        { type:"result", id, ok, result }
 *   { type:"ping" }                { type:"pong" }
 *                                  { type:"event", event }
 *
 * Anything else is treated as a command, so an LLM can just send
 * {"id":"1","action":"key_down","key":"w","duration":1000} with no envelope.
 */

const RECONNECT_MIN = 1000;
const RECONNECT_MAX = 15000;

export class BridgeSocket {
  constructor(store) {
    this.store = store;
    this.ws = null;
    this.connected = false;
    this.host = null;
    this.port = null;
    this.attempt = 0;
    this.reconnectTimer = null;
    this.onCommand = null;
    this.onClose = null;
    this.onHello = null;
    this.manualClose = false;
  }

  init({ onCommand, onClose }) {
    this.onCommand = onCommand || (() => {});
    this.onClose = onClose || (() => {});
  }

  connect({ host, port, onHello, sessionHeight }) {
    if (this.ws && (this.ws.readyState === 0 || this.ws.readyState === 1)) return;
    this.manualClose = false;
    this.host = host;
    this.port = port;
    this.onHello = onHello || this.onHello;
    const url = `ws://${host}:${port}`;
    let ws;
    try {
      ws = new WebSocket(url);
    } catch (e) {
      this.scheduleReconnect();
      return;
    }
    this.ws = ws;

    ws.addEventListener("open", () => {
      this.connected = true;
      this.attempt = 0;
      this.send({
        type: "hello",
        protocol: 1,
        client: "eagler-llm-bridge",
        session: sessionHeight || "observe"
      });
      if (this.onHello) this.onHello();
    });

    ws.addEventListener("message", (ev) => {
      let msg;
      try { msg = JSON.parse(ev.data); } catch (e) { return; }
      if (!msg || typeof msg !== "object") return;
      if (msg.type === "welcome" || msg.type === "hello") {
        this.send({ type: "hello", protocol: 1, client: "eagler-llm-bridge" });
        return;
      }
      if (msg.type === "ping") { this.send({ type: "pong", t: msg.t }); return; }
      if (msg.type === "pong") return;
      if (msg.type === "get_state") {
        this.send({ type: "state", id: msg.id, state: this.store.summary({ chatLimit: msg.chatLimit || 60, includeFrame: !!msg.includeFrame }) });
        return;
      }
      // Everything else is a command
      this.onCommand(msg);
    });

    ws.addEventListener("close", () => {
      this.connected = false;
      this.ws = null;
      if (this.onClose) this.onClose();
      if (!this.manualClose) this.scheduleReconnect();
    });

    ws.addEventListener("error", () => {
      // close event follows; nothing to do
    });
  }

  scheduleReconnect() {
    if (this.manualClose || this.reconnectTimer) return;
    const delay = Math.min(RECONNECT_MAX, RECONNECT_MIN * Math.pow(1.6, this.attempt++));
    this.reconnectTimer = setTimeout(() => {
      this.reconnectTimer = null;
      if (this.host && this.port) this.connect({ host: this.host, port: this.port });
    }, delay);
  }

  disconnect() {
    this.manualClose = true;
    clearTimeout(this.reconnectTimer);
    this.reconnectTimer = null;
    if (this.ws) { try { this.ws.close(); } catch (e) {} }
    this.ws = null;
    this.connected = false;
  }

  send(obj) {
    if (!this.ws || this.ws.readyState !== 1) return false;
    try { this.ws.send(JSON.stringify(obj)); return true; } catch (e) { return false; }
  }

  sendResult(id, ok, result) {
    this.send({ type: "result", id, ok, result });
  }

  sendEvent(event) {
    this.send({ type: "event", event });
  }
}
