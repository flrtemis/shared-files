/*
 * Eagler LLM Bridge — background service worker (MV3, ES module).
 *
 * Architecture
 * ------------
 *  LLM / CLI ──ws://127.0.0.1:8787──▶ bridge host (local server, ws-bridge.js)
 *                                        │  JSON frames over WebSocket
 *                                        ▼
 *                              THIS service worker (a WebSocket *client*)
 *                                        │  chrome.scripting / runtime messages
 *                                        ▼
 *                    content script (nite.games) ─ postMessage ─▶ page agent
 *                                                                    │
 *                              ┌─────────────────────────────────────┤
 *                              ▼                                     ▼
 *                 game frame agent (gnhustgames.org)      top page agent
 *                 - WebSocket sniffer (chat/health/pos)   - relays commands
 *                 - synthetic key/mouse injection
 *                 - canvas frames + packet injection
 *
 * Why the service worker never talks to the network directly: MV3 kills idle
 * workers, but outbound WebSockets keep it alive while they are open. The
 * bridge host is the only network endpoint, and it is local-only.
 */
import { TabManager } from "./tab-manager.js";
import { BridgeSocket } from "./ws-client.js";
import { StateStore } from "./state-store.js";
import { handleCommand, PROTOCOL_VERSION } from "./commands.js";
import { installRules } from "./rules.js";


const DEFAULTS = {
  host: "127.0.0.1:8787",
  autoConnect: true,
  autoAttach: true,
  pushEvents: true,
  captureFps: 0.5,
  captureWidth: 480,
  allowInject: false,
  allowMirror: false,
  tabId: null
};

const store = new StateStore();
const tabs = new TabManager({
  onPageEvent: (evt) => store.applyPageEvent(evt),
  onFrame: (frame) => store.applyFrame(frame),
  onAgentGone: (frameKey) => store.dropAgent(frameKey)
});
const socket = new BridgeSocket(store);
let settings = { ...DEFAULTS };
let offscreenReady = false;

// ---------------------------------------------------------------------------
// Settings
// ---------------------------------------------------------------------------
async function loadSettings() {
  const got = await chrome.storage.local.get("settings");
  settings = { ...DEFAULTS, ...(got.settings || {}) };
  return settings;
}

async function saveSettings(patch) {
  settings = { ...settings, ...patch };
  await chrome.storage.local.set({ settings });
  return settings;
}

// ---------------------------------------------------------------------------
// Offscreen audio document (lazy)
// ---------------------------------------------------------------------------
async function ensureOffscreen() {
  if (offscreenReady) return true;
  if (!chrome.offscreen) return false;
  const existing = await chrome.runtime.getContexts
    ? await chrome.runtime.getContexts({ contextTypes: ["OFFSCREEN_DOCUMENT"] })
    : [];
  if (existing && existing.length) { offscreenReady = true; return true; }
  try {
    await chrome.offscreen.createDocument({
      url: "offscreen/audio.html",
      reasons: ["USER_MEDIA"],
      justification: "Record the game tab's audio for local speech-to-text so the LLM can read voice chat."
    });
    offscreenReady = true;
    return true;
  } catch (e) {
    console.warn("[eagler-bridge] offscreen failed", e);
    return false;
  }
}

// ---------------------------------------------------------------------------
// Connection management
// ---------------------------------------------------------------------------
function connectSocket() {
  const [host, port] = (settings.host || DEFAULTS.host).split(":");
  socket.connect({
    host: host || "127.0.0.1",
    port: parseInt(port || "8787", 10),
    sessionHeight: settings.allowInject ? "inject-enabled" : "observe",
    onHello: () => {
      broadcast({ type: "bridge_status", connected: true });
      socket.sendEvent({ type: "settings", settings: publicSettings() });
    }
  });
}

function publicSettings() {
  return {
    captureFps: settings.captureFps,
    captureWidth: settings.captureWidth,
    allowInject: settings.allowInject,
    allowMirror: settings.allowMirror,
    autoAttach: settings.autoAttach
  };
}

function broadcast(msg) {
  chrome.runtime.sendMessage({ kind: "eagler-bridge-ui", msg }).catch(() => {});
}

// ---------------------------------------------------------------------------
// Tabs / injection
// ---------------------------------------------------------------------------
// Hosts that serve the Eaglercraft client. nite.games embeds it; gnhustgames.org
// serves it directly (and is what the tests and self-hosted copies use).
const GAME_HOSTS = /(^|\/\/)(www\.)?(nite\.games|gnhustgames\.org)\//i;

async function findGameTab(all) {
  const isGame = (t) => t && t.url && GAME_HOSTS.test(t.url);
  // 1) a tab whose frames already host a registered agent — the strongest
  //    signal, and it works for embeds on hosts this file has never heard of.
  const live = new Set(store.listAgents().map((a) => a.tab).filter((x) => x != null));
  const withAgent = all.filter((t) => live.has(t.id));
  if (withAgent.length) return withAgent[0];
  // 2) a known game host
  const byHost = all.filter(isGame);
  if (byHost.length) return byHost[0];
  return null;
}

async function ensureMinecraftTab(preferId) {
  const id = preferId || settings.tabId;
  const all = await chrome.tabs.query({});
  // An explicitly requested tab wins even if it is not on a known host.
  let tab = id ? all.find((t) => t.id === id) : null;
  if (!tab) tab = await findGameTab(all);
  if (!tab) return null;
  if (tab.id !== settings.tabId) {
    settings.tabId = tab.id;
    await chrome.storage.local.set({ settings });
  }
  return tab;
}

async function attachToTab(tabId) {
  if (!tabId) return { ok: false, error: "no nite.games tab open" };
  // 1) top page: content script is declared in the manifest, but the tab may
  //    have been opened before install — inject manually too.
  await tabs.ensureTopInjected(tabId);
  // 2) all frames: inject the game agent into the Eaglercraft frame
  const res = await tabs.injectIntoFrames(tabId);
  return res;
}

// ---------------------------------------------------------------------------
// Commands coming from the LLM over WS
// ---------------------------------------------------------------------------
async function onSocketCommand(cmd) {
  const id = cmd.id;
  const type = cmd.type;

  try {
    // Attach automatically when the LLM starts talking
    let tabId = settings.tabId;
    if (!tabId && settings.autoAttach) {
      const tab = await ensureMinecraftTab();
      if (tab) { tabId = tab.id; await attachToTab(tabId); }
    }

    const result = await handleCommand(cmd, {
      tabs,
      store,
      socket,
      settings,
      saveSettings,
      attachToTab,
      ensureMinecraftTab,
      ensureOffscreen,
      tabId,
      broadcast
    });
    socket.sendResult(id, true, result);
  } catch (e) {
    socket.sendResult(id, false, String(e && e.message || e));
  }
}

// ---------------------------------------------------------------------------
// Wiring
// ---------------------------------------------------------------------------
async function init() {
  await loadSettings();
  installRules();
  socket.init({
    onCommand: onSocketCommand,
    onClose: () => broadcast({ type: "bridge_status", connected: false })
  });
  if (settings.autoAttach) {
    ensureMinecraftTab().then((tab) => { if (tab) attachToTab(tab.id); }).catch(() => {});
  }
  if (settings.autoConnect) connectSocket();
}

init();

chrome.runtime.onInstalled.addListener(async () => {
  await loadSettings();
  chrome.alarms.create("eagler-keepalive", { periodInMinutes: 0.5 });
});

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name !== "eagler-keepalive") return;
  // Keep the service worker (and thus the WS client) alive while connected
  if (!socket.connected && settings.autoConnect) connectSocket();
  const tab = await ensureMinecraftTab().catch(() => null);
  if (tab && settings.autoAttach) await attachToTab(tab.id).catch(() => {});
});

// ---------------------------------------------------------------------------
// Messages from content scripts / offscreen / popup / options
// ---------------------------------------------------------------------------
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg) return;
  // Ring buffer of recent messages: makes "did the worker hear it?" answerable
  // without a debugger (used by the tests and by anyone debugging injection).
  self.__msgLog = self.__msgLog || [];
  self.__msgLog.push({
    kind: msg.kind, type: msg.type, tab: sender.tab && sender.tab.id,
    url: (msg.payload && (msg.payload.url || (msg.payload.entry && msg.payload.entry.url))) || undefined,
    from: sender.frameId, at: Date.now()
  });
  if (self.__msgLog.length > 100) self.__msgLog.shift();

  // ---- From content script on nite.games -----------------------------------
  if (msg.kind === "eagler-bridge") {
    const tabId = sender.tab ? sender.tab.id : null;
    const tabKey = "tab" + (tabId == null ? "?" : tabId);

    switch (msg.type) {
      case "content-ready": {
        sendResponse({ ok: true });
        tabs.noteContentReady(tabId);
        // Token for the top page agent is requested by the agent itself; the
        // content script pushes it on boot. We also ask for frame injection.
        tabs.injectIntoFrames(tabId).catch(() => {});
        break;
      }
      case "inject-frames": {
        sendResponse({ ok: true });
        tabs.injectIntoFrames(tabId).then((r) => {
          broadcast({ type: "inject_result", tabId, result: r });
        }).catch(() => {});
        break;
      }
      case "page-hello": {
        sendResponse({ ok: true });
        const evt = { tab: tabKey, frameKey: msg.payload.frameKey, ...msg.payload };
        store.markAgent(evt);
        // A frame that has the parser IS the game, wherever it is embedded. If
        // nothing is attached yet, adopt this tab so `attach` works off-site too.
        if (msg.payload.hasParser && tabId != null && !settings.tabId) {
          settings.tabId = tabId;
          chrome.storage.local.set({ settings }).catch(() => {});
        }
        socket.sendEvent({ type: "agent_hello", tab: tabKey, frameKey: msg.payload.frameKey, url: msg.payload.url, hasParser: msg.payload.hasParser });
        // Sync the current config down to the fresh agent
        tabs.relayToFrame(tabId, msg.payload.frameKey, "set_config", {
          id: "cfg",
          config: {
            captureFps: settings.captureFps,
            captureWidth: settings.captureWidth,
            allowInject: settings.allowInject,
            allowMirror: settings.allowMirror
          }
        }).catch(() => {});
        break;
      }
      case "page-result": {
        sendResponse({ ok: true });
        const payload = msg.payload;
        // Command results carry ok/result; snapshot/status replies carry ok/result
        // too, so one pending-table dispatch covers every request type.
        tabs.resolvePending(payload.id, payload.ok, payload.result !== undefined ? payload.result : payload);
        break;
      }
      case "page-status_result": {
        sendResponse({ ok: true });
        const payload = msg.payload || {};
        if (payload.id) tabs.resolvePending(payload.id, payload.ok, payload);
        break;
      }
      case "page-event": {
        sendResponse({ ok: true });
        const evt = { tab: tabKey, ...msg.payload };
        store.applyPageEvent(evt);
        break;
      }
      case "page-frame": {
        sendResponse({ ok: true });
        store.applyFrame({ tab: tabKey, ...msg.payload });
        break;
      }
      case "page-audio":
        sendResponse({ ok: true });
        break;
      default:
        sendResponse({ ok: false });
    }
    return true;
  }

  // ---- From the Perchance adapter (the LLM side) ---------------------------
  if (msg.kind === "eagler-perchance") {
    const tabId = sender.tab ? sender.tab.id : null;
    const tabKey = "tab" + (tabId == null ? "?" : tabId);
    switch (msg.type) {
      case "llm-status": {
        sendResponse({ ok: true });
        store.perchanceTabId = tabId;
        store.applyPageEvent({ tab: tabKey, type: "llm-status", payload: msg.payload || {} });
        socket.sendEvent({ type: "llm_status", ...(msg.payload || {}) });
        break;
      }
      case "llm-message": {
        sendResponse({ ok: true });
        store.perchanceTabId = tabId;
        store.applyPageEvent({ tab: tabKey, type: "llm-message", payload: msg.payload || {} });
        socket.sendEvent({ type: "llm_message", ...(msg.payload || {}) });
        break;
      }
      default:
        sendResponse({ ok: false });
    }
    return true;
  }

  // ---- From offscreen audio doc -------------------------------------------
  if (msg.kind === "eagler-bridge-offscreen") {
    if (msg.type === "transcript") {
      store.pushTranscript({ text: msg.text, confidence: msg.confidence, at: Date.now() });
      socket.sendEvent({ type: "transcript", text: msg.text, confidence: msg.confidence });
    } else if (msg.type === "speech-error") {
      socket.sendEvent({ type: "transcript_error", error: msg.error });
    } else if (msg.type === "offscreen-ready") {
      offscreenReady = true;
    }
    return;
  }

  // ---- From popup / options UI --------------------------------------------
  if (msg.kind === "eagler-bridge-ui-req") {
    (async () => {
      try {
        switch (msg.type) {
          case "get_state":
            sendResponse({
              ok: true,
              settings: publicSettings(),
              host: settings.host,
              connected: socket.connected,
              store: store.summary(),
              protocol: PROTOCOL_VERSION
            });
            break;
          case "connect":
            connectSocket();
            sendResponse({ ok: true });
            break;
          case "disconnect":
            socket.disconnect();
            sendResponse({ ok: true });
            break;
          case "attach": {
            const tab = await ensureMinecraftTab(msg.tabId);
            if (!tab) { sendResponse({ ok: false, error: "open nite.games/game/minecraft first" }); break; }
            const r = await attachToTab(tab.id);
            sendResponse({ ok: true, result: r });
            break;
          }
          case "set_settings": {
            const s = await saveSettings(msg.patch || {});
            socket.sendEvent({ type: "settings", settings: publicSettings() });
            sendResponse({ ok: true, settings: s });
            break;
          }
          case "self_test": {
            const r = await runSelfTest();
            sendResponse(r);
            break;
          }
          case "enable_audio": {
            const ok = await ensureOffscreen();
            sendResponse({ ok, offscreen: ok });
            break;
          }
          case "snapshot": {
            const tab = await ensureMinecraftTab();
            if (!tab) { sendResponse({ ok: false, error: "no tab" }); break; }
            const snap = await tabs.requestSnapshot(tab.id, { chatLimit: 80 });
            // Merge live store chat as a fallback
            sendResponse({ ok: true, snapshot: snap, store: store.summary() });
            break;
          }
          default:
            sendResponse({ ok: false, error: "unknown ui request" });
        }
      } catch (e) {
        sendResponse({ ok: false, error: String(e && e.message || e) });
      }
    })();
    return true;
  }
});

// ---------------------------------------------------------------------------
// Self test: proves the whole path works without an LLM attached
// ---------------------------------------------------------------------------
async function runSelfTest() {
  const steps = [];
  function step(name, ok, detail) { steps.push({ name, ok, detail }); }
  try {
    step("service worker alive", true, PROTOCOL_VERSION);
    const tab = await ensureMinecraftTab();
    step("nite.games tab found", !!tab, tab ? tab.url : "open https://nite.games/game/minecraft");
    if (!tab) return { ok: false, steps };

    await tabs.ensureTopInjected(tab.id);
    const top = await tabs.pingTop(tab.id);
    step("content script responds", !!top && top.ok, top);

    const inj = await tabs.injectIntoFrames(tab.id, { force: true });
    step("game frame injected", !!inj && inj.injected > 0, inj);

    await new Promise((r) => setTimeout(r, 1200));
    const frameAgents = store.listAgents();
    step("page agent said hello", frameAgents.length > 0, frameAgents);

    // The real remote frame occasionally answers just after the first 4 s
    // window during a cold load; one retry keeps the self-test honest.
    let status = await tabs.requestStatus(tab.id);
    if (!status || !status.ok) status = await tabs.requestStatus(tab.id);
    step("agent status", !!status && !!status.ok, status && status.result);

    const snap = await tabs.requestSnapshot(tab.id, { chatLimit: 20 });
    step("state snapshot", !!snap && !!snap.ok, snap && snap.snapshot && snap.snapshot.game);

    // Input path: one W tap for 400 ms (a human would see the player step)
    const tap = await tabs.sendCommand(tab.id, { action: "key_tap", key: "w", duration: 400 });
    step("synthetic key accepted", !!tap && !!tap.ok, tap && tap.result);

    step("LLM socket connected", socket.connected, settings.host);
    return { ok: steps.every((s) => s.ok || s.name === "LLM socket connected"), steps };
  } catch (e) {
    step("exception", false, String(e && e.message || e));
    return { ok: false, steps };
  }
}

// Expose for debugging from the service worker console
// Debug handle + message log, kept small and always on: they are how the test
// suites and anyone debugging a stuck attach inspect the worker without a
// debugger attached. runCommand goes through the exact same path as WS commands.
self.__eaglerBridge = {
  store, tabs, socket, settings: () => settings, runSelfTest,
  runCommand: (c) => handleCommand(c, { tabs, store, settings, saveSettings, attachToTab, ensureMinecraftTab, ensureOffscreen, tabId: settings.tabId, socket }),
  msgLog: () => (self.__msgLog || []).slice(-50)
};
