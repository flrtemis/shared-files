/*
 * Eagler LLM Bridge — command handling.
 *
 * The LLM sends one JSON object per command. Two accepted shapes:
 *
 *   {"id":"1","action":"key_down","key":"w","duration":1000}
 *   {"id":"2","type":"command","command":{"action":"key_down", ...}}
 *
 * Every command is validated here (the privileged layer), then relayed to the
 * page agent inside the game frame. Commands that read state (snapshot, chat,
 * status, frame) are answered from the store without touching the page.
 */

export const PROTOCOL_VERSION = "1.0";

const KEY_RE = /^([A-Za-z0-9_]{1,24}|[1-9]|0| |\.|\/|,|-|=|;|'|\[|\]|`|\\|code:[A-Za-z0-9]+)$/;

function bad(msg) {
  const e = new Error(msg);
  e.userFacing = true;
  throw e;
}

function num(v, name, min, max, dflt) {
  if (v == null) {
    if (dflt !== undefined) return dflt;
    bad(`${name} is required`);
  }
  const n = Number(v);
  if (!isFinite(n)) bad(`${name} must be a number`);
  if (min != null && n < min) bad(`${name} must be >= ${min}`);
  if (max != null && n > max) bad(`${name} must be <= ${max}`);
  return n;
}

function key(v) {
  if (v == null) bad("key is required");
  const s = String(v);
  if (!KEY_RE.test(s)) bad("invalid key: " + s);
  return s;
}

/** Normalize the many ways an LLM may phrase a single action. */
export function normalizeCommand(cmd) {
  if (!cmd || typeof cmd !== "object") bad("command must be a JSON object");
  const c = { ...cmd };
  if (c.type === "command" && c.command && typeof c.command === "object") return normalizeCommand(c.command);
  if (!c.action) {
    if (c.key != null && c.duration == null && c.hold !== true) c.action = "key_tap";
    else if (c.key != null) c.action = "key_down";
    else if (c.message != null) c.action = "chat";
    else bad("action is required (see the action list in README)");
  }
  const a = String(c.action).toLowerCase().replace(/[-\s]/g, "_");

  switch (a) {
    case "key_down":
    case "keydown":
    case "press":
    case "hold":
      return { action: "key_down", key: key(c.key), duration: c.duration == null ? null : num(c.duration, "duration", 0, 600000) };
    case "key_up":
    case "keyup":
    case "release":
      return { action: "key_up", key: key(c.key) };
    case "key_tap":
    case "tap":
    case "keypress":
    case "key_press":
      return { action: "key_tap", key: key(c.key), duration: num(c.duration, "duration", 0, 600000, 60) };
    case "type":
    case "type_text":
      if (c.text == null) bad("text is required");
      return { action: "type", text: String(c.text).slice(0, 2000), delay: num(c.delay, "delay", 0, 500, 12) };
    case "chat":
    case "send_chat":
    case "say":
      if ((c.text == null) && (c.message == null)) bad("text is required");
      return { action: "chat", text: String(c.text != null ? c.text : c.message).slice(0, 250), delay: num(c.delay, "delay", 0, 500, 12) };
    case "command":
    case "run_command":
      if ((c.command_text == null) && (c.text == null)) bad("command text is required");
      return { action: "command", command_text: String(c.command_text || c.text).slice(0, 250) };
    case "look":
    case "mouse_look":
    case "turn":
      return { action: "look", dx: num(c.dx, "dx", -100000, 100000, 0), dy: num(c.dy, "dy", -100000, 100000, 0) };
    case "mouse_move":
    case "move_mouse":
      return { action: "mouse_move", dx: num(c.dx, "dx", -100000, 100000, 0), dy: num(c.dy, "dy", -100000, 100000, 0), steps: num(c.steps, "steps", 1, 30, 1) };
    case "mouse_down":
    case "mousedown":
      return { action: "mouse_down", button: c.button == null ? "left" : String(c.button) };
    case "mouse_up":
    case "mouseup":
      return { action: "mouse_up", button: c.button == null ? "left" : String(c.button) };
    case "left_click":
    case "right_click":
    case "attack":
      return { action: "mouse_down", button: a === "right_click" ? "right" : "left" };
    case "click":
      return { action: "click" };
    case "wheel":
    case "scroll":
      return { action: "wheel", deltaY: num(c.deltaY != null ? c.deltaY : c.dy, "deltaY", -100000, 100000, 0), duration: num(c.duration, "duration", 0, 10000, 0) };
    case "wait":
    case "sleep":
      return { action: "wait", ms: num(c.ms != null ? c.ms : c.duration, "ms", 0, 600000, 100) };
    case "release_all":
    case "stop":
      return { action: "release_all" };
    case "sequence":
    case "steps":
    case "macro":
      if (!Array.isArray(c.steps)) bad("steps must be an array");
      if (c.steps.length > 200) bad("too many steps (max 200)");
      return { action: "_sequence", steps: c.steps.map((s) => (typeof s === "string" ? { action: "key_tap", key: s } : s)) };
    case "packet":
    case "inject":
      if (!c.name) bad("packet name is required");
      return { action: "packet", name: String(c.name), args: c.args || c.data || {} };
    case "start_audio_transcription":
      return { action: "_audio_start" };
    case "stop_audio_transcription":
      return { action: "_audio_stop" };
    case "start_mirror":
      if (!c.url) bad("url is required");
      return { action: "_mirror_start", url: String(c.url), username: c.username, brand: c.brand };
    case "mirror_send":
      if (!Array.isArray(c.bytes)) bad("bytes must be an array");
      return { action: "_mirror_send", bytes: c.bytes };
    default:
      bad("unknown action: " + c.action);
  }
}

// ---------------------------------------------------------------------------
// State readers (served from the store; no page round-trip)
// ---------------------------------------------------------------------------
function chatSnippet(store, limit) {
  return store.chat.slice(-limit).map((c) => ({
    at: c.at,
    kind: c.kind,
    from: c.from,
    text: c.text
  }));
}

export async function handleCommand(cmd, ctx) {
  const { tabs, store, settings, saveSettings, attachToTab, ensureMinecraftTab, ensureOffscreen, tabId, socket } = ctx;
  const action = (cmd.action || cmd.type || "").toString().toLowerCase().replace(/[-\s]/g, "_");
  const effectiveTabId = cmd.tabId || tabId;

  // ---- observation commands ------------------------------------------------
  if (action === "get_state" || action === "state" || action === "observe") {
    const s = store.summary({ chatLimit: Math.min(Number(cmd.chatLimit) || 60, 200), includeFrame: !!cmd.includeFrame });
    return {
      ok: true,
      state: s,
      chat: chatSnippet(store, Number(cmd.chatLimit) || 20),
      llm: store.llm,
      llmReplies: store.llmReplies.slice(-10),
      frame: cmd.includeFrame ? s.frame : undefined
    };
  }

  if (action === "get_chat" || action === "chat_log" || action === "read_chat") {
    return { ok: true, chat: chatSnippet(store, Math.min(Number(cmd.limit) || 50, 200)), seq: store.chatSeq };
  }

  if (action === "changes" || action === "since") {
    return { ok: true, ...store.since(cmd.chatSeq, cmd.eventSeq) };
  }

  if (action === "screenshot" || action === "frame" || action === "capture") {
    const width = Math.max(160, Math.min(1280, Number(cmd.width) || settings.captureWidth || 480));
    let frame = null;
    try {
      const r = await tabs.sendCommand(effectiveTabId, { action: "capture", width }, { timeout: 4000 });
      const f = r && r.result && r.result.frame;
      if (f && f.ok) frame = f;
    } catch (e) { /* fall back to the store */ }
    if (!frame && store.lastFrame) frame = store.lastFrame;
    if (!frame) return { ok: false, error: "no frame captured yet (open the game first)" };
    return { ok: true, frame: { at: frame.at || new Date().toISOString(), dataUrl: frame.dataUrl, width: frame.width, height: frame.height } };
  }

  if (action === "status" || action === "ping") {
    const status = effectiveTabId ? await tabs.requestStatus(effectiveTabId).catch(() => null) : null;
    return {
      ok: true,
      bridge: PROTOCOL_VERSION,
      tab: effectiveTabId || null,
      socket: socket.connected,
      page: status,
      state: store.summary({ chatLimit: 10 })
    };
  }

  if (action === "attach") {
    const tab = await ensureMinecraftTab(cmd.tabId);
    if (!tab) bad("no nite.games tab open — open https://nite.games/game/minecraft first");
    const r = await attachToTab(tab.id);
    return { ok: true, tabId: tab.id, attached: r };
  }

  if (action === "set_settings") {
    const patch = {};
    for (const k of ["captureFps", "captureWidth", "allowInject", "allowMirror", "pushEvents", "autoAttach", "tabId"]) {
      if (cmd[k] != null) patch[k] = cmd[k];
    }
    const s = await saveSettings(patch);
    if (effectiveTabId) {
      await tabs.relayToFrame(effectiveTabId, null, "set_config", {
        id: "cfg",
        config: { captureFps: s.captureFps, captureWidth: s.captureWidth, allowInject: s.allowInject, allowMirror: s.allowMirror }
      }).catch(() => {});
    }
    return { ok: true, settings: { captureFps: s.captureFps, captureWidth: s.captureWidth, allowInject: s.allowInject, allowMirror: s.allowMirror } };
  }

  if (action === "enable_injection" || action === "allow_inject") {
    await saveSettings({ allowInject: cmd.enabled !== false });
    if (effectiveTabId) {
      await tabs.relayToFrame(effectiveTabId, null, "set_config", { id: "cfg", config: { allowInject: cmd.enabled !== false } }).catch(() => {});
    }
    return { ok: true, allowInject: cmd.enabled !== false };
  }

  // ---- the LLM side: the Perchance AI chat ---------------------------------
  //
  // These reach the adapter living in the generator frame, not the game frame,
  // and never need a game tab, so they run before the attach gate below.
  async function perchanceTab() {
    if (cmd.tabId) return cmd.tabId;
    if (store.perchanceTabId) return store.perchanceTabId;
    const found = await tabs.findPerchanceTab().catch(() => null);
    if (found) { store.perchanceTabId = found; return found; }
    return null;
  }

  if (action === "llm_say" || action === "llm_ask" || action === "ask_llm" || action === "say_to_llm") {
    const text = String(cmd.text != null ? cmd.text : cmd.message != null ? cmd.message : cmd.prompt != null ? cmd.prompt : "");
    if (!text.trim()) bad("text is required");
    if (text.length > 8000) bad("text too long (max 8000 chars)");
    const id = await perchanceTab();
    if (!id) bad("no Perchance chat tab found — open the AI character chat page first");
    const r = await tabs.sendToPerchance(id, "send", { text });
    if (!r || r.ok === false) return { ok: false, error: (r && r.error) || "the adapter refused the send" };
    return { ok: true, sent: text, waitForReply: cmd.wait !== false, note: "reply streams in as llm_reply events / /llm" };
  }

  if (action === "llm_status" || action === "perchance_status") {
    const id = await perchanceTab();
    if (!id) return { ok: true, attached: false, error: "no Perchance chat tab found" };
    const r = await tabs.sendToPerchance(id, "status", {}).catch(() => null);
    return { ok: true, attached: true, tabId: id, status: r || store.llm };
  }

  if (action === "llm_stop" || action === "stop_llm") {
    const id = await perchanceTab();
    if (!id) bad("no Perchance chat tab found");
    const r = await tabs.sendToPerchance(id, "stop", {});
    return { ok: !!(r && r.ok), result: r };
  }

  if (action === "llm_messages") {
    const id = await perchanceTab();
    if (!id) return { ok: true, attached: false, replies: store.llmReplies };
    const r = await tabs.sendToPerchance(id, "messages", {}).catch(() => null);
    return { ok: true, attached: !!r, replies: store.llmReplies, page: r };
  }

  if (action === "_audio_start") {
    const ok = await ensureOffscreen();
    return { ok, note: ok ? "audio document ready (transcription runs on demand)" : "offscreen unavailable" };
  }
  if (action === "_audio_stop") return { ok: true };

  // ---- everything else is an input/actuation command -----------------------
  if (!effectiveTabId) bad("not attached to a tab: open nite.games and call {action:'attach'}");

  // Normalize + validate (throws user-facing errors)
  let normalized;
  if (action === "_mirror_start" || action === "_mirror_send") {
    normalized = cmd;
  } else if (action === "_sequence") {
    normalized = { action: "_sequence", steps: cmd.steps || cmd.sequence };
  } else {
    normalized = normalizeCommand(cmd);
  }

  // Mirror + audio commands go to the page with their privileged names
  if (normalized.action === "_mirror_start") {
    const r = await tabs.relayToFrame(effectiveTabId, null, "start_mirror", { id: "m", url: normalized.url, username: normalized.username, brand: normalized.brand });
    return { ok: true, sent: r, note: "mirror socket opening; frames will stream as events" };
  }
  if (normalized.action === "_mirror_send") {
    const r = await tabs.relayToFrame(effectiveTabId, null, "mirror_send", { id: "ms", bytes: normalized.bytes });
    return { ok: true, sent: r };
  }

  const timeout = normalized.action === "_sequence" ? 60000 : 20000;
  const res = await tabs.sendCommand(effectiveTabId, normalized, { timeout });
  const result = res && res.result;
  const ok = !!(result && result.ok !== false && (res.ok !== false));
  return { ok, action: normalized.action, result };
}
