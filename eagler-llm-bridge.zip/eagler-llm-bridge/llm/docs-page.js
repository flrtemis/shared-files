/*
 * Minimal self-contained docs page served at http://127.0.0.1:8787/
 * (No CDN dependencies: it must work offline and inside the sandboxed viewer.)
 */
"use strict";

exports.html = function html(port) {
  const base = "http://127.0.0.1:" + (port || 8787);
  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Eagler LLM Bridge — local API</title>
<style>
  :root { color-scheme: dark; }
  body { font: 15px/1.55 ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, sans-serif; background:#0b0e14; color:#dbe3ef; max-width: 820px; margin: 40px auto; padding: 0 20px; }
  h1 { font-size: 24px; margin-bottom: 4px; }
  .sub { color:#8b98ab; margin-bottom: 28px; }
  code, pre { background:#121826; border:1px solid #1e2839; border-radius:6px; }
  code { padding: 1px 5px; font-size: 13px; }
  pre { padding: 14px 16px; overflow:auto; font-size: 13px; }
  h2 { margin-top: 34px; font-size: 17px; border-top:1px solid #1e2839; padding-top: 20px; }
  table { width:100%; border-collapse: collapse; font-size: 13.5px; }
  th, td { text-align:left; padding: 7px 10px; border-bottom: 1px solid #1e2839; vertical-align: top; }
  th { color:#8b98ab; font-weight:600; }
  .ok { color:#5ad27b; } .warn { color:#ffcf5a; } .bad { color:#ff6b6b; }
  .pill { display:inline-block; border:1px solid #2a364d; padding:1px 8px; border-radius:99px; font-size:12px; color:#9fb0c8; border-color:#2a364d; margin-right:6px;}
  button { background:#1c2740; color:#dbe3ef; border:1px solid #2d3d5e; border-radius:6px; padding:6px 12px; cursor:pointer; font-size:13px;}
  button:hover { background:#243354; }
</style>
</head>
<body>
  <h1>Eagler LLM Bridge <span class="pill">local only</span></h1>
  <div class="sub">Bridge host on <code>${base}</code> — nothing leaves this machine. The Chrome extension connects here and performs the game interaction.</div>

  <p>
    <span id="ext" class="warn">checking extension…</span> &nbsp;
    <button onclick="poll()">Refresh</button>
  </p>

  <h2>For an LLM (tool calling)</h2>
  <p>Point your tool runner at <code>POST /command</code>, or connect the WebSocket and send the same JSON objects. Ready-made schemas:
    <a style="color:#7db7ff" href="/openapi.json">/openapi.json</a>,
    <code>llm/tools/openai-tools.json</code>, <code>llm/tools/anthropic-tools.json</code>.</p>
  <pre>POST /command
{"action":"key_down","key":"w","duration":1000}

{"action":"sequence","steps":[
  {"action":"chat","text":"hello from the bot"},
  {"action":"look","dx":120,"dy":0},
  {"action":"key_tap","key":"space"}
]}

{"action":"get_state"}</pre>

  <h2>Talking to the AI brain (Perchance)</h2>
  <p>The AI chat in the open Perchance tab is reachable through the same command envelope, so an LLM on this side
     can use it as a sub-brain, or let it drive the game directly:</p>
  <pre>{"action":"llm_say","message":"You are watching: Steve joined the world."}
{"action":"llm_ask","message":"What should I do next?","timeoutMs":120000}
{"action":"llm_status"}
{"action":"llm_messages","limit":10}</pre>
  <p>Dedicated endpoints: <code>POST /llm</code>, <code>POST /llm/ask</code>, <code>GET /llm/status</code>.</p>

  <h2>Endpoints</h2>
  <table>
    <tr><th>Method</th><th>Path</th><th>Purpose</th></tr>
    <tr><td>GET</td><td>/health</td><td>Extension connected? Client count, uptime.</td></tr>
    <tr><td>GET</td><td>/state</td><td>Chat tail, health/food, position, scoreboard, agents.</td></tr>
    <tr><td>GET</td><td>/chat?limit=50</td><td>Recent chat only (fast path).</td></tr>
    <tr><td>POST</td><td>/command</td><td>Any JSON command, including sequences.</td></tr>
    <tr><td>GET</td><td>/screenshot?width=640</td><td>JPEG of the game canvas — feed it to a vision model.</td></tr>
    <tr><td>GET</td><td>/events</td><td>SSE stream of chat/vitals/movement/transcripts.</td></tr>
    <tr><td>WS</td><td>ws://127.0.0.1:${port || 8787}</td><td>Bidirectional: commands in, results + events out.</td></tr>
  </table>

  <h2>Action reference</h2>
  <table>
    <tr><th>action</th><th>fields</th><th>effect</th></tr>
    <tr><td>key_down / key_up / key_tap</td><td>key, duration</td><td>Keyboard events in the game frame (w a s d space shift enter t / 1..9)</td></tr>
    <tr><td>type</td><td>text, delay</td><td>Types characters through the engine's keyboard handler</td></tr>
    <tr><td>chat / command</td><td>text</td><td>Opens chat with T, types, presses Enter. <code>command</code> prefixes "/"</td></tr>
    <tr><td>look / mouse_move</td><td>dx, dy</td><td>Computed camera movement given to the mouse handler</td></tr>
    <tr><td>mouse_down / mouse_up / click</td><td>button</td><td>Attack / use / menus</td></tr>
    <tr><td>wheel</td><td>deltaY</td><td>Hotbar scrolling when pointer lock is unavailable</td></tr>
    <tr><td>sequence</td><td>steps[]</td><td>Run steps in order server-side</td></tr>
    <tr><td>packet</td><td>name, args</td><td>Opt-in: send a protocol packet (chat, use_entity, held_item_change, …) over the live socket</td></tr>
    <tr><td>get_state / get_chat / changes</td><td>chatLimit / limit / chatSeq,eventSeq</td><td>Read-back state for the LLM</td></tr>
  </table>

  <h2>State observer notes</h2>
  <ul>
    <li><b>Chat + HUD</b> come from the real Minecraft 1.8 packet stream (the extension sniffs the Eaglercraft WebSocket in the page, both directions).</li>
    <li><b>Vision</b> comes from periodic canvas captures (<code>/screenshot</code>), which is the only way to read a WebGL game's UI.</li>
    <li><b>Voice chat</b> transcripts are best-effort via the browser's SpeechRecognition on the tab's audio; they are labelled <code>unverified</code>.</li>
  </ul>

<script>
async function poll() {
  try {
    const r = await fetch('/health'); const j = await r.json();
    const el = document.getElementById('ext');
    if (j.extension) { el.className = 'ok'; el.textContent = 'extension connected ✓  (' + j.clients + ' client' + (j.clients === 1 ? '' : 's') + ')'; }
    else { el.className = 'bad'; el.textContent = 'extension NOT connected — open the extension popup and press Connect'; }
  } catch (e) {
    document.getElementById('ext').textContent = 'bridge host unreachable';
  }
}
poll(); setInterval(poll, 5000);
</script>
</body>
</html>`;
};
