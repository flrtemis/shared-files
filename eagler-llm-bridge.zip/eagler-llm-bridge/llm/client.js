#!/usr/bin/env node
/*
 * Eagler LLM Bridge — tiny Node client (no dependencies).
 *
 * Use it from your own scripts:
 *   const { Bridge } = require("./client.js");
 *   const b = new Bridge();
 *   await b.cmd({ action: "key_down", key: "w", duration: 1000 });
 *   console.log(await b.state());
 *
 * Or from the shell:
 *   node llm/client.js state
 *   node llm/client.js cmd '{"action":"key_tap","key":"space"}'
 *   node llm/client.js chat "hello"
 *   node llm/client.js watch          # stream events
 *   node llm/client.js shot           # save a JPEG of the canvas
 */
"use strict";

const http = require("http");
const fs = require("fs");
const path = require("path");

const HOST = process.env.BRIDGE_HOST || "127.0.0.1";
const PORT = parseInt(process.env.BRIDGE_PORT || "8787", 10);

function request(method, pathname, body) {
  return new Promise((resolve, reject) => {
    const data = body == null ? null : Buffer.from(typeof body === "string" ? body : JSON.stringify(body));
    const req = http.request(
      { host: HOST, port: PORT, path: pathname, method, headers: data ? { "Content-Type": "application/json", "Content-Length": data.length } : {} },
      (res) => {
        const chunks = [];
        res.on("data", (c) => chunks.push(c));
        res.on("end", () => resolve({ status: res.statusCode, headers: res.headers, body: Buffer.concat(chunks) }));
      }
    );
    req.on("error", reject);
    if (data) req.write(data);
    req.end();
  });
}

async function jsonRequest(method, pathname, body) {
  const r = await request(method, pathname, body);
  const text = r.body.toString("utf8");
  try { return JSON.parse(text); } catch (e) { return { ok: false, status: r.status, raw: text.slice(0, 400) }; }
}

class Bridge {
  constructor(opts = {}) {
    this.host = opts.host || HOST;
    this.port = opts.port || PORT;
  }

  health() { return jsonRequest("GET", "/health"); }
  cmd(command) { return jsonRequest("POST", "/command", command); }
  state(chatLimit = 50) { return jsonRequest("GET", "/state?chatLimit=" + chatLimit); }
  chat(limit = 50) { return jsonRequest("GET", "/chat?limit=" + limit); }

  async screenshot(width = 640) {
    const r = await request("GET", "/screenshot?width=" + width + "&format=json");
    try { return JSON.parse(r.body.toString("utf8")); } catch (e) { return { ok: false }; }
  }

  async screenshotToFile(file, width = 640) {
    const r = await request("GET", "/screenshot?width=" + width);
    if (r.status !== 200) throw new Error("screenshot failed: " + r.status);
    fs.writeFileSync(file, r.body);
    return file;
  }

  /** Convenience wrappers ------------------------------------------------- */
  keyDown(key, duration) { return this.cmd({ action: "key_down", key, duration }); }
  keyUp(key) { return this.cmd({ action: "key_up", key }); }
  tap(key, duration) { return this.cmd({ action: "key_tap", key, duration }); }
  type(text) { return this.cmd({ action: "type", text }); }
  sendChat(text) { return this.cmd({ action: "chat", text }); }
  runCommand(text) { return this.cmd({ action: "command", text }); }
  look(dx, dy) { return this.cmd({ action: "look", dx, dy }); }
  attack() { return this.cmd({ action: "mouse_down", button: "left" }); }
  sequence(steps) { return this.cmd({ action: "sequence", steps }); }

  /** WebSocket event stream (Node >= 21 has global WebSocket; Node 20 does not). */
  watch(onEvent) {
    let WS = globalThis.WebSocket;
    if (!WS) {
      try { WS = require("ws"); } catch (e) {
        throw new Error("WebSocket unavailable: run Node >= 21, or `npm i ws`");
      }
    }
    const ws = new WS(`ws://${this.host}:${this.port}`);
    ws.addEventListener("open", () => ws.send(JSON.stringify({ type: "hello" })));
    ws.addEventListener("message", (ev) => {
      try { onEvent(JSON.parse(ev.data)); } catch (e) { /* ignore */ }
    });
    return ws;
  }
}

module.exports = { Bridge, request, HOST, PORT };

// ---------------------------------------------------------------------------
// CLI
// ---------------------------------------------------------------------------
if (require.main === module) {
  const [cmd, ...rest] = process.argv.slice(2);
  const b = new Bridge();
  (async () => {
    switch (cmd) {
      case "health": console.log(await b.health()); break;
      case "state": console.log(JSON.stringify(await b.state(60), null, 2)); break;
      case "chat": console.log(JSON.stringify(await b.chat(50), null, 2)); break;
      case "cmd": console.log(JSON.stringify(await b.cmd(JSON.parse(rest.join(" "))), null, 2)); break;
      case "chat-send": console.log(JSON.stringify(await b.sendChat(rest.join(" ")), null, 2)); break;
      case "shot": {
        const file = rest[0] || path.join(process.cwd(), "eagler-shot.jpg");
        await b.screenshotToFile(file, parseInt(rest[1] || "800", 10));
        console.log("saved", file); break;
      }
      case "watch": {
        console.log("watching events (ctrl+c to stop)…");
        b.watch((msg) => {
          if (msg.type === "event") console.log(new Date().toISOString().slice(11, 19), msg.event.type, JSON.stringify(msg.event.payload || {}).slice(0, 300));
        });
        break;
      }
      default:
        console.log(`usage:
  node llm/client.js health
  node llm/client.js state
  node llm/client.js chat
  node llm/client.js cmd '{"action":"key_tap","key":"w","duration":1000}'
  node llm/client.js chat-send "hello world"
  node llm/client.js shot [file.jpg] [width]
  node llm/client.js watch`);
    }
  })().catch((e) => { console.error("error:", e.message); process.exit(1); });
}
