#!/usr/bin/env node
/*
 * Eagler LLM Bridge — local bridge host.
 *
 * This is the "simple local API or websocket that the LLM can use to send
 * JSON packets". It runs on your machine, binds 127.0.0.1 only (no LAN, no
 * internet), and speaks two protocols on one port:
 *
 *   WebSocket  ws://127.0.0.1:8787
 *     - the extension connects here as the *agent*;
 *     - an LLM or any script can also connect here as a *client*.
 *     Client frames:   {"id":"1","action":"key_down","key":"w","duration":1000}
 *     Client reply:    {"type":"result","id":"1","ok":true,"result":{...}}
 *     State requests:  {"id":"2","action":"get_state"}
 *     Event stream:    {"type":"event","event":{...}}   (broadcast to clients)
 *
 *   HTTP       http://127.0.0.1:8787
 *     GET  /health                 -> {ok, clients, extension}
 *     GET  /state                  -> current game state (chat, hud, pos, ...)
 *     GET  /chat?limit=50          -> recent chat
 *     POST /command  {"action":…}  -> same as a WS command (JSON in, JSON out)
 *     POST /screenshot             -> {frame:{dataUrl}} or image/png
 *     GET  /openapi.json           -> OpenAPI 3 schema for LLM tool bindings
 *
 *   Flags: --enable-inject   allow protocol packet injection this session
 *
 *   OpenAI-compatible tool schema: llm/tools/openai-tools.json
 *   Anthropic tool schema:        llm/tools/anthropic-tools.json
 *
 * Dependency-free: uses only Node builtins (http, crypto) plus a tiny RFC 6455
 * server implementation, so `node llm/ws-bridge.js` works on a fresh install.
 */
"use strict";

const http = require("http");
const crypto = require("crypto");

const HOST = process.env.BRIDGE_HOST || "127.0.0.1";
const PORT = parseInt(process.env.BRIDGE_PORT || "8787", 10);
const MAX_CLIENTS = 8;
const CMD_TIMEOUT_MS = 20000;

// ---------------------------------------------------------------------------
// Minimal RFC 6455 server (text frames only, no permessage-deflate)
// ---------------------------------------------------------------------------
const WS_GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11";

function encodeFrame(payload, opcode = 0x1) {
  const data = Buffer.isBuffer(payload) ? payload : Buffer.from(String(payload), "utf8");
  const len = data.length;
  let header;
  if (len < 126) {
    header = Buffer.alloc(2);
    header[1] = len;
  } else if (len < 65536) {
    header = Buffer.alloc(4);
    header[1] = 126;
    header.writeUInt16BE(len, 2);
  } else {
    header = Buffer.alloc(10);
    header[1] = 127;
    header.writeBigUInt64BE(BigInt(len), 2);
  }
  header[0] = 0x80 | opcode;
  return Buffer.concat([header, data]);
}

class WsConn {
  constructor(socket, req) {
    this.socket = socket;
    this.req = req;
    this.buffer = Buffer.alloc(0);
    this.alive = true;
    this.role = "unknown"; // "extension" | "client"
    this.handlers = { message: [], close: [] };
    socket.on("data", (chunk) => this._onData(chunk));
    socket.on("close", () => this._closed());
    socket.on("error", () => this._closed());
  }

  on(evt, fn) { (this.handlers[evt] || (this.handlers[evt] = [])).push(fn); return this; }
  emit(evt, ...args) { (this.handlers[evt] || []).forEach((f) => { try { f(...args); } catch (e) { console.error(e); } }); }

  _closed() {
    if (!this.alive) return;
    this.alive = false;
    this.emit("close");
  }

  _onData(chunk) {
    this.buffer = Buffer.concat([this.buffer, chunk]);
    while (true) {
      if (this.buffer.length < 2) return;
      const b0 = this.buffer[0];
      const b1 = this.buffer[1];
      const fin = (b0 & 0x80) !== 0;
      const opcode = b0 & 0x0f;
      const masked = (b1 & 0x80) !== 0;
      let len = b1 & 0x7f;
      let offset = 2;
      if (len === 126) {
        if (this.buffer.length < 4) return;
        len = this.buffer.readUInt16BE(2);
        offset = 4;
      } else if (len === 127) {
        if (this.buffer.length < 10) return;
        len = Number(this.buffer.readBigUInt64BE(2));
        offset = 10;
      }
      const maskLen = masked ? 4 : 0;
      if (this.buffer.length < offset + maskLen + len) return;
      const mask = masked ? this.buffer.subarray(offset, offset + 4) : null;
      let payload = this.buffer.subarray(offset + maskLen, offset + maskLen + len);
      if (masked) {
        payload = Buffer.from(payload);
        for (let i = 0; i < payload.length; i++) payload[i] ^= mask[i & 3];
      }
      this.buffer = this.buffer.subarray(offset + maskLen + len);

      if (opcode === 0x8) { this.close(); return; }
      if (opcode === 0x9) { this._write(encodeFrame(payload, 0xa)); continue; }
      if (opcode === 0xa) continue;
      if (opcode === 0x1 || opcode === 0x2) {
        if (!fin) continue; // fragmentation not needed for JSON
        this.emit("message", payload.toString("utf8"));
      }
    }
  }

  _write(buf) {
    if (!this.alive) return false;
    try { this.socket.write(buf); return true; } catch (e) { this._closed(); return false; }
  }

  send(obj) { return this._write(encodeFrame(typeof obj === "string" ? obj : JSON.stringify(obj))); }

  close() {
    if (!this.alive) return;
    try { this.socket.write(encodeFrame(Buffer.alloc(0), 0x8)); } catch (e) {}
    try { this.socket.end(); } catch (e) {}
    this._closed();
  }
}

// ---------------------------------------------------------------------------
// Broker
// ---------------------------------------------------------------------------
const state = {
  startedAt: Date.now(),
  extension: null,        // WsConn
  clients: new Set(),     // WsConn (LLM side)
  logs: [],               // ring of recent activity
  lastState: null,        // last pushed game state summary
  pending: new Map(),     // id -> {resolve, timer}
  seq: 0
};

function log(...args) {
  const line = new Date().toISOString().slice(11, 23) + " " + args.join(" ");
  console.log(line);
  state.logs.push(line);
  if (state.logs.length > 500) state.logs.shift();
}

function nextId() { return "c" + (++state.seq).toString(36) + "-" + Date.now().toString(36); }

function broadcastToClients(obj) {
  for (const c of state.clients) c.send(obj);
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/** Assistant replies the store is holding (completed or streaming). */
async function getLlmReplies(limit) {
  const r = await sendCommandToExtension({ action: "get_state", chatLimit: 0 }, 6000);
  const st = (r.ok && r.result && r.result.state) || {};
  return (st.llmReplies || []).slice(-limit);
}

function sendCommandToExtension(command, timeout = CMD_TIMEOUT_MS) {
  return new Promise((resolve) => {
    if (!state.extension || !state.extension.alive) {
      resolve({ ok: false, error: "extension not connected — open the popup and press Connect (see README)" });
      return;
    }
    const id = command.id || nextId();
    const timer = setTimeout(() => {
      state.pending.delete(id);
      resolve({ ok: false, error: "timeout waiting for the extension", id });
    }, timeout);
    state.pending.set(id, { resolve, timer });
    state.extension.send({ type: "cmd", id, ...command });
    log("→ ext", id, JSON.stringify(command).slice(0, 160));
  });
}

function handleExtensionMessage(conn, raw) {
  let msg;
  try { msg = JSON.parse(raw); } catch (e) { return; }
  if (msg.type === "hello") {
    conn.role = "extension";
    if (state.extension && state.extension !== conn) state.extension.close();
    state.extension = conn;
    log("extension connected", JSON.stringify(msg).slice(0, 120));
    conn.send({ type: "welcome", protocol: 1, server: "eagler-llm-bridge" });
    broadcastToClients({ type: "extension", connected: true });
    // `--enable-inject` (or BRIDGE_ALLOW_INJECT=1) opts the session into
    // protocol-level packet injection. It is still off by default.
    if (process.env.BRIDGE_ALLOW_INJECT === "1" || process.argv.includes("--enable-inject")) {
      conn.send({ type: "cmd", id: nextId(), action: "enable_injection", enabled: true });
      log("packet injection enabled for this session (CLI flag)");
    }
    return;
  }
  if (msg.type === "result") {
    const pending = state.pending.get(msg.id);
    if (pending) {
      clearTimeout(pending.timer);
      state.pending.delete(msg.id);
      pending.resolve({ ok: !!msg.ok, result: msg.result, id: msg.id });
    }
    broadcastToClients(msg);
    return;
  }
  if (msg.type === "state") {
    state.lastState = msg.state;
    broadcastToClients({ type: "state", state: msg.state });
    return;
  }
  if (msg.type === "event") {
    const ev = msg.event || {};
    // Keep a lightweight copy for HTTP /state
    if (ev.type === "state:chat" && state.lastState && ev.payload && ev.payload.entry) {
      state.lastState.chat = (state.lastState.chat || []).concat([ev.payload.entry]).slice(-200);
    }
    broadcastToClients({ type: "event", event: ev });
    if (ev.type !== "state:move" && ev.type !== "packet") log("event", ev.type);
    return;
  }
  if (msg.type === "pong") return;
}

function handleClientMessage(conn, raw) {
  let msg;
  try { msg = JSON.parse(raw); } catch (e) {
    conn.send({ type: "result", id: null, ok: false, result: "invalid JSON" });
    return;
  }
  if (msg.type === "hello") {
    conn.send({ type: "welcome", protocol: 1, server: "eagler-llm-bridge", state: state.lastState });
    return;
  }
  if (msg.type === "ping") { conn.send({ type: "pong", t: msg.t }); return; }
  // Everything else is a command; pass through with a fresh id
  const id = msg.id || nextId();
  sendCommandToExtension({ ...msg, id }).then((res) => {
    conn.send({ type: "result", id, ok: res.ok, result: res.result, error: res.error });
  });
}

// ---------------------------------------------------------------------------
// HTTP endpoints
// ---------------------------------------------------------------------------
function json(res, code, obj) {
  const body = JSON.stringify(obj, null, 2);
  res.writeHead(code, {
    "Content-Type": "application/json; charset=utf-8",
    "Access-Control-Allow-Origin": "http://127.0.0.1",
    "Cache-Control": "no-store"
  });
  res.end(body);
}

function readBody(req, limit = 4 * 1024 * 1024) {
  return new Promise((resolve, reject) => {
    let chunks = [];
    let size = 0;
    req.on("data", (c) => {
      size += c.length;
      if (size > limit) { reject(new Error("body too large")); req.destroy(); return; }
      chunks.push(c);
    });
    req.on("end", () => resolve(Buffer.concat(chunks).toString("utf8")));
    req.on("error", reject);
  });
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || HOST}`);
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Headers", "content-type");

  if (req.method === "OPTIONS") { res.writeHead(204); res.end(); return; }

  if (url.pathname === "/health") {
    return json(res, 200, {
      ok: true,
      uptime_s: Math.round((Date.now() - state.startedAt) / 1000),
      extension: !!(state.extension && state.extension.alive),
      clients: state.clients.size,
      pending: state.pending.size,
      version: 1
    });
  }

  if (url.pathname === "/state") {
    // Ask the extension for a fresh summary; fall back to last push
    const r = await sendCommandToExtension({ action: "get_state", chatLimit: parseInt(url.searchParams.get("chatLimit") || "50", 10) }, 6000);
    if (r.ok) { state.lastState = r.result && r.result.state || state.lastState; return json(res, 200, r.result); }
    return json(res, 200, { ok: false, error: r.error, lastState: state.lastState });
  }

  // ---- the LLM side: the Perchance AI chat --------------------------------
  if (url.pathname === "/llm") {
    const r = await sendCommandToExtension({ action: "get_state", chatLimit: 0 }, 6000);
    const st = (r.ok && r.result && r.result.state) || {};
    return json(res, 200, { ok: !!r.ok, llm: st.llm || null, replies: (st.llmReplies || []).slice(-parseInt(url.searchParams.get("limit") || "20", 10)) });
  }

  if (url.pathname === "/llm/ask" && req.method === "POST") {
    let payload;
    try { payload = JSON.parse(await readBody(req)); } catch (e) { return json(res, 400, { ok: false, error: "invalid JSON body" }); }
    const text = String(payload.text || payload.message || payload.prompt || "");
    if (!text.trim()) return json(res, 400, { ok: false, error: "text is required" });
    const waitMs = Math.max(0, Math.min(180000, Number(payload.waitMs) || 60000));
    const r = await sendCommandToExtension({ action: "llm_say", text, wait: payload.wait !== false }, 15000);
    if (!r.ok) return json(res, 502, r);
    if (payload.wait === false || waitMs === 0) return json(res, 200, { ok: true, sent: text });
    // Poll the store until a completed assistant message newer than the send.
    const started = Date.now();
    const before = (await getLlmReplies(1)).length ? (await getLlmReplies(50)).slice(-1)[0] : null;
    const beforeSeq = before ? before.seq : 0;
    while (Date.now() - started < waitMs) {
      await sleep(700);
      const replies = await getLlmReplies(50);
      const fresh = replies.filter((m) => m.seq > beforeSeq && m.complete);
      if (fresh.length) {
        const m = fresh[fresh.length - 1];
        return json(res, 200, { ok: true, text: m.text, from: m.from, at: m.at, waited_ms: Date.now() - started });
      }
    }
    const partial = (await getLlmReplies(50)).filter((m) => m.seq > beforeSeq).slice(-1)[0];
    return json(res, 200, { ok: true, timedOut: true, partial: partial ? partial.text : null, waited_ms: Date.now() - started });
  }

  if (url.pathname === "/llm/status") {
    const r = await sendCommandToExtension({ action: "llm_status" }, 6000);
    return json(res, r.ok ? 200 : 503, r);
  }

  if (url.pathname === "/chat") {
    const r = await sendCommandToExtension({ action: "get_chat", limit: parseInt(url.searchParams.get("limit") || "50", 10) }, 6000);
    return json(res, r.ok ? 200 : 503, r.ok ? r.result : { ok: false, error: r.error });
  }

  if (url.pathname === "/command" && req.method === "POST") {
    let payload;
    try { payload = JSON.parse(await readBody(req)); } catch (e) { return json(res, 400, { ok: false, error: "invalid JSON body" }); }
    const r = await sendCommandToExtension(payload);
    return json(res, r.ok ? 200 : 502, r);
  }

  if (url.pathname === "/screenshot" && (req.method === "GET" || req.method === "POST")) {
    const width = parseInt(url.searchParams.get("width") || "640", 10);
    const r = await sendCommandToExtension({ action: "screenshot", width }, 8000);
    if (!r.ok) return json(res, 502, r);
    const frame = r.result && r.result.frame;
    if (!frame) return json(res, 404, { ok: false, error: "no frame" });
    if (url.searchParams.get("format") === "json") return json(res, 200, { ok: true, frame });
    const b64 = String(frame.dataUrl).split(",")[1] || "";
    res.writeHead(200, { "Content-Type": "image/jpeg", "Cache-Control": "no-store" });
    return res.end(Buffer.from(b64, "base64"));
  }

  if (url.pathname === "/events") {
    // Server-Sent Events stream of game events for simple LLM clients
    res.writeHead(200, {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-store",
      Connection: "keep-alive"
    });
    const client = { send: (obj) => res.write("data: " + JSON.stringify(obj) + "\n\n") };
    state.clients.add(client);
    const keep = setInterval(() => res.write(": keepalive\n\n"), 15000);
    req.on("close", () => { clearInterval(keep); state.clients.delete(client); });
    return;
  }

  if (url.pathname === "/openapi.json") {
    return json(res, 200, require("./openapi.js").spec(PORT));
  }

  if (url.pathname === "/" || url.pathname === "/docs") {
    res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
    return res.end(require("./docs-page.js").html(PORT));
  }

  return json(res, 404, { ok: false, error: "not found" });
});

// WebSocket upgrade
server.on("upgrade", (req, socket) => {
  const key = req.headers["sec-websocket-key"];
  if (!key) { socket.destroy(); return; }
  const accept = crypto.createHash("sha1").update(key + WS_GUID).digest("base64");
  socket.write(
    "HTTP/1.1 101 Switching Protocols\r\n" +
    "Upgrade: websocket\r\n" +
    "Connection: Upgrade\r\n" +
    `Sec-WebSocket-Accept: ${accept}\r\n\r\n`
  );
  const conn = new WsConn(socket, req);
  // Insert into clients only after hello tells us it is an LLM client; until
  // then treat as client (so raw commands work without a hello).
  state.clients.add(conn);
  log("socket opened from", req.socket.remoteAddress);
  conn.on("message", (raw) => {
    if (conn.role === "extension") return handleExtensionMessage(conn, raw);
    // Detect extension hello
    try {
      const msg = JSON.parse(raw);
      if (msg.type === "hello" && msg.client === "eagler-llm-bridge") {
        state.clients.delete(conn);
        return handleExtensionMessage(conn, raw);
      }
    } catch (e) { /* fallthrough */ }
    handleClientMessage(conn, raw);
  });
  conn.on("close", () => {
    state.clients.delete(conn);
    if (state.extension === conn) {
      state.extension = null;
      log("extension disconnected");
      broadcastToClients({ type: "extension", connected: false });
    }
  });
});

server.listen(PORT, HOST, () => {
  log(`Eagler LLM Bridge host listening on http://${HOST}:${PORT} (ws://${HOST}:${PORT})`);
  log(`endpoints: /health /state /chat /command /screenshot /events /llm /llm/ask /llm/status /openapi.json /docs`);
});

process.on("SIGINT", () => { log("shutting down"); server.close(() => process.exit(0)); });
