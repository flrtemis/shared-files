/*
 * Eagler LLM Bridge — Perchance "game brain" loop.
 *
 * The AI that plays is a Perchance ai-character-chat generator (aiTextPlugin),
 * not a hosted model. This loop connects the two halves of the bridge:
 *
 *   Perchance reply  ->  parse action lines  ->  Minecraft input
 *   Minecraft state  ->  observation text    ->  POST /llm/ask
 *
 * The reply format is deliberately boring so a chat model can stick to it:
 *
 *   say: hello there
 *   walk: forward 1200
 *   look: right
 *   attack
 *   wait
 *
 * Anything else in the reply is treated as speech and sent to Minecraft chat,
 * which is usually what you want from a chatty model.
 *
 *   node llm/perchance-agent.js --goal "you are playing Minecraft..."
 *   node llm/perchance-agent.js --dry-run            # no AI, prints the plan
 *   node llm/perchance-agent.js --once               # one cycle
 */
"use strict";
const http = require("http");

const args = process.argv.slice(2).reduce((a, v, i, all) => {
  if (v.startsWith("--")) {
    const k = v.slice(2);
    const next = all[i + 1];
    a[k] = next && !next.startsWith("--") ? next : true;
  }
  return a;
}, {});

const HOST = process.env.BRIDGE_HOST || "127.0.0.1";
const PORT = parseInt(process.env.BRIDGE_PORT || "8787", 10);
const CYCLE_MS = parseInt(args.interval || "20000", 10);
const ASK_TIMEOUT = parseInt(args.timeout || "60000", 10);

const GOAL = args.goal || [
  "You are playing Minecraft (Eaglercraft 1.8) through a bot bridge.",
  "You see the world as a text summary each turn: health, position, chat, and any recent events.",
  "Reply with short action lines, one per line, then optionally one line of chat.",
  "Actions: say: <text>, walk: forward|back|left|right <ms>, look: left|right|up|down, attack, jump, wait.",
  "Keep it under 6 lines. Example:",
  "look: right",
  "walk: forward 1500",
  "say: heading toward the trees"
].join("\n");

// ---------------------------------------------------------------------------
// HTTP helpers
// ---------------------------------------------------------------------------
function req(method, path, body, timeout = ASK_TIMEOUT + 10000) {
  return new Promise((resolve) => {
    const data = body ? JSON.stringify(body) : null;
    const r = http.request({ host: HOST, port: PORT, path, method, timeout,
      headers: data ? { "content-type": "application/json", "content-length": Buffer.byteLength(data) } : {} },
      (res) => {
        let b = "";
        res.on("data", (c) => (b += c));
        res.on("end", () => { try { resolve(JSON.parse(b)); } catch (e) { resolve({ ok: false, raw: b.slice(0, 200) }); } });
      });
    r.on("error", (e) => resolve({ ok: false, error: e.message }));
    r.on("timeout", () => { r.destroy(); resolve({ ok: false, error: "timeout" }); });
    if (data) r.write(data);
    r.end();
  });
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ---------------------------------------------------------------------------
// State -> observation text
// ---------------------------------------------------------------------------
async function observe() {
  const s = await req("GET", "/state?chatLimit=8", null, 8000);
  const st = (s && s.state) || {};
  const lines = [];
  lines.push(`Health ${st.hud && st.hud.health != null ? st.hud.health : "?"}/20, food ${st.hud && st.hud.food != null ? st.hud.food : "?"}/20`);
  if (st.pos) lines.push(`Position x=${Math.round(st.pos.x)} y=${Math.round(st.pos.y)} z=${Math.round(st.pos.z)}`);
  if (st.username) lines.push(`You are ${st.username}`);
  const chat = (st.chat || []).filter((c) => c.kind !== "llm").slice(-6);
  if (chat.length) {
    lines.push("Chat:");
    for (const c of chat) lines.push(`  ${c.from ? "<" + c.from + ">" : "*"} ${c.text}`);
  }
  const evs = (st.events || []).filter((e) => /death|disconnect|chat|hud/.test(e.type || "")).slice(-4);
  if (evs.length) {
    lines.push("Recent events:");
    for (const e of evs) lines.push(`  ${e.type}`);
  }
  if (!st.connected) lines.push("(not in game yet — waiting for the world to load)");
  return lines.join("\n");
}

// ---------------------------------------------------------------------------
// Reply -> commands
// ---------------------------------------------------------------------------
function parsePlan(reply) {
  const steps = [];
  const text = String(reply || "");
  for (const rawLine of text.split(/\r?\n/)) {
    const line = rawLine.trim().replace(/^[-*]\s*/, "");
    if (!line) continue;
    let m;
    if ((m = line.match(/^say:\s*(.+)$/i))) steps.push({ action: "chat", text: m[1] });
    else if ((m = line.match(/^walk:\s*(forward|back|backward|left|right)\s*(\d{2,5})?/i))) {
      const key = { forward: "w", back: "s", backward: "s", left: "a", right: "d" }[m[1].toLowerCase()];
      steps.push({ action: "key_down", key, duration: Math.min(parseInt(m[2] || "1000", 10), 5000) });
    }
    else if ((m = line.match(/^look:\s*(left|right|up|down)/i))) {
      const d = m[1].toLowerCase();
      steps.push({ action: "look", dx: d === "left" ? -320 : d === "right" ? 320 : 0, dy: d === "up" ? -200 : d === "down" ? 200 : 0 });
    }
    else if (/^attack$/i.test(line)) steps.push({ action: "click", button: "left" });
    else if (/^jump$/i.test(line)) steps.push({ action: "key_tap", key: "space", duration: 120 });
    else if (/^wait$/i.test(line)) steps.push({ action: "wait", ms: 800 });
    else if (/^chat:\s*(.+)$/i.test(line)) steps.push({ action: "chat", text: line.replace(/^chat:\s*/i, "") });
    else if (line.length <= 200 && !/^[a-z]+:/i.test(line)) steps.push({ action: "chat", text: line });
  }
  return steps.slice(0, 12);
}

async function act(steps) {
  const done = [];
  for (const s of steps) {
    const r = await req("POST", "/command", s, 15000);
    done.push({ step: s, ok: !!(r && r.ok !== false) });
    await sleep(s.duration ? Math.min(s.duration, 1500) : 250);
  }
  return done;
}

// ---------------------------------------------------------------------------
// Main loop
// ---------------------------------------------------------------------------
(async () => {
  console.log("Eagler LLM Bridge — Perchance brain");
  console.log("goal seeded into every ask\n" + GOAL + "\n");

  const status = await req("GET", "/llm/status", null, 8000);
  if (!status || status.ok === false) {
    console.log("The Perchance chat is not attached: " + ((status && status.error) || "unknown"));
    console.log("Open the AI chat generator in a tab (e.g. https://perchance.org/g66gcru29s) and retry.");
    process.exit(1);
  }

  let cycle = 0;
  for (;;) {
    cycle++;
    const observation = await observe();
    console.log(`--- cycle ${cycle} ---\n${observation}\n`);

    if (args["dry-run"]) {
      console.log("(dry run) would ask the AI with the text above\n");
      if (args.once) break;
      await sleep(CYCLE_MS);
      continue;
    }

    const prompt = [
      GOAL,
      "",
      "Current situation:",
      observation,
      "",
      "Your action lines:"
    ].join("\n");

    const t0 = Date.now();
    const reply = await req("POST", "/llm/ask", { text: prompt, waitMs: ASK_TIMEOUT }, ASK_TIMEOUT + 15000);
    if (!reply || reply.ok === false) {
      console.log("ask failed: " + ((reply && (reply.error || reply.result)) || "no reply") + "\n");
      if (args.once) break;
      await sleep(CYCLE_MS);
      continue;
    }

    const text = reply.text || reply.partial || "";
    console.log(`AI (${Date.now() - t0} ms):\n${text}\n`);

    const steps = parsePlan(text);
    if (steps.length) console.log("plan:", JSON.stringify(steps));
    const applied = await act(steps);
    if (applied.length) console.log("applied:", applied.filter((a) => a.ok).length + "/" + applied.length, "\n");

    if (args.once) break;
    await sleep(CYCLE_MS);
  }
  process.exit(0);
})();
