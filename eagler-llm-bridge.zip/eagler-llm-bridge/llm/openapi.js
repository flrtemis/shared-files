/*
 * OpenAPI 3.0 schema for the local bridge. Served at /openapi.json.
 * Kept dependency-free so the bridge host can require() it directly.
 */
"use strict";

exports.spec = function spec(port) {
  const base = "http://127.0.0.1:" + (port || 8787);
  return {
    openapi: "3.0.3",
    info: {
      title: "Eagler LLM Bridge",
      version: "1.0.0",
      description:
        "Local-only bridge between an LLM and an Eaglercraft (Minecraft 1.8) session running inside the Eagler LLM Bridge Chrome extension. " +
        "Commands are JSON objects; state is scraped from the game's network stream, its canvas, and the extension's UI."
    },
    servers: [{ url: base }],
    paths: {
      "/health": {
        get: {
          operationId: "health",
          summary: "Bridge and extension status",
          responses: { "200": { description: "Status", content: { "application/json": { schema: { type: "object", properties: { ok: { type: "boolean" }, extension: { type: "boolean" }, clients: { type: "integer" } } } } } } }
        }
      },
      "/state": {
        get: {
          operationId: "getState",
          summary: "Current game state: chat tail, HUD, position, agents",
          parameters: [{ name: "chatLimit", in: "query", schema: { type: "integer", default: 50 } }],
          responses: { "200": { description: "State snapshot", content: { "application/json": { schema: { $ref: "#/components/schemas/State" } } } } }
        }
      },
      "/chat": {
        get: {
          operationId: "getChat",
          summary: "Recent chat log",
          parameters: [{ name: "limit", in: "query", schema: { type: "integer", default: 50 } }],
          responses: { "200": { description: "Chat entries", content: { "application/json": { schema: { type: "object", properties: { chat: { type: "array", items: { $ref: "#/components/schemas/ChatEntry" } } } } } } } }
        }
      },
      "/command": {
        post: {
          operationId: "sendCommand",
          summary: "Send one JSON command (see components.schemas.Command)",
          requestBody: { required: true, content: { "application/json": { schema: { $ref: "#/components/schemas/Command" } } } },
          responses: { "200": { description: "Command result", content: { "application/json": { schema: { type: "object", properties: { ok: { type: "boolean" }, result: { type: "object" } } } } } } }
        }
      },
      "/screenshot": {
        get: {
          operationId: "screenshot",
          summary: "Capture the game canvas (JPEG). Use ?format=json to get a data URL.",
          parameters: [
            { name: "width", in: "query", schema: { type: "integer", default: 640 } },
            { name: "format", in: "query", schema: { type: "string", enum: ["jpeg", "json"] } }
          ],
          responses: { "200": { description: "Image bytes or JSON", content: { "image/jpeg": {}, "application/json": {} } } }
        }
      },
      "/events": {
        get: {
          operationId: "events",
          summary: "Server-Sent Events stream of game events (chat, vitals, movement, transcripts)",
          responses: { "200": { description: "text/event-stream" } }
        }
      }
    },
    components: {
      schemas: {
        ChatEntry: {
          type: "object",
          properties: {
            at: { type: "string", format: "date-time" },
            kind: { type: "string", enum: ["chat", "system", "actionbar"] },
            from: { type: "string", nullable: true },
            text: { type: "string" }
          }
        },
        State: {
          type: "object",
          properties: {
            connected: { type: "boolean" },
            handshakeDone: { type: "boolean" },
            server: { type: "string", nullable: true },
            username: { type: "string", nullable: true },
            hud: {
              type: "object",
              properties: { health: { type: "number" }, food: { type: "integer" }, xp: { type: "object" }, header: { type: "string" } }
            },
            pos: { type: "object", properties: { x: { type: "number" }, y: { type: "number" }, z: { type: "number" }, yaw: { type: "number" }, pitch: { type: "number" } } },
            chat: { type: "array", items: { $ref: "#/components/schemas/ChatEntry" } }
          }
        },
        Command: {
          type: "object",
          required: ["action"],
          properties: {
            id: { type: "string" },
            action: {
              type: "string",
              enum: [
                "key_down", "key_up", "key_tap", "type", "chat", "command", "look", "mouse_move",
                "mouse_down", "mouse_up", "click", "wheel", "wait", "release_all", "sequence",
                "packet", "get_state", "get_chat", "changes", "screenshot", "status", "attach",
                "set_settings", "start_audio_transcription", "stop_audio_transcription",
                "llm_say", "llm_ask", "llm_status", "llm_stop", "llm_messages"
              ]
            },
            key: { type: "string", description: "w, a, s, d, space, shift, KeyW, 87 ..." },
            duration: { type: "integer", description: "ms to hold, used by key_down/key_tap" },
            text: { type: "string", description: "for type/chat" },
            dx: { type: "integer", description: "mouse-look delta X" },
            dy: { type: "integer", description: "mouse-look delta Y" },
            button: { type: "string", enum: ["left", "right", "middle"] },
            deltaY: { type: "integer", description: "scroll wheel delta" },
            ms: { type: "integer" },
            steps: { type: "array", items: { $ref: "#/components/schemas/Command" } },
            llm: {
              type: "object",
              description:
                "LLM actions talk to the Perchance AI chat in the open tab: llm_say sends text as a user message, " +
                "llm_ask sends a prompt and returns the reply, llm_status reports attachment, llm_messages reads recent turns."
            },
            message: { type: "string", description: "llm_say / llm_ask: the text to send to the AI" },
            timeoutMs: { type: "integer", description: "llm_ask: how long to wait for a reply (default 120000)" },
            limit: { type: "integer", description: "llm_messages: how many turns to return" },
            name: { type: "string", description: "packet name for action=packet (chat, use_entity, held_item_change, ...)" },
            args: { type: "object" }
          }
        }
      }
    }
  };
};
