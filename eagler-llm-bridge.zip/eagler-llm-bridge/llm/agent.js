#!/usr/bin/env node
/*
 * Eagler LLM Bridge — reference LLM agent loop.
 *
 * Demonstrates the full cycle the brief asks for:
 *
 *   1. OBSERVE  -> GET /state  (+ /screenshot for vision models)
 *   2. THINK    -> ask the LLM what to do, with the game state in the prompt
 *   3. ACT      -> POST /command with the JSON packet it produced
 *   4. repeat
 *
 * Works with any OpenAI-compatible chat endpoint (OpenAI, Ollama, LM Studio,
 * vLLM, llama.cpp server...). No SDK required.
 *
 *   OPENAI_API_KEY=sk-... node llm/agent.js --goal "chop one tree and say hi in chat"
 *   node llm/agent.js --goal "..." --base-url http://127.0.0.1:11434/v1 --model llama3.1
 *   node llm/agent.js --goal "..." --provider anthropic       # uses ANTHROPIC_API_KEY
 *   node llm/agent.js --dry-run                               # no LLM: print the state it would send
 *
 * The system prompt is intentionally small and explicit; the tool schemas in
 * llm/tools/ carry the details.
 */
"use strict";

const { Bridge } = require("./client.js");
const fs = require("fs");
const path = require("path");

const args = parseArgs(process.argv.slice(2));
const PROVIDER = args.provider || (process.env.ANTHROPIC_API_KEY && !process.env.OPENAI_API_KEY ? "anthropic" : "openai");
const BASE_URL = args["base-url"] || process.env.OPENAI_BASE_URL || "https://api.openai.com/v1";
const MODEL = args.model || (PROVIDER === "anthropic" ? "claude-3-5-sonnet-latest" : "gpt-4o-mini");
const MAX_TURNS = parseInt(args.turns || "12", 10);
const GOAL = args.goal || "Look around, check the chat, and report what is happening in one sentence.";
const VISION = args.vision === "true";

const bridge = new Bridge();

function parseArgs(argv) {
  const out = {};
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a.startsWith("--")) {
      const k = a.slice(2);
      const next = argv[i + 1];
      if (next != null && !next.startsWith("--")) { out[k] = next; i++; }
      else out[k] = "true";
    }
  }
  return out;
}

// ---------------------------------------------------------------------------
// Tool definitions -> bridge commands
// ---------------------------------------------------------------------------
const TOOLS = JSON.parse(fs.readFileSync(path.join(__dirname, "tools", PROVIDER === "anthropic" ? "anthropic-tools.json" : "openai-tools.json"), "utf8"));

async function executeTool(name, input) {
  switch (name) {
    case "eagler_observe": {
      const s = await bridge.state(input.chatLimit || 40);
      if (input.includeScreenshot) {
        const shot = await bridge.screenshot(560);
        s.screenshot = shot && shot.frame ? shot.frame.dataUrl : null;
      }
      return s;
    }
    case "eagler_press":
      return input.duration != null
        ? bridge.cmd({ action: "key_down", key: input.key, duration: input.duration })
        : bridge.cmd({ action: "key_tap", key: input.key });
    case "eagler_release": return bridge.cmd({ action: "key_up", key: input.key });
    case "eagler_send_chat": return bridge.cmd({ action: "chat", text: input.text });
    case "eagler_command": return bridge.cmd({ action: "command", text: input.command });
    case "eagler_look": return bridge.cmd({ action: "look", dx: input.dx || 0, dy: input.dy || 0 });
    case "eagler_mouse":
      return bridge.cmd({ action: input.down ? "mouse_down" : "mouse_up", button: input.button || "left" });
    case "eagler_sequence": return bridge.cmd({ action: "sequence", steps: input.steps || [] });
    // The Perchance AI chat as a sub-brain: the agent can ask it for a plan in
    // words and then carry that plan out with the action tools above.
    case "eagler_ask_ai": return bridge.cmd({ action: "llm_ask", message: input.message, timeoutMs: input.timeoutMs });
    case "eagler_say_to_ai": return bridge.cmd({ action: "llm_say", message: input.message });
    case "eagler_ai_status": return bridge.cmd({ action: "llm_status" });
    case "eagler_ai_messages": return bridge.cmd({ action: "llm_messages", limit: input.limit });
    case "eagler_screenshot": {
      const shot = await bridge.screenshot(input.width || 640);
      return { ok: !!(shot && shot.ok), frame: shot && shot.frame };
    }
    default:
      return { ok: false, error: "unknown tool " + name };
  }
}

function openAITools() {
  return TOOLS;
}

function anthropicTools() {
  return TOOLS;
}

// ---------------------------------------------------------------------------
// LLM calls
// ---------------------------------------------------------------------------
async function callOpenAI(messages) {
  const body = {
    model: MODEL,
    messages,
    tools: openAITools(),
    tool_choice: "auto",
    temperature: 0.2
  };
  if (!VISION) body.messages = messages.map(stripImages);
  const res = await fetch(BASE_URL.replace(/\/$/, "") + "/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": "Bearer " + (process.env.OPENAI_API_KEY || "local")
    },
    body: JSON.stringify(body)
  });
  if (!res.ok) throw new Error("LLM HTTP " + res.status + ": " + (await res.text()).slice(0, 400));
  const json = await res.json();
  return json.choices[0].message;
}

function stripImages(m) {
  if (typeof m.content === "string") return m;
  if (Array.isArray(m.content)) {
    return { ...m, content: m.content.map((c) => (c.type === "image_url" ? { type: "text", text: "[screenshot omitted: set --vision true]" } : c)) };
  }
  return m;
}

async function callAnthropic(messages, system) {
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": process.env.ANTHROPIC_API_KEY,
      "anthropic-version": "2023-06-01"
    },
    body: JSON.stringify({
      model: MODEL,
      max_tokens: 1024,
      system,
      tools: anthropicTools(),
      messages
    })
  });
  if (!res.ok) throw new Error("LLM HTTP " + res.status + ": " + (await res.text()).slice(0, 400));
  return res.json();
}

const SYSTEM = `You are controlling a Minecraft 1.8 player (Eaglercraft) through a tool bridge.
Rules:
- Always call eagler_observe before your first action and after anything important.
- Prefer many small actions (e.g. key_tap w, look a bit, observe) over long holds; you cannot see continuously.
- Movement keys: w forward, s back, a left, d right, space jump, shift sneak. Look with small dx/dy nudges (30-120).
- To coordinate with humans, use eagler_send_chat, and read the chat field in observations.
- If a command fails, read the error, adapt, and try a different approach. Never loop on the same failing call.
- When the goal is done, reply with a one-line summary and stop calling tools.`;

function stateToPrompt(state) {
  if (!state || !state.state) return "No state available — is the extension attached? Call eagler_observe and report the error.";
  const s = state.state;
  const lines = [];
  lines.push("ATTACHED: " + (s.connected ? "yes" : "no") + (s.ready === false ? " (game still loading)" : ""));
  lines.push("USERNAME: " + (s.username || "?") + "  SERVER: " + (s.server || "?"));
  if (s.pos) lines.push(`POSITION: x=${round(s.pos.x)} y=${round(s.pos.y)} z=${round(s.pos.z)} yaw=${round(s.pos.yaw)} pitch=${round(s.pos.pitch)}`);
  if (s.hud) {
    const h = s.hud;
    lines.push(`VITALS: health=${h.health ?? "?"} food=${h.food ?? "?"} xp=${h.xp ? h.xp.level : "?"}`);
    if (h.footer) lines.push("TAB FOOTER: " + h.footer);
    if (h.header) lines.push("TAB HEADER: " + h.header);
  }
  const chat = (state.chat || s.chat || []).slice(-25);
  if (chat.length) {
    lines.push("RECENT CHAT:");
    for (const c of chat) lines.push(`  [${c.kind || "chat"}] ${c.from ? c.from + ": " : ""}${c.text}`);
  } else {
    lines.push("RECENT CHAT: (none yet)");
  }
  return lines.join("\n");
}

function round(v) { return typeof v === "number" ? Math.round(v * 10) / 10 : v; }

// ---------------------------------------------------------------------------
// Main loop
// ---------------------------------------------------------------------------
async function main() {
  console.log("bridge:", await bridge.health());
  if (args["dry-run"]) {
    const s = await bridge.state(40);
    console.log("\n--- observation the LLM would receive ---\n");
    console.log(stateToPrompt(s));
    return;
  }

  const started = Date.now();
  console.log(`\nGOAL: ${GOAL}\nprovider=${PROVIDER} model=${MODEL} vision=${VISION} turns=${MAX_TURNS}\n`);

  const transcript = [];
  let observation = await bridge.state(40);
  if (VISION && observation.state) {
    const shot = await bridge.screenshot(560);
    observation.screenshot = shot && shot.frame && shot.frame.dataUrl;
  }

  if (PROVIDER === "anthropic") {
    const messages = [];
    for (let turn = 0; turn < MAX_TURNS; turn++) {
      const content = [{ type: "text", text: "OBSERVATION\n" + stateToPrompt(observation) + "\n\nGOAL: " + GOAL }];
      if (VISION && observation.screenshot) {
        content.push({ type: "image", source: { type: "base64", media_type: "image/jpeg", data: observation.screenshot.split(",")[1] } });
      }
      messages.push({ role: "user", content });
      const reply = await callAnthropic(messages, SYSTEM);
      messages.push({ role: "assistant", content: reply.content });
      const toolUses = reply.content.filter((c) => c.type === "tool_use");
      const textParts = reply.content.filter((c) => c.type === "text").map((c) => c.text).join(" ");
      if (textParts) console.log("LLM:", textParts);
      if (!toolUses.length) break;
      const results = [];
      for (const tu of toolUses) {
        console.log(" → tool", tu.name, JSON.stringify(tu.input).slice(0, 200));
        const r = await executeTool(tu.name, tu.input);
        results.push({ type: "tool_result", tool_use_id: tu.id, content: JSON.stringify(r).slice(0, 6000) });
      }
      messages.push({ role: "user", content: results });
      observation = await bridge.state(40);
      if (VISION && observation.state) {
        const shot = await bridge.screenshot(560);
        observation.screenshot = shot && shot.frame && shot.frame.dataUrl;
      }
    }
  } else {
    const messages = [{ role: "system", content: SYSTEM }];
    for (let turn = 0; turn < MAX_TURNS; turn++) {
      const userContent = "OBSERVATION\n" + stateToPrompt(observation) + "\n\nGOAL: " + GOAL;
      if (VISION && observation.screenshot) {
        messages.push({ role: "user", content: [
          { type: "text", text: userContent },
          { type: "image_url", image_url: { url: observation.screenshot } }
        ]});
      } else {
        messages.push({ role: "user", content: userContent });
      }
      const msg = await callOpenAI(messages);
      messages.push(msg);
      if (msg.content) console.log("LLM:", msg.content);
      const calls = msg.tool_calls || [];
      if (!calls.length) break;
      for (const call of calls) {
        let input = {};
        try { input = JSON.parse(call.function.arguments || "{}"); } catch (e) {}
        console.log(" → tool", call.function.name, JSON.stringify(input).slice(0, 200));
        const r = await executeTool(call.function.name, input);
        messages.push({ role: "tool", tool_call_id: call.id, content: JSON.stringify(r).slice(0, 8000) });
      }
      observation = await bridge.state(40);
      if (VISION && observation.state) {
        const shot = await bridge.screenshot(560);
        observation.screenshot = shot && shot.frame && shot.frame.dataUrl;
      }
    }
  }

  console.log(`\ndone in ${Math.round((Date.now() - started) / 1000)}s`);
}

if (require.main === module) {
  main().catch((e) => { console.error("agent error:", e.message); process.exit(1); });
}

module.exports = { executeTool, stateToPrompt, SYSTEM };
