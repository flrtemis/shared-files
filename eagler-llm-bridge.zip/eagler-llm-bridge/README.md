# Eagler LLM Bridge

A Chrome (MV3) extension plus a local bridge process that lets an LLM **play Eaglercraft** —
the Minecraft 1.8 client embedded on [nite.games](https://nite.games/game/minecraft) — through plain JSON.

```
 LLM / agent code
       │  JSON over ws://127.0.0.1:8787  (or POST /command)
       ▼
 llm/ws-bridge.js          local-only server (binds 127.0.0.1)
       │  WebSocket
       ▼
 extension service worker  routes commands, keeps game state
       │  chrome.scripting / messages
       ▼
 content script (nite.games)  has host permissions for BOTH origins
       │  window.postMessage (nonce-token gated)
       ▼
 page agent in the GAME frame (gnhustgames.org/eaglercraft-source/)
   ├─ keyboard/mouse injection into the real engine listeners
   ├─ WebSocket sniffer → Minecraft 1.8 packets (chat, HUD, position)
   └─ canvas capture → JPEG frames for vision models
```

Everything runs on your machine. The bridge host listens on `127.0.0.1` only; the extension has no
telemetry and contacts no server except the game itself and your local bridge.

---

## What it does (requirement by requirement)

| Requirement | Implementation |
|---|---|
| **Input bridge** — JSON → simulated keys in the iframe | `page/page-bridge.js`. Keyboard events are dispatched at the game frame's `window` (where EaglercraftX actually attaches `keydown/keyup/keypress`, verified in the shipped `classes.js`), with legacy `keyCode`/`which` defined — the client reads `e.which`. Mouse events go to the render canvas with `movementX/Y` for look. `{"action":"key_down","key":"w","duration":1000}` presses W, then auto-releases after 1 s. |
| **State observer** — real-time text back to the LLM | Eaglercraft renders everything in WebGL, so there is no DOM chat to scrape. The agent wraps `window.WebSocket` *before the client boots* and decodes both directions: the EAG handshake (to learn your username) and vanilla **Minecraft protocol 47** packets — chat, health/food, XP, position, tab-list header/footer, scoreboard, deaths, disconnects. Canvas frames are captured for vision. |
| **Privileged access / CORS** | `host_permissions` for `nite.games` **and** `gnhustgames.org`; the service worker injects the agent into every frame with `chrome.scripting` (`world: "MAIN"`), so the cross-origin game frame's `window` is reachable even though page JS could never do this. Page↔content messaging is gated by a per-frame nonce token so other page scripts cannot forge commands. |
| **Local API / websocket** | `llm/ws-bridge.js` — dependency-free HTTP + WebSocket server on `127.0.0.1:8787`. Endpoints `/state`, `/chat`, `/command`, `/screenshot`, `/events` (SSE), `/openapi.json`, and `/` docs page. Tool schemas for OpenAI and Anthropic are in `llm/tools/`. |

---

## Install

### 1. Load the extension

1. Open `chrome://extensions`, enable **Developer mode**.
2. **Load unpacked** → pick this folder (`eagler-llm-bridge/`).
3. Pin the extension, click it → **Attach** (or just open the game; auto-attach is on by default).

### 2. Start the local bridge

```bash
node llm/ws-bridge.js            # http://127.0.0.1:8787
node llm/ws-bridge.js --enable-inject   # + allow packet injection (see below)
```

No `npm install` needed for the bridge — it uses only Node builtins.

### 3. Open the game

Go to <https://nite.games/game/minecraft>. The extension finds the Eaglercraft iframe
(`gnhustgames.org/eaglercraft-source/`), injects the agent, and starts streaming state.

Click **Connect** in the popup if the bridge host was started after the extension.

---

## Send commands

### HTTP

```bash
curl -X POST http://127.0.0.1:8787/command \
  -H 'content-type: application/json' \
  -d '{"action":"key_down","key":"w","duration":1000}'

curl http://127.0.0.1:8787/state            # chat tail, vitals, position
curl http://127.0.0.1:8787/chat?limit=20
curl -o screen.jpg http://127.0.0.1:8787/screenshot?width=800
curl -N http://127.0.0.1:8787/events        # SSE stream
```

### WebSocket

```js
const ws = new WebSocket("ws://127.0.0.1:8787");
ws.onopen = () => ws.send(JSON.stringify({ id: "1", action: "chat", text: "hello" }));
ws.onmessage = (e) => console.log(JSON.parse(e.data)); // {type:"result",id:"1",ok:true,...}
// events arrive as {type:"event",event:{type:"state:chat",payload:{entry:{...}}}}
```

### Actions

| action | fields | effect |
|---|---|---|
| `key_down` / `key_up` / `key_tap` | `key`, `duration` | `w a s d space shift enter esc t e 1..9`, or `KeyW`, or `87` |
| `type` | `text`, `delay` | types characters through the engine's keyboard handler |
| `chat` / `command` | `text` | opens chat (T), types, Enter; `command` adds a leading `/` |
| `look` / `mouse_move` | `dx`, `dy`, `steps` | mouse-look deltas (compensated pair, see below) |
| `mouse_down` / `mouse_up` / `click` | `button` | attack / use / menus |
| `wheel` | `deltaY` | hotbar scroll fallback |
| `wait` | `ms` | pause inside a sequence |
| `sequence` | `steps[]` | run many actions without round-trips |
| `packet` | `name`, `args` | **opt-in** raw protocol packet (`chat`, `use_entity`, `held_item_change`, `entity_action`, `player_abilities`, `client_settings`, …) |
| `get_state` / `get_chat` / `changes` / `screenshot` / `status` | | read-back for the LLM |
| `attach` / `set_settings` | | tab + capture configuration |
| `llm_say` | `message` | send text into the Perchance AI chat (no reply awaited) |
| `llm_ask` | `message`, `timeoutMs` | ask the Perchance AI chat, return its reply |
| `llm_status` / `llm_messages` | `limit` | is the AI attached; read recent turns |

### Give it to an LLM

`llm/tools/openai-tools.json` and `llm/tools/anthropic-tools.json` are ready to paste into a
tool-calling request. `llm/agent.js` is a complete reference loop (OpenAI-compatible or Anthropic):

```bash
OPENAI_API_KEY=sk-... node llm/agent.js --goal "say hi in chat, then walk forward 2 seconds"
node llm/agent.js --goal "..." --base-url http://127.0.0.1:11434/v1 --model llama3.1   # Ollama
node llm/agent.js --provider anthropic --goal "..."
node llm/agent.js --goal "..." --vision true    # attaches canvas JPEGs for vision models
node llm/agent.js --dry-run                     # print the exact observation it would send
```

---

## How the tricky parts work

**Where the game actually lives.** `https://nite.games/embed/minecraft` is a React SPA; the game is
an iframe to `https://gnhustgames.org/eaglercraft-source/` (EaglercraftX 1.8, TeaVM→JS, WebGL).
Chat is drawn into a canvas, so **there is no DOM to scrape** — hence the packet sniffer.

**Input.** In `classes.js`, `keydown/keyup/keypress` are attached to `window` and read `e.which`;
mouse look reads `e.movementX/Y` on the canvas. The bridge dispatches exactly one synthetic event per
key action at `window` (dispatching at the canvas too would bubble and double every keystroke), with
`keyCode`/`which` defined via getters because `KeyboardEvent` construction ignores them.
Synthetic events are `isTrusted:false`; the real client accepts them (verified live: an injected key
advanced the disclaimer screen and the main menu reacted).

**Look.** Chromium refuses to re-lock the pointer for synthetic events, so when the engine drops one
delta as a lock artifact the agent sends the compensated pair the engine expects
(`-dx,-dy` then `+dx,+dy`); the engine applies the second one.

**Chat.** `chat` is a real macro: T opens chat, characters are typed through the same handler, Enter
sends. With injection enabled the LLM can alternatively send the raw `chat` packet over the live socket.

**State.** The sniffer tees both directions of the game's WebSocket (`send` and `message`) without
touching the traffic. Frames are unmasked if needed and decoded one packet per frame. Chat components
(including `translate`/`with`) are flattened to plain text, `§` codes stripped, and speakers extracted
(`<Alex> …`, `Alex: …`).

### The EAG handshake (verified against live servers)

Protocol ids and layouts follow lax1dude's reference implementation —
`HandshakePacketTypes.java`, `WebSocketEaglerInitialHandler.java` and `HandshakerV1`–`V5.java`
(`lax1dude/eaglerxserver`), cross-checked against the client half
(`Eaglercraft-Archive/EaglercraftX-1_8-workspace`, `HandshakerHandler.java`, `HandshakerV5.java`).

| id | direction | packet | layout |
|----|-----------|--------|--------|
| `0x01` | C→S | `client_version` | `u8 0x02` legacy byte, `u16 n` + `n×u16` EAG versions, `u16 m` + `m×u16` MC versions (47), `u8+ASCII` brand, `u8+ASCII` version, `bool` auth, `u8+ASCII` **auth username** |
| `0x02` | S→C | `server_version` | `u16` EAG version, `u16` MC version, `u8+ASCII` brand, `u8+ASCII` version, `u8` auth method, `u16` salt, `[V5] bool` nickname selection |
| `0x04` | C→S | `request_login` | `u8+ASCII` name (**empty** unless nickname selection), `u8+ASCII` server, `u8` pw, `bool` cookie, `u8` cookie, `VarInt` capability mask, `VarInt×bits`, `u8` ext caps |
| `0x05` | S→C | `allow_login` | `u8+ASCII` name, `16B` UUID, `VarInt` mask, `bitcount` version bytes, `u8` ext caps |
| `0x06` / `0x03` / `0x0A` / `0xFF` | S→C | `deny_login` / `version_mismatch` / `redirect` / `error` | `u16`-length UTF-8 message (error adds a `u8` code) |
| `0x07` / `0x08` | C→S | `profile_data` / `finish_login` | optional key/value; `finish_login` is one byte |
| `0x09` | S→C | `server_finish` | one byte — handshake over, vanilla 1.8 play starts |

Two details bite hard, and both are covered by tests:

1. The legacy byte `0x02` after `0x01` is **required**; without it servers read an empty version
   list and silently drop the connection.
2. The offline username lives in `client_version`'s auth-username field — `request_login`'s name is
   only honoured when the server turns nickname selection on, and it must otherwise be zero-length.
   `profile_data` is optional, and stock EaglercraftXServer rejects an unknown profile key with
   `Invalid Packet`, so the bridge sends `finish_login` directly.

Verified live: five public EaglercraftX servers (`mc.zyth.me`, `zentic.cc`, `play.heartsmp.net`,
`tuff.ws`, `eagler.totalfreedom.tf`) complete the handshake and reach play state.

**Blocked input edge case.** If the human presses Escape, the engine shows its pause menu and needs a
physical click ("Back to game") before pointer lock can be re-acquired. No synthetic event can do
that (Chromium requires real user activation), and a machine proxy sitting under the human would lock
the human out entirely. So the bridge does the honest thing: `status` reports `pointerLocked:false`,
and the LLM should ask the human to click, or use `packet` / `command` actions which do not need
pointer lock (chat, `/tp`, attacks via `use_entity`, sneak via `entity_action`).

**Voice chat** (Eaglercraft has WebRTC voice): the extension ships the capture plumbing
(`chrome.tabCapture` via the offscreen document + SpeechRecognition, results labelled `unverified`),
but this path is best-effort and off unless you call `start_audio_transcription` — Chrome's
recognizer is server-backed, so it is not silent.

---

## Tests

```bash
node test/run-tests.js            # 46 checks, offline
node test/perchance-tests.js      # 15 checks, Perchance adapter against a fixture page
node test/perchance-e2e.js        #  6 checks, AI reply -> plan -> game, end to end
node test/brain-e2e.js            #  8 checks, full loop: state -> AI chat -> plan -> game -> socket
node test/nested-embed.js         #  3 checks, game two iframes deep (nite.games shape)
node test/e2e-real.js             # live against nite.games (needs network, Chromium, Xvfb)
node test/live-handshake.js       # real EaglercraftX servers, no browser needed
node test/live-handshake-state.js # live nite.games handshake read through the extension
```

Suites that drive a browser need `xvfb-run -a` on a headless machine and find Chromium
automatically (override with `CHROME_BIN`).

`run-tests.js` exercises, against **real packet bytes** and a mock Eaglercraft server that speaks the
EAG handshake:

- the 1.8 decoder (chat components, join game, position, health, tab header, scoreboard, handshake,
  truncated-packet robustness)
- the page agent in a real browser: key down/up/duration release, compensated look, chat macro
  (text actually arrives at the mock server), sniffer decoding server chat/HUD/position/username,
  canvas capture JPEG, snapshot shape, injection gate, token enforcement.

`e2e-real.js` loads the actual extension unpacked into Chromium, opens the real nite.games page, and
asserts the full chain: service worker → content script → injected game-frame agent → real client
screens changing after a synthetic key → `/state`, `/command`, `/screenshot` over the local host.

All green: **46/46** offline, **20/20** live, and `live-handshake.js` decodes real
`server_version` frames plus `join_game`/`keep_alive` play packets from five public servers.

---

## Security notes

- The bridge binds `127.0.0.1` only; it has no auth because it is local-only. Do not expose it.
- Page scripts cannot drive the agent: every command carries a per-frame nonce minted by the content
  script. Verified by a test that posts a bad-token command and asserts nothing happens.
- Packet injection is off by default (popup **Options** or `--enable-inject`), limited to an
  allowlist, and only works while you are in-game.
- The extension strips `X-Frame-Options`/CSP `frame-ancestors` **for the game frame only**, so the
  Eaglercraft page can be embedded where you want it.
- This automates a game client. Servers may forbid automation; use it on servers you are allowed to.

---

## Layout

```
manifest.json            MV3, permissions for both origins
background/
  service-worker.js      hub: WS client to the local host, routing, self-test
  tab-manager.js         frame injection (chrome.scripting), command RPC
  state-store.js         chat/HUD/position/frames, read models for the LLM
  ws-client.js           bridge-host protocol, reconnect
  commands.js            validation + normalization of every JSON action
  rules.js               header stripping for embedding the game frame
content/content.js       relay + token + frame discovery (top frame)
content/game-frame-boot.js  loads the agent early in every game frame
page/page-bridge.js      MAIN-world agent: input, sniffer, capture, injection
page/perchance-bridge.js the AI chat adapter: types state in, reads replies out
page/v1_8_parser.js      Minecraft 1.8 + EAG decoder (shared with tests)
offscreen/               tabCapture + speech-recognition host
popup/, options/         status, self-test, settings
llm/ws-bridge.js         local HTTP + WebSocket server (no dependencies)
llm/agent.js             reference LLM tool-use loop
llm/perchance-agent.js   the loop driven by the Perchance AI chat (no API key)
llm/tools/               OpenAI + Anthropic tool schemas
test/                    unit, mock-server, browser-integration, live e2e
```
