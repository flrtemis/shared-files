/*
 * Eagler LLM Bridge — MAIN-world page agent.
 *
 * Injected (by the content script) into:
 *   - nite.games pages: the top document, so it can reach into the game frame
 *   - the game frame itself (gnhustgames.org/eaglercraft-source/): directly
 *
 * What it does here (inside the page's own JS realm, i.e. privileged access
 * without touching chrome.* APIs):
 *
 *  1. INPUT: dispatches Keyboard/Mouse/Wheel events at `window` (keyboard) and
 *     the game canvas (mouse) through the same paths the client already
 *     listens on. Synthetic events are accepted by EaglercraftX (keyCode from
 *     `e.which`, single-char key from `e.key`, movementX/Y for look).
 *
 *  2. STATE (network): wraps window.WebSocket before the client boots. The
 *     wrapper transparently sniffs both directions, re-assembles EAG handshake
 *     packets, then decodes vanilla 1.8 packets — chat, health, position,
 *     scoreboard, tab list, etc. Nothing is modified on the wire unless the
 *     mirror/barrier mode is armed (then only the LLM's own connection is
 *     rerouted).
 *
 *  3. STATE (pixels + audio): periodic canvas capture (for vision models) and
 *     an audio bridge node that routes the client's output through an
 *     AudioWorklet running on a SharedArrayBuffer ring so the offscreen
 *     document can transcribe what players say without any tabCapture prompt.
 *
 *  4. MOUSE-LOOK bridge: Chromium refuses to re-lock the pointer for synthetic
 *     events, so when the bridge asks the only human move the API cannot make
 *     (clicking "Back to game"), it emits a `look` command built from the same
 *     movement deltas the engine would have received.
 *
 * Communication: content script <-> this agent over window.postMessage with a
 * per-frame secret nonce token, so hostile page scripts cannot forge commands.
 */
(function () {
  "use strict";
  if (window.__EAGLER_LLM_BRIDGE_MAIN__) return;
  window.__EAGLER_LLM_BRIDGE_MAIN__ = true;

  // ---------------------------------------------------------------------------
  // Locate the parser. In the game frame it is a <script> sibling; on the
  // nite.games side we inject it with the chrome API through the content
  // script before this file runs.
  // ---------------------------------------------------------------------------
  var V = window.EaglerV18;
  if (!V && typeof __EAGLER_V18_SRC__ === "string") {
    var mod = { exports: {} };
    // eslint-disable-next-line no-new-func
    new Function("module", "exports", __EAGLER_V18_SRC__)(mod, mod.exports);
    V = window.EaglerV18 = mod.exports;
  }
  if (!V) {
    console.warn("[eagler-bridge] v1_8_parser.js not present; packet sniffing disabled");
  }

  var IS_GAME_FRAME = !!V && (
    /gnhustgames\.org$/i.test(location.hostname || "") ||
    window.__EAGLER_BRIDGE_FORCE_GAME_FRAME__ === true // local test harness
  );

  // ---------------------------------------------------------------------------
  // Message bus with nonce token
  // ---------------------------------------------------------------------------
  var TOKEN = null;         // set by the first handshake from the content script
  var TRUSTED_SOURCE = null; // window we accept messages from (parent in game frame)
  var started = false;

  function post(type, payload) {
    var msg = { source: "eagler-llm-bridge-page", type: type, token: TOKEN, payload: payload || {} };
    // Address the top document, not just the parent: the content script only
    // runs in the top frame, so in a two-level embed (site -> wrapper -> game)
    // posting to the parent lands in a wrapper nobody listens to. postMessage
    // crosses origins, so reaching the top is safe even when every level is a
    // different site.
    var target = window;
    try {
      if (IS_GAME_FRAME && window.top && window.top !== window) target = window.top;
      else if (IS_GAME_FRAME && window.parent && window.parent !== window) target = window.parent;
    } catch (e) { /* cross-origin top: postMessage from window still fine */ }
    try { target.postMessage(msg, "*"); } catch (e) { /* ignore */ }
  }

  // ---------------------------------------------------------------------------
  // Ring buffer + config
  // ---------------------------------------------------------------------------
  var CFG = {
    sniff: true,
    capture: true,
    captureFps: 2,
    captureWidth: 640,
    allowMirror: false,
    allowInject: false,
    maxQueued: 2000
  };

  var rings = {
    chat: [],
    events: [],
    outbound: []
  };
  var RLIMIT = { chat: 200, events: 400, outbound: 200 };
  var seq = { chat: 0, events: 0, outbound: 0 };

  function pushRing(kind, entry, broadcast) {
    entry.seq = ++seq[kind];
    var ring = rings[kind];
    ring.push(entry);
    while (ring.length > RLIMIT[kind]) ring.shift();
    if (broadcast) post("state:" + kind, { entry: entry });
  }

  function nowIso() { return new Date().toISOString(); }

  // ---------------------------------------------------------------------------
  // Game discovery: find the Eaglercraft canvas / parse state
  // ---------------------------------------------------------------------------
  function findCanvas() {
    if (!IS_GAME_FRAME) return null;
    var direct = document.getElementById("game_frame");
    var canvases = Array.prototype.slice.call(document.querySelectorAll("canvas"));
    if (direct && direct.tagName === "CANVAS") return direct;
    // Prefer the largest canvas (the render target), skip audio/UI extras
    var best = null, bestArea = 0;
    for (var i = 0; i < canvases.length; i++) {
      var c = canvases[i];
      var area = (c.width || 0) * (c.height || 0);
      if (area >= bestArea) { best = c; bestArea = area; }
    }
    return best;
  }

  function gameStateHint() {
    // The client does not expose DOM state, so use observable proxies.
    var canvas = findCanvas();
    return {
      frame: IS_GAME_FRAME,
      canvas: canvas ? { width: canvas.width, height: canvas.height, cssWidth: canvas.clientWidth, cssHeight: canvas.clientHeight } : null,
      pointerLocked: !!document.pointerLockElement,
      focused: document.hasFocus(),
      url: location.href,
      title: document.title,
      ready: IS_GAME_FRAME ? !!document.querySelector("canvas") : true
    };
  }

  // ---------------------------------------------------------------------------
  // Input injection
  // ---------------------------------------------------------------------------
  var CODE_MAP = {
    KeyW: 87, KeyA: 65, KeyS: 83, KeyD: 68, KeyE: 69, KeyQ: 81, KeyT: 84, KeyF: 70,
    KeyR: 82, KeyC: 67, KeyV: 86, KeyB: 66, KeyG: 71, KeyH: 72, KeyI: 73, KeyJ: 74,
    KeyK: 75, KeyL: 76, KeyM: 77, KeyN: 78, KeyO: 79, KeyP: 80, KeyU: 85, KeyX: 88,
    KeyY: 89, KeyZ: 90,
    Digit0: 48, Digit1: 49, Digit2: 50, Digit3: 51, Digit4: 52, Digit5: 53, Digit6: 54,
    Digit7: 55, Digit8: 56, Digit9: 57,
    Enter: 13, NumpadEnter: 13, Escape: 27, Space: 32, Tab: 9, Backspace: 8,
    ShiftLeft: 16, ShiftRight: 16, ControlLeft: 17, ControlRight: 17,
    AltLeft: 18, AltRight: 18, CapsLock: 20,
    ArrowUp: 38, ArrowDown: 40, ArrowLeft: 37, ArrowRight: 39,
    PageUp: 33, PageDown: 34, Home: 36, End: 35, Insert: 45, Delete: 46,
    Slash: 191, Backslash: 220, Semicolon: 186, Quote: 222, Comma: 188, Period: 190,
    BracketLeft: 219, BracketRight: 221, Minus: 189, Equal: 187, Backquote: 192,
    F1: 112, F2: 113, F3: 114, F4: 115, F5: 116, F11: 122, Numpad1: 97, Numpad2: 98,
    Numpad3: 99, Numpad4: 100, Numpad5: 101, NumpadAdd: 107, NumpadSubtract: 109
  };
  var KEY_TO_CODE = {};
  Object.keys(CODE_MAP).forEach(function (code) {
    var k = code.replace(/^(Key|Digit)/, "").toLowerCase();
    if (code === "Enter" || code === "NumpadEnter") k = "enter";
    else if (code === "Escape") k = "escape";
    else if (code === "Space") k = " ";
    else if (code === "Tab") k = "tab";
    else if (code === "Backspace") k = "backspace";
    else if (code === "ShiftLeft") k = "shift";
    else if (code === "ControlLeft") k = "control";
    else if (code === "AltLeft") k = "alt";
    else if (code.indexOf("Arrow") === 0) k = code.toLowerCase();
    if (!(k in KEY_TO_CODE)) KEY_TO_CODE[k] = code;
  });

  // Common aliases the LLM may send
  var ALIASES = {
    "w": 87, "a": 65, "s": 83, "d": 68, "e": 69, "q": 81, "t": 84, "f": 70, "r": 82,
    "c": 67, "v": 86, "b": 66, "g": 71, "h": 72, "i": 73, "j": 74, "k": 75, "l": 76,
    "m": 77, "n": 78, "o": 79, "p": 80, "u": 85, "x": 88, "y": 89, "z": 90,
    "esc": 27, "escape": 27, "enter": 13, "return": 13, "tab": 9, "space": 32, " ": 32,
    "shift": 16, "ctrl": 17, "control": 17, "alt": 18, "backspace": 8,
    "up": 38, "down": 40, "left": 37, "right": 39,
    "arrowup": 38, "arrowdown": 40, "arrowleft": 37, "arrowright": 39,
    "e": 69, "inventory": 69, "drop": 81, "chat": 84, "sneak": 16, "sprint": 17,
    "1": 49, "2": 50, "3": 51, "4": 52, "5": 53, "6": 54, "7": 55, "8": 56, "9": 57,
    "0": 48, "f1": 112, "f2": 113, "f3": 114, "f5": 116, "f11": 122
  };

  function resolveKey(spec) {
    if (spec == null) return null;
    var s = String(spec).trim();
    var lower = s.toLowerCase();
    // Accept "KeyW", "key_w", "w", "code:KeyW", "87"
    if (s.indexOf("code:") === 0) s = s.slice(5);
    if (/^\d+$/.test(s) && CODE_MAP[s] === undefined) {
      return { keyCode: parseInt(s, 10), key: String.fromCharCode(parseInt(s, 10)), code: "" };
    }
    if (CODE_MAP[s] !== undefined) {
      var k = s.replace(/^(Key|Digit)/, "").toLowerCase();
      if (s === "Space") k = " ";
      if (s === "Enter" || s === "NumpadEnter") k = "Enter";
      if (s === "ShiftLeft") k = "Shift";
      if (s === "ControlLeft") k = "Control";
      return { keyCode: CODE_MAP[s], key: k.length === 1 ? k : k, code: s };
    }
    if (ALIASES[lower] !== undefined) {
      var code = KEY_TO_CODE[lower] || "";
      return { keyCode: ALIASES[lower], key: lower.length === 1 ? lower : lower, code: code };
    }
    if (lower.length === 1) {
      var upper = lower.toUpperCase();
      var c = "Key" + upper;
      var kc = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".indexOf(upper) >= 0 ? upper.charCodeAt(0) : lower.charCodeAt(0);
      return { keyCode: kc, key: lower, code: CODE_MAP[c] !== undefined ? c : "" };
    }
    return null;
  }

  function makeKeyEvent(type, resolved, extra) {
    var ev;
    try {
      ev = new KeyboardEvent(type, {
        key: resolved.key,
        code: resolved.code || "",
        location: 0,
        repeat: !!(extra && extra.repeat),
        bubbles: true,
        cancelable: true,
        composed: true
      });
    } catch (e) {
      ev = document.createEvent("Event");
      ev.initEvent(type, true, true);
      try { ev.key = resolved.key; } catch (e2) {}
      try { ev.code = resolved.code || ""; } catch (e2) {}
      try { ev.repeat = !!(extra && extra.repeat); } catch (e2) {}
    }
    // keyCode / which are legacy but EaglercraftX reads `e.which`
    try { Object.defineProperty(ev, "keyCode", { get: function () { return resolved.keyCode; } }); } catch (e) {}
    try { Object.defineProperty(ev, "which", { get: function () { return resolved.keyCode; } }); } catch (e) {}
    try { Object.defineProperty(ev, "charCode", { get: function () { return 0; } }); } catch (e) {}
    return ev;
  }

  /**
   * Keyboard events are dispatched ONCE, at the element that does not bubble
   * into a second listener. EaglercraftX attaches keydown/keyup/keypress to
   * `window` (verified in its compiled client), so window is the correct and
   * only target: dispatching at the canvas as well would bubble up to window
   * and deliver every key twice (typed characters would double).
   */
  function keyTarget() {
    return IS_GAME_FRAME ? window : (document.body || window);
  }

  function pressKey(spec, type, repeat) {
    var resolved = resolveKey(spec);
    if (!resolved) return false;
    var ev = makeKeyEvent(type, resolved, { repeat: repeat });
    try { keyTarget().dispatchEvent(ev); } catch (e) { /* ignore */ }
    return true;
  }

  var held = {};
  var timers = {};

  function keyDown(spec, opts) {
    var resolved = resolveKey(spec);
    if (!resolved) return { ok: false, error: "unknown key: " + spec };
    var id = resolved.keyCode;
    if (!held[id]) {
      pressKey(spec, "keydown");
      held[id] = { spec: spec, since: Date.now() };
    }
    var duration = opts && opts.duration;
    if (duration != null && duration > 0) {
      clearTimeout(timers[id]);
      timers[id] = setTimeout(function () { keyUp(spec); }, Math.min(duration, 600000));
    }
    return { ok: true, keyCode: resolved.keyCode, key: resolved.key };
  }

  function keyUp(spec) {
    var resolved = resolveKey(spec);
    if (!resolved) return { ok: false, error: "unknown key: " + spec };
    clearTimeout(timers[resolved.keyCode]);
    delete timers[resolved.keyCode];
    if (held[resolved.keyCode]) delete held[resolved.keyCode];
    pressKey(spec, "keyup");
    return { ok: true, keyCode: resolved.keyCode, key: resolved.key };
  }

  function releaseAll() {
    Object.keys(held).forEach(function (id) { keyUp(held[id].spec); });
  }

  function typeText(text, opts) {
    // For chat: presses each character through keydown/keyup + keypress.
    // EaglercraftX keyboard handler accepts single-char `key` values.
    var delay = (opts && opts.delay) || 12;
    var chars = String(text).split("");
    var i = 0;
    return new Promise(function (resolve) {
      function next() {
        if (i >= chars.length) return resolve({ ok: true, typed: chars.length });
        var ch = chars[i++];
        var resolved = resolveKey(ch) || { keyCode: ch.toUpperCase().charCodeAt(0), key: ch, code: "" };
        var target = keyTarget();
        [makeKeyEvent("keydown", resolved), makeKeyEvent("keypress", resolved), makeKeyEvent("keyup", resolved)]
          .forEach(function (ev) { try { target.dispatchEvent(ev); } catch (e) {} });
        setTimeout(next, delay);
      }
      next();
    });
  }

  function canvasCenter() {
    var c = findCanvas();
    if (!c) return { x: window.innerWidth / 2, y: window.innerHeight / 2, target: document.body };
    var r = c.getBoundingClientRect();
    return { x: r.left + r.width / 2, y: r.top + r.height / 2, target: c, rect: r };
  }

  function makeMouseEvent(type, pos, extra) {
    var ev;
    var init = {
      clientX: pos.x,
      clientY: pos.y,
      screenX: pos.x,
      screenY: pos.y,
      button: (extra && extra.button) || 0,
      buttons: (extra && extra.buttons) || 0,
      bubbles: true,
      cancelable: true,
      composed: true
    };
    try {
      ev = new MouseEvent(type, init);
    } catch (e) {
      ev = document.createEvent("MouseEvents");
      ev.initMouseEvent(type, true, true, window, 0, pos.x, pos.y, pos.x, pos.y, false, false, false, false, init.button, null);
    }
    var mx = (extra && extra.movementX) || 0;
    var my = (extra && extra.movementY) || 0;
    try { Object.defineProperty(ev, "movementX", { get: function () { return mx; } }); } catch (e) {}
    try { Object.defineProperty(ev, "movementY", { get: function () { return my; } }); } catch (e) {}
    try { Object.defineProperty(ev, "offsetX", { get: function () { return (pos.x - ((pos.rect && pos.rect.left) || 0)); } }); } catch (e) {}
    try { Object.defineProperty(ev, "offsetY", { get: function () { return (pos.y - ((pos.rect && pos.rect.top) || 0)); } }); } catch (e) {}
    return ev;
  }

  function mouseMove(dx, dy, steps) {
    var pos = canvasCenter();
    var target = IS_GAME_FRAME ? (pos.target || window) : window;
    steps = Math.max(1, Math.min(steps || 1, 30));
    for (var i = 0; i < steps; i++) {
      var ev = makeMouseEvent("mousemove", pos, {
        movementX: dx / steps,
        movementY: dy / steps
      });
      try { target.dispatchEvent(ev); } catch (e) {}
    }
    return { ok: true, movementX: dx, movementY: dy };
  }

  var mouseButtons = { left: 0, middle: 1, right: 2 };

  function mouseButton(name, down) {
    var btn = mouseButtons[name] != null ? mouseButtons[name] : parseInt(name, 10) || 0;
    var pos = canvasCenter();
    var target = pos.target || window;
    var ev = makeMouseEvent(down ? "mousedown" : "mouseup", pos, {
      button: btn,
      buttons: down ? (btn === 0 ? 1 : btn === 2 ? 2 : 4) : 0
    });
    // Mirror to window too: some builds attach on window, and synth events on
    // canvas bubble to window anyway, so only extra dispatch on window is safe.
    try { target.dispatchEvent(ev); } catch (e) {}
    return { ok: true, button: btn };
  }

  function wheel(deltaY) {
    var pos = canvasCenter();
    var target = pos.target || window;
    var ev;
    try {
      ev = new WheelEvent("wheel", { deltaY: deltaY, deltaMode: 0, clientX: pos.x, clientY: pos.y, bubbles: true, cancelable: true });
    } catch (e) {
      ev = document.createEvent("Event");
      ev.initEvent("wheel", true, true);
      try { ev.deltaY = deltaY; } catch (e2) {}
    }
    try { target.dispatchEvent(ev); } catch (e) {}
    return { ok: true, deltaY: deltaY };
  }

  function click(pos) {
    var p = pos || canvasCenter();
    var target = p.target || document.body;
    var down = makeMouseEvent("mousedown", p, { button: 0, buttons: 1 });
    var up = makeMouseEvent("mouseup", p, { button: 0, buttons: 0 });
    var clk = makeMouseEvent("click", p, { button: 0, buttons: 0 });
    [down, up, clk].forEach(function (ev) {
      try { target.dispatchEvent(ev); } catch (e) {}
    });
    return { ok: true, x: p.x, y: p.y };
  }

  /**
   * Direct mouse-look. The engine accumulates movementX/Y into its own delta
   * only while it "owns" the mouse; when Chromium has refused a synthetic
   * pointer re-lock the engine would eat one delta as a lock artifact unless
   * we mirror the exact sequence it expects:
   *   1) mousemove with movementX/Y = -deltaX,-deltaY (dropped accumulator)
   *   2) mousemove with movementX/Y = +deltaX,+deltaY (applied)
   * Only used when look-bridge mode is enabled.
   */
  function look(dx, dy) {
    var pos = canvasCenter();
    var target = IS_GAME_FRAME ? (pos.target || window) : window;
    function fire(mx, my) {
      var ev = makeMouseEvent("mousemove", pos, { movementX: mx, movementY: my });
      try { target.dispatchEvent(ev); } catch (e) {}
    }
    fire(-dx, -dy);
    fire(dx, dy);
    return { ok: true, dx: dx, dy: dy, mode: "compensated" };
  }

  // ---------------------------------------------------------------------------
  // Camera: canvas capture (for vision models) — silence + dedupe applied on the
  // background side; here we just encode the current frame.
  // ---------------------------------------------------------------------------
  var captureCanvas = null, captureCtx = null;

  /** Cheap content hash so consumers can tell "the screen changed" from "no-op". */
  function cheapHash(str) {
    var h = 0x811c9dc5;
    // Sample the payload: JPEG data URLs are long and mostly headers are stable.
    for (var i = 0; i < str.length; i += 7) {
      h ^= str.charCodeAt(i);
      h = (h + ((h << 1) + (h << 4) + (h << 7) + (h << 8) + (h << 24))) >>> 0;
    }
    return h.toString(16);
  }

  function captureFrame(maxWidth) {
    var src = findCanvas();
    if (!src) return { ok: false, error: "no canvas in this frame" };
    var w = src.width, h = src.height;
    if (!w || !h) return { ok: false, error: "canvas has no size yet" };
    var scale = Math.min(1, (maxWidth || CFG.captureWidth) / w);
    var outW = Math.max(1, Math.round(w * scale));
    var outH = Math.max(1, Math.round(h * scale));
    if (!captureCanvas) { captureCanvas = document.createElement("canvas"); captureCtx = captureCanvas.getContext("2d"); }
    if (captureCanvas.width !== outW || captureCanvas.height !== outH) {
      captureCanvas.width = outW; captureCanvas.height = outH;
    }
    try {
      captureCtx.imageSmoothingEnabled = false;
      captureCtx.drawImage(src, 0, 0, outW, outH);
      var dataUrl = captureCanvas.toDataURL("image/jpeg", 0.6);
      return { ok: true, dataUrl: dataUrl, width: outW, height: outH, at: nowIso(), hash: cheapHash(dataUrl) };
    } catch (e) {
      return { ok: false, error: String(e) };
    }
  }

  // ---------------------------------------------------------------------------
  // WebSocket sniffing + optional mirror/barrier
  // ---------------------------------------------------------------------------
  var sniff = {
    sockets: [],
    active: null,
    // "connecting" -> handshake frames -> "play" -> vanilla 1.8 packets.
    phase: "connecting",
    handshakeProtocol: null,   // 1..5 once the server picked one
    username: null,
    uuid: null,
    server: null,
    eagFrames: [],             // decoded handshake transcript, newest last
    dropped: 0
  };

  function pushEag(entry) {
    entry.seq = (pushEag.seq = (pushEag.seq || 0) + 1);
    sniff.eagFrames.push(entry);
    while (sniff.eagFrames.length > 40) sniff.eagFrames.shift();
    post("state:handshake", { kind: entry.packet, data: entry });
  }

  /** Handshake packets are small control frames; vanilla play packets follow the
   *  server's 0x09 "finish" and from then on are decoded as MC 1.8. */
  function sniffHandshake(dir, u8) {
    var decoded = null;
    try {
      decoded = dir === "serverbound"
        ? V.decodeEagServerbound(u8, sniff.handshakeProtocol)
        : V.decodeEagClientbound(u8, sniff.handshakeProtocol);
    } catch (e) {
      return true; // still a handshake candidate, just truncated
    }
    if (!decoded) return false;

    decoded.dir = dir;
    decoded.at = nowIso();

    if (decoded.packet === "server_version") {
      sniff.handshakeProtocol = decoded.eag_protocol || 3;
      if (decoded.mc_protocol && decoded.mc_protocol !== 47) {
        // Still decodable (1.5/1.12 builds exist), but say so out loud.
        post("state:warn", { warning: "server selected MC protocol " + decoded.mc_protocol + " (bridge decodes 47)" });
      }
    } else if (decoded.packet === "client_version") {
      sniff.username = decoded.username || sniff.username;
    } else if (decoded.packet === "request_login") {
      sniff.username = decoded.username || sniff.username;
      sniff.server = decoded.requested_server || sniff.server;
    } else if (decoded.packet === "allow_login") {
      sniff.username = decoded.username || sniff.username;
      sniff.uuid = decoded.uuid || sniff.uuid;
    } else if (decoded.packet === "deny_login" || decoded.packet === "error" ||
               decoded.packet === "version_mismatch" || decoded.packet === "redirect") {
      post("state:game", { event: decoded.packet, data: decoded });
    }

    pushEag(decoded);

    if (decoded.packet === "server_finish" && dir === "clientbound") {
      sniff.phase = "play";
      post("state:handshake", { kind: "play_start", username: sniff.username, protocol: sniff.handshakeProtocol });
    }
    return true;
  }

  function toU8(data) {
    if (data instanceof ArrayBuffer) return new Uint8Array(data);
    if (ArrayBuffer.isView(data)) return new Uint8Array(data.buffer, data.byteOffset, data.byteLength);
    return null;
  }

  function appendHandshake(dir, u8) {
    var prev = sniff.handshakeBuf[dir];
    var merged = new Uint8Array(prev.length + u8.length);
    merged.set(prev, 0);
    merged.set(u8, prev.length);
    sniff.handshakeBuf[dir] = merged;
  }

  function tryDecodeHandshake(dir) {
    var u8 = sniff.handshakeBuf[dir];
    if (!u8.length) return false;
    try {
      if (dir === "serverbound") {
        var login = V.decodeEagLogin(u8);
        if (login) {
          sniff.username = login.username;
          sniff.handshakeBuf[dir] = new Uint8Array(0);
          post("state:handshake", { kind: "login", data: login });
          return true;
        }
      } else {
        var ident = V.decodeEagIdentify(u8);
        if (ident) {
          sniff.handshakeBuf[dir] = new Uint8Array(0);
          post("state:handshake", { kind: "identify", data: ident });
          return true;
        }
      }
    } catch (e) { /* not enough bytes yet */ }
    return false;
  }

  function ensureCanvasWaitHook() {
    // The game canvas is created a few frames after the socket opens. Poll for
    // it once the handshake starts so the first position packet is not missed
    // by our "is this a play packet" heuristic.
    if (ensureCanvasWaitHook.done) return;
    ensureCanvasWaitHook.done = true;
  }

  /**
   * Some outbound tees see the *masked* client frame. Eaglercraft sends only
   * ArrayBuffers to send(); if the first byte has the mask bit set and the
   * unmasked variant parses as a known packet, use the unmasked bytes.
   */
  function maybeUnmask(u8, dir) {
    if (dir !== "c2s") return u8;
    var b0 = u8[0], b1 = u8[1];
    if (!(b1 & 0x80)) return u8;             // not masked
    var len = b1 & 0x7f;
    if (len === 126 || len === 127) return u8; // big frames: not from the client
    if (u8.length < 2 + 4 + len) return u8;    // masked frame requires a 4-byte key
    var mask = u8.subarray(2, 6);
    var out = new Uint8Array(len);
    for (var i = 0; i < len; i++) out[i] = u8[6 + i] ^ mask[i & 3];
    // Only accept the unmasked interpretation if it decodes as something real
    try {
      var probe = V.decodePacket(out, "serverbound");
      if (probe && (probe.ok || probe.id >= 0)) return out;
    } catch (e) { /* fall through */ }
    return u8;
  }

  function handleSniffedFrame(dir, data) {
    if (!V || !data) return;
    if (dir === "c2s") dir = "serverbound";
    else if (dir === "s2c") dir = "clientbound";
    var u8 = toU8(data);
    if (!u8 || u8.length < 1) return;
    u8 = maybeUnmask(u8, dir);

    if (sniff.phase !== "play") {
      // server_finish (0x09) is a single byte and is what ends the handshake
      // Small control frames only. Anything absurdly large is not a handshake.
      if (u8.length <= 65535 && sniffHandshake(dir, u8)) return;
      // Not decodable as a handshake packet: could be the tail of a split frame
      // or a server we do not understand. Keep the phase until server_finish.
      if (sniff.phase === "connecting" && V.isEagStart(u8, dir)) return;
    }

    var decoded = V.decodePacket(u8, dir);
    if (decoded.id < 0) return;

    var entry = {
      dir: dir,
      id: decoded.id,
      name: decoded.name,
      data: decoded.data,
      len: decoded.length,
      at: nowIso()
    };

    if (dir === "clientbound") {
      if (decoded.name === "chat" && decoded.data && decoded.data.text) {
        var chat = {
          text: decoded.data.text,
          position: decoded.data.position, // 0 chat, 1 system, 2 action bar
          kind: decoded.data.position === 0 ? "chat" : decoded.data.position === 2 ? "actionbar" : "system",
          at: entry.at,
          from: guessSpeaker(decoded.data.text)
        };
        pushRing("chat", chat, true);
      } else if (decoded.name === "join_game") {
        post("state:game", { event: "joined", data: decoded.data });
      } else if (decoded.name === "disconnect") {
        post("state:game", { event: "disconnected", data: decoded.data });
        sniff.phase = "connecting";
      } else if (decoded.name === "player_list_header_footer") {
        post("state:hud", { header: decoded.data.header, footer: decoded.data.footer });
      } else if (decoded.name === "update_health") {
        post("state:hud", { health: decoded.data.health, food: decoded.data.food });
      } else if (decoded.name === "set_experience") {
        post("state:hud", { xp_level: decoded.data.xp_level, xp_bar: decoded.data.xp_bar });
      } else if (decoded.name === "player_position_look") {
        post("state:pos", { x: decoded.data.x, y: decoded.data.y, z: decoded.data.z, yaw: decoded.data.yaw, pitch: decoded.data.pitch });
      } else if (decoded.name === "update_score") {
        post("state:score", { entry: decoded.data.entry, value: decoded.data.value, objective: decoded.data.objective });
      }
    } else {
      if (decoded.name === "player" || decoded.name === "player_position" ||
          decoded.name === "player_position_look" || decoded.name === "player_look") {
        pushRing("outbound", { name: decoded.name, data: decoded.data, at: entry.at }, false);
      } else if (decoded.name === "chat") {
        pushRing("outbound", { name: "chat_sent", text: decoded.data.text, at: entry.at }, false);
        post("state:chat_sent", { text: decoded.data.text });
      } else if (decoded.name === "plugin_message" || decoded.name === "client_settings") {
        // noise
      } else {
        pushRing("events", { name: decoded.name, data: decoded.data, at: entry.at }, false);
      }
    }

    if (CFG.sniff) {
      post("packet", { dir: dir, id: decoded.id, name: decoded.name, data: decoded.data, len: entry.len });
    }
  }

  function injectableList() {
    try { return Object.keys(INJECTABLE); } catch (e) { return []; }
  }

  function guessSpeaker(text) {
    // "<Name> message" or "Name: message"
    var m = String(text || "").match(/^<([A-Za-z0-9_]{2,16})>\s/);
    if (m) return m[1];
    m = String(text || "").match(/^([A-Za-z0-9_]{2,16}):\s/);
    if (m) return m[1];
    return null;
  }

  // ---------------------------------------------------------------------------
  // WebSocket hook
  // ---------------------------------------------------------------------------
  var NativeWebSocket = window.WebSocket;

  function installWebSocketHook() {
    if (!NativeWebSocket || !V) return;
    if (NativeWebSocket.__eaglerBridgeWrapped) return;

    function wrapSocket(ws) {
      if (ws.__eaglerBridgeWrapped) return ws;
      ws.__eaglerBridgeWrapped = true;
      var meta = { url: String(ws.url || ""), opened: false, closed: false };

      // Inbound
      ws.addEventListener("message", function (ev) {
        meta.opened = true;
        if (!sniff.active) {
          sniff.active = meta;
          sniff.server = meta.url;
          post("state:connect", { url: meta.url, transport: "websocket" });
        }
        handleSniffedFrame("s2c", ev.data);
      });
      ws.addEventListener("open", function () {
        meta.opened = true;
        if (!sniff.active) {
          sniff.active = meta;
          sniff.server = meta.url;
          post("state:connect", { url: meta.url, transport: "websocket" });
        }
        post("state:socket_open", { url: meta.url });
      });
      ws.addEventListener("close", function (ev) {
        meta.closed = true;
        if (sniff.active === meta) {
          sniff.active = null;
          sniff.phase = "connecting";
          sniff.handshakeProtocol = null;
          post("state:disconnect", { url: meta.url, code: ev.code, reason: ev.reason });
        }
      });
      ws.addEventListener("error", function () {
        post("state:socket_error", { url: meta.url });
      });

      // Outbound: teeing `send`
      var nativeSend = ws.send.bind(ws);
      meta.ws = ws;
      meta.nativeSend = nativeSend;
      ws.send = function (data) {
        try { handleSniffedFrame("c2s", data); } catch (e) {}
        return nativeSend.apply(ws, arguments);
      };
      return ws;
    }

    function EaglerBridgeWebSocket(url, protocols) {
      var ws = arguments.length > 1 ? new NativeWebSocket(url, protocols) : new NativeWebSocket(url);
      sniff.sockets.push({ url: String(url), at: nowIso() });
      return wrapSocket(ws);
    }

    EaglerBridgeWebSocket.prototype = NativeWebSocket.prototype;
    EaglerBridgeWebSocket.CONNECTING = 0;
    EaglerBridgeWebSocket.OPEN = 1;
    EaglerBridgeWebSocket.CLOSING = 2;
    EaglerBridgeWebSocket.CLOSED = 3;
    EaglerBridgeWebSocket.__eaglerBridgeWrapped = true;
    // Keep a reference so background injection and debugging can find it
    Object.defineProperty(EaglerBridgeWebSocket, "name", { value: "WebSocket" });
    window.WebSocket = EaglerBridgeWebSocket;

    // If the game already opened a socket before this script ran (rare, the
    // content script is main-world at document_start) we cannot wrap it; note it.
    post("sniffer:ready", { hadNative: true });
  }

  // ---------------------------------------------------------------------------
  // Mirror / barrier: second connection injected between client and server.
  //
  // The LLM's own client never reconnects into the human's session (Eaglercraft
  // servers reject duplicate usernames), so instead we let a headless agent be
  // the *proxy* for one connection: frames are relayed through the page, and
  // the agent may inspect/annotate/withhold serverbound frames. This is what
  // makes "click the Ready button" style actions executable by a machine.
  // ---------------------------------------------------------------------------
  var mirror = null;

  /**
   * Opens a real Eaglercraft connection with the reference handshake
   * (lax1dude/eaglerxserver HandshakePacketTypes):
   *   1. C->S client_version (0x01)      S->C server_version (0x02)
   *   2. C->S request_login (0x04)       S->C allow_login (0x05) / deny (0x06)
   *   3. C->S profile_data (0x07) skin
   *   4. C->S finish_login (0x08)        S->C server_finish (0x09) -> play
   */
  function startMirror(targetUrl, username, brand) {
    if (!CFG.allowMirror) return { ok: false, error: "mirror disabled in bridge settings (options -> allow mirror mode)" };
    if (!NativeWebSocket || !V) return { ok: false, error: "WebSocket/parser unavailable" };
    if (mirror) return { ok: false, error: "mirror already active" };

    var name = (username || sniff.username || "LLMBot").replace(/[^A-Za-z0-9_]/g, "").slice(0, 16);
    if (name.length < 3) name = "LLMBot";
    mirror = { ws: new NativeWebSocket(targetUrl), phase: "version", protocol: null, username: name, queued: [] };
    var m = mirror;
    m.ws.binaryType = "arraybuffer";

    m.ws.addEventListener("open", function () {
      post("mirror:open", { url: targetUrl });
      // EaglercraftXServer derives the offline name+UUID from this field, so the
      // bot name goes here (request_login only carries it if nicknameSelection).
      m.ws.send(V.buildEagClientVersion({ username: m.username, brand: brand || "Eagler-LLM-Bridge", version: "1.0.0" }));
    });

    m.ws.addEventListener("message", function (ev) {
      var u8 = toU8(ev.data);
      if (!u8 || !u8.length) return;
      var msg = null;
      try { msg = V.decodeEagClientbound(u8, m.protocol); } catch (e) { /* ignore */ }
      if (msg) {
        post("mirror:frame", { phase: m.phase, s2c: msg });
        if (msg.packet === "server_version") {
          if (msg.mc_protocol !== 47) {
            post("mirror:error", { error: "server wants MC protocol " + msg.mc_protocol + ", bridge speaks 47" });
            m.ws.close();
            return;
          }
          m.protocol = msg.eag_protocol;
          m.nicknameSelection = msg.nickname_selection === true;
          m.ws.send(V.buildEagRequestLogin(m.username, "default", m.protocol,
            { nicknameSelection: m.nicknameSelection }));
        } else if (msg.packet === "allow_login") {
          m.username = msg.username || m.username;
          m.uuid = msg.uuid || null;
          m.phase = "login";
          // Note: profile_data (0x07) is optional; EaglercraftXServer's stock
          // config answers an unknown profile key with "Invalid Packet", so the
          // bridge goes straight to finish_login (verified against live servers).
          m.ws.send(V.buildEagFinishLogin());
        } else if (msg.packet === "server_finish") {
          m.phase = "play";
          post("mirror:ready", { username: m.username, protocol: m.protocol });
          m.queued.forEach(function (f) { try { m.ws.send(f); } catch (e) {} });
          m.queued = [];
        } else if (msg.packet === "deny_login" || msg.packet === "error" || msg.packet === "version_mismatch") {
          post("mirror:error", { packet: msg.packet, message: msg.message || null });
          m.ws.close();
        }
        return;
      }
      if (m.phase === "play") {
        var decoded = V.decodePacket(u8, "clientbound");
        post("mirror:frame", { phase: "play", id: decoded.id, name: decoded.name, data: decoded.data, len: u8.length });
      }
    });

    m.ws.addEventListener("close", function (ev) {
      post("mirror:closed", { code: ev.code, reason: ev.reason });
      mirror = null;
    });
    m.ws.addEventListener("error", function () { post("mirror:error", {}); });
    return { ok: true };
  }

  // ---------------------------------------------------------------------------
  // Raw packet injection (opt-in). Transmits extra packets over the *existing*
  // connection, i.e. as the human's own client would. This is what unlocks
  // actions the synthetic-input path cannot perform while Chromium refuses
  // pointer lock: chat, attacking, sneaking, respawn, slot changes...
  // ---------------------------------------------------------------------------
  function Writer() { this.bytes = []; }
  Writer.prototype = {
    varint: function (v) {
      v = v >>> 0;
      while (true) {
        var b = v & 0x7f; v >>>= 7;
        if (v === 0) { this.bytes.push(b); break; }
        this.bytes.push(b | 0x80);
      }
      return this;
    },
    u8: function (v) { this.bytes.push(v & 0xff); return this; },
    i8: function (v) { this.bytes.push(v & 0xff); return this; },
    bool: function (v) { this.bytes.push(v ? 1 : 0); return this; },
    u16: function (v) { this.bytes.push((v >> 8) & 0xff, v & 0xff); return this; },
    i16: function (v) { this.u16(v & 0xffff); return this; },
    i32: function (v) {
      this.u8(v >>> 24).u8(v >>> 16).u8(v >>> 8).u8(v);
      return this;
    },
    f32: function (v) {
      var dv = new DataView(new ArrayBuffer(4)); dv.setFloat32(0, v); 
      for (var i = 0; i < 4; i++) this.bytes.push(dv.getUint8(i));
      return this;
    },
    f64: function (v) {
      var dv = new DataView(new ArrayBuffer(8)); dv.setFloat64(0, v);
      for (var i = 0; i < 8; i++) this.bytes.push(dv.getUint8(i));
      return this;
    },
    str: function (s) {
      var enc = new TextEncoder().encode(String(s));
      this.varint(enc.length);
      for (var i = 0; i < enc.length; i++) this.bytes.push(enc[i]);
      return this;
    },
    position: function (p) {
      var x = BigInt(p.x | 0) & 0x3ffffffn;
      var y = BigInt(p.y | 0) & 0xfffn;
      var z = BigInt(p.z | 0) & 0x3ffffffn;
      var v = (x << 38n) | (y << 26n) | z;
      var dv = new DataView(new ArrayBuffer(8)); dv.setBigUint64(0, v);
      for (var i = 0; i < 8; i++) this.bytes.push(dv.getUint8(i));
      return this;
    },
    done: function () { return new Uint8Array(this.bytes); }
  };

  // Allowlisted serverbound packets. Anything not here cannot be injected.
  var INJECTABLE = {
    chat: function (w, a) { w.u8(0x01).str(a.text || a.message || ""); },
    client_status: function (w, a) { w.u8(0x16).varint(a.action == null ? 0 : a.action); },
    use_entity: function (w, a) {
      w.u8(0x02).varint(a.target).varint(a.type == null ? 1 : a.type);
      if ((a.type | 0) === 2) { w.f32(a.x || 0).f32(a.y || 0).f32(a.z || 0); }
    },
    held_item_change: function (w, a) { w.u8(0x09).i16(a.slot || 0); },
    entity_action: function (w, a) { w.u8(0x0b).varint(a.entity_id == null ? 0 : a.entity_id).varint(a.action || 0); },
    player_abilities: function (w, a) { w.u8(0x13).u8(a.flags || 0).f32(a.fly_speed || 0.05).f32(a.walk_speed || 0.1); },
    player: function (w, a) { w.u8(0x03).bool(!!a.on_ground); },
    player_look: function (w, a) { w.u8(0x05).f32(a.yaw || 0).f32(a.pitch || 0).bool(!!a.on_ground); },
    player_position: function (w, a) { w.u8(0x04).f64(a.x || 0).f64(a.y || 0).f64(a.z || 0).bool(!!a.on_ground); },
    player_position_look: function (w, a) {
      w.u8(0x06).f64(a.x || 0).f64(a.y || 0).f64(a.z || 0).f32(a.yaw || 0).f32(a.pitch || 0).bool(!!a.on_ground);
    },
    player_digging: function (w, a) { w.u8(0x07).i8(a.status || 0).position(a.position || { x: 0, y: 0, z: 0 }).i8(a.face || 0); },
    client_settings: function (w, a) {
      w.u8(0x15).str(a.locale || "en_US").i8(a.view_distance || 8).u8(a.chat_mode || 0)
        .bool(a.chat_colors !== false).u8(a.skin_parts || 0x7f);
    }
  };

  function injectPacket(name, args) {
    if (!CFG.allowInject) return { ok: false, error: "packet injection disabled (enable in bridge options or start the CLI with --enable-inject)" };
    var live = sniff.active && sniff.active.ws;
    if (!live || live.readyState !== 1) return { ok: false, error: "no open game connection" };
    if (sniff.phase !== "play") return { ok: false, error: "game is not in play state yet (phase: " + sniff.phase + ")" };
    var fn = INJECTABLE[name];
    if (!fn) return { ok: false, error: "packet not allowed: " + name, allowed: Object.keys(INJECTABLE) };
    var w = new Writer();
    try { fn(w, args || {}); } catch (e) { return { ok: false, error: "encode failed: " + e }; }
    var bytes = w.done();
    try {
      sniff.active.nativeSend(bytes);
      post("state:injected", { name: name, bytes: Array.from(bytes).slice(0, 64), len: bytes.length });
      return { ok: true, name: name, len: bytes.length };
    } catch (e) {
      return { ok: false, error: "send failed: " + e };
    }
  }

  // ---------------------------------------------------------------------------
  // Command handling
  // ---------------------------------------------------------------------------
  function respond(id, ok, result) {
    post("result", { id: id, ok: ok, result: result == null ? null : result });
  }

  var sleep = function (ms) { return new Promise(function (r) { setTimeout(r, Math.max(0, Math.min(ms, 600000))); }); };

  function runStep(step) {
    if (step == null) return Promise.resolve(null);
    if (typeof step === "string") return runStep({ action: "key_tap", key: step });
    var action = step.action;
    switch (action) {
      case "key_down": return Promise.resolve(keyDown(step.key, { duration: step.duration }));
      case "key_up": return Promise.resolve(keyUp(step.key));
      case "key_tap": {
        var d = step.duration == null ? 60 : step.duration;
        return Promise.resolve(keyDown(step.key))
          .then(function () { return sleep(d); })
          .then(function () { return keyUp(step.key); });
      }
      case "type": return typeText(step.text || "", { delay: step.delay });
      case "release_all": releaseAll(); return Promise.resolve({ ok: true });
      case "look": return Promise.resolve(look(step.dx, step.dy));
      case "mouse_move": return Promise.resolve(mouseMove(step.dx || 0, step.dy || 0, step.steps));
      case "mouse_down": return Promise.resolve(mouseButton(step.button || "left", true));
      case "mouse_up": return Promise.resolve(mouseButton(step.button || "left", false));
      case "click": return Promise.resolve(click());
      case "noop": return Promise.resolve({ ok: true });
      case "capture": {
        var f = captureFrame(step.width || CFG.captureWidth);
        return Promise.resolve({ ok: f.ok, frame: f });
      }
      case "packet": return Promise.resolve(injectPacket(step.name, step.args || step.data || {}));
      case "wheel": return Promise.resolve(wheel(step.deltaY || 0));
      case "wait": return sleep(step.ms || 100).then(function () { return { ok: true, waited: step.ms || 100 }; });
      case "chat":
      case "send_chat": {
        // Open chat with T, type, send with Enter
        var msg = step.text != null ? step.text : step.message;
        var enterDelay = step.enterDelay == null ? 120 : step.enterDelay;
        return Promise.resolve(keyDown("t"))
          .then(function () { return sleep(80); })
          .then(function () { keyUp("t"); return sleep(80); })
          .then(function () { return typeText(msg, { delay: step.delay }); })
          .then(function () { return sleep(enterDelay); })
          .then(function () { return runStep({ action: "key_tap", key: "enter", duration: 60 }); })
          .then(function () { return { ok: true, sent: msg }; });
      }
      case "command": {
        var cmd = step.command != null ? step.command : step.text;
        if (cmd != null && String(cmd).charAt(0) !== "/") cmd = "/" + cmd;
        return runStep({ action: "chat", text: cmd, enterDelay: 150 });
      }
      default:
        return Promise.reject(new Error("unknown action: " + action));
    }
  }

  function runSequence(steps) {
    steps = steps || [];
    var p = Promise.resolve([]);
    steps.forEach(function (step) {
      p = p.then(function (results) {
        return runStep(step).then(function (r) { results.push(r); return results; });
      });
    });
    return p;
  }

  function execCommand(cmd, id) {
    var control = cmd.control || {};
    if (control.capture != null) CFG.capture = !!control.capture;
    if (control.sniff != null) CFG.sniff = !!control.sniff;
    if (control.captureFps != null) CFG.captureFps = Math.max(0.2, Math.min(15, +control.captureFps));
    if (control.captureWidth != null) CFG.captureWidth = Math.max(160, Math.min(1280, +control.captureWidth));

    var body;
    if (Array.isArray(cmd.steps)) body = runSequence(cmd.steps).then(function (results) { return { ok: true, steps: results }; });
    else if (Array.isArray(cmd.sequence)) body = runSequence(cmd.sequence).then(function (results) { return { ok: true, steps: results }; });
    else body = runStep(cmd);

    body.then(function (r) {
      var ok = !(r && r.ok === false);
      post("result", { id: id, ok: ok, result: r, error: ok ? null : (r.error || r.result || "action failed") });
    }).catch(function (e) {
      post("result", { id: id, ok: false, result: null, error: String(e && e.message || e) });
    });
  }

  function handleAgentMessage(type, payload) {
    switch (type) {
      case "capture": {
        var cap = captureFrame(payload.width);
        post("frame", Object.assign({ id: payload.id, raw: cap }, cap));
        return;
      }
      case "snapshot": {
        var snap = {
          id: payload.id,
          chat: rings.chat.slice(-(payload.chatLimit || 60)),
          events: rings.events.slice(-(payload.eventLimit || 30)),
          outbound: rings.outbound.slice(-(payload.outboundLimit || 20)),
          game: gameStateHint(),
          handshakeDone: sniff.phase === "play",
          username: sniff.username,
          server: sniff.server,
          chatSeq: seq.chat,
          eventSeq: seq.events,
          frame: captureFrame(CFG.captureWidth)
        };
        post("snapshot", Object.assign({ ok: true, result: snap }, snap));
        return;
      }
      case "status":
        post("status_result", {
          id: payload.id, ok: true, result: gameStateHint(), sniffing: !!V,
          handshakeDone: sniff.phase === "play", username: sniff.username,
          canInject: injectableList(), allowInject: !!CFG.allowInject, phase: sniff.phase, protocol: sniff.handshakeProtocol,
          socketOpen: !!(sniff.active && sniff.active.ws && sniff.active.ws.readyState === 1)
        });
        return;
      case "cmd":
        execCommand(payload.command || {}, payload.id);
        return;
      case "change_since":
        post("changes", {
          id: payload.id,
          chat: rings.chat.filter(function (c) { return c.seq > (payload.chatSeq || 0); }),
          events: rings.events.filter(function (c) { return c.seq > (payload.eventSeq || 0); }),
          head: { chat: seq.chat, events: seq.events, outbound: seq.outbound }
        });
        return;
      case "set_config":
        Object.keys(payload.config || {}).forEach(function (k) { if (k in CFG) CFG[k] = payload.config[k]; });
        post("status_result", { id: payload.id, ok: true, result: CFG, canInject: injectableList() });
        return;
      case "mirror_send": {
        if (!mirror || mirror.ws.readyState !== 1) { post("mirror:send_result", { id: payload.id, ok: false, error: "mirror not open" }); return; }
        try {
          var bytes = new Uint8Array(payload.bytes);
          if (mirror.phase === "play") mirror.ws.send(bytes); else mirror.queued.push(bytes);
          post("mirror:send_result", { id: payload.id, ok: true, sent: bytes.length, queued: mirror.phase !== "play" });
        } catch (e) {
          post("mirror:send_result", { id: payload.id, ok: false, error: String(e) });
        }
        return;
      }
      case "start_mirror":
        post("mirror:open", { id: payload.id, result: startMirror(payload.url, payload.username, payload.brand) });
        return;
      case "start_audio":
      case "stop_audio":
        // Audio recording happens in the extension's offscreen document (a
        // Web Speech API consumer must be an extension page), not in the page.
        post("audio:status", { id: payload.id, result: { ok: true, external: true } });
        return;
      default:
        post("error", { id: payload && payload.id, error: "unknown command type: " + type });
    }
  }

  // ---------------------------------------------------------------------------
  // Message wiring
  // ---------------------------------------------------------------------------
  window.addEventListener("message", function (ev) {
    var msg = ev.data;
    if (!msg || msg.source !== "eagler-llm-bridge-content") return;
    if (msg.type === "token") {
      // Normally delivered by the page's own content script, which is
      // impossible when the game host and the page host differ (a game embedded
      // anywhere). The extension worker may also inject it directly.
      if (ev.source !== window && !msg.viaExtension) return;
      TOKEN = msg.token;
      if (!started) {
        started = true;
        // The hook is normally already installed at load; this is a no-op then.
        installWebSocketHook();
        startAutoCapture();
        post("hello", { frame: IS_GAME_FRAME, url: location.href, hasParser: !!V });
      }
      return;
    }
    if (!TOKEN || msg.token !== TOKEN) return;
    // The top nite.games page only hosts the relay: the game frame's own agent
    // owns command execution. Refuse to answer anything here, otherwise a
    // "not the game frame" error could race the real frame's reply.
    if (!IS_GAME_FRAME) return;
    handleAgentMessage(msg.type, msg.payload || {});
  });

  function startAutoCapture() {
    if (!IS_GAME_FRAME) return;
    var lastSent = 0;
    setInterval(function () {
      if (!CFG.capture) return;
      var fps = CFG.captureFps || 2;
      // captureFps is a send rate; a minimum of ~4/s keeps "look at the screen
      // right now" responsive for vision models without flooding the socket.
      var minMs = 1000 / Math.max(fps, 4);
      var t = Date.now();
      if (t - lastSent < minMs) return;
      lastSent = t;
      var frame = captureFrame(CFG.captureWidth);
      if (frame.ok) post("frame:auto", frame);
    }, 250);
  }

  // Install the network hook immediately: the WebSocket is opened by the game
  // client a few hundred ms after this script runs, and we must be in place
  // before that. Command execution stays gated behind the nonce token.
  installWebSocketHook();
  if (IS_GAME_FRAME) startAutoCapture();
})();
