/*
 * Eagler LLM Bridge — Perchance adapter (content script, ISOLATED world).
 *
 * Runs inside the *generator* frame of a Perchance chat page, i.e.
 *   https://<hash>.perchance.org/<generator>
 * which is where the AI chat UI actually lives (the top-level perchance.org
 * page just frames it).
 *
 * Why this file exists: the "AI" the user wants to play with is a Perchance
 * ai-character-chat generator (aiTextPlugin), not a hosted API. Its replies
 * only exist in the DOM, so the bridge reads them the way a human would:
 *
 *   #messageFeed .message            one row per message
 *     .characterName                 who said it
 *     .messageText                   the text (grows while streaming)
 *   #messageInput                    textarea the user types in
 *   #sendButton                      send control
 *
 * The adapter
 *   - posts every message it sees to the service worker, streaming-aware:
 *     `partial` updates while text grows, one final `complete` event;
 *   - accepts `send` commands (fill the textarea, fire input, click send);
 *   - reports `generating` so the caller knows when to stop waiting.
 *
 * Verified against the live DOM of perchance.org/g66gcru29s: rows carry
 * data-id / data-order / data-character-id, the greeting row's characterName is
 * the assistant, user rows are "Anon". Streaming updates re-render `.messageText`
 * (the row keeps a literal "generating..." marker while in flight).
 */
(() => {
  "use strict";
  if (window.__EAGLER_PERCHANCE_ADAPTER__) return;
  window.__EAGLER_PERCHANCE_ADAPTER__ = true;

  const SEL = {
    feed: "#messageFeed",
    input: "#messageInput",
    send: "#sendButton",
    row: ".message",
    name: ".characterName",
    text: ".messageText"
  };

  const USER_NAME_RE = /^(anon|you|user|me)$/i;
  const GENERATING_RE = /generating|stop response/i;
  const QUIET_MS = 1500;      // text unchanged this long + no marker => complete
  const PARTIAL_MS = 400;     // throttle for streaming updates

  const state = {
    assistantName: null,      // learned from the first row (the greeting)
    rows: new Map(),          // id -> { text, name, role, lastChangeAt, emitted, complete }
    seq: 0,
    ready: false,
    lastSendAt: 0,
    pendingSends: []          // texts we injected, to tag the user row
  };

  const ext = (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.id) ? chrome : null;

  function post(type, payload) {
    if (!ext) return;
    try {
      const p = ext.runtime.sendMessage({ kind: "eagler-perchance", type, payload });
      if (p && p.catch) p.catch(() => {});
    } catch (e) { /* worker asleep */ }
  }

  const now = () => Date.now();

  // ---------------------------------------------------------------------------
  // Reading the feed
  // ---------------------------------------------------------------------------
  function rowId(el) {
    const id = el.getAttribute("data-id");
    if (id) return "m" + id;
    // Fall back to position so the adapter still works if the id attribute goes away.
    const feed = el.parentElement;
    return "p" + (feed ? Array.prototype.indexOf.call(feed.children, el) : 0);
  }

  /**
   * Text of a message with its line breaks intact.
   *
   * innerText is what a human sees, but this generator renders markdown into
   * block elements (<p>, <li>) whose innerText joins... without newlines in some
   * layouts -- and a plan like "walk: forward" / "say: hi" collapsed into one
   * unparseable line. So block boundaries are walked explicitly and joined with
   * "\n", then innerText is used for whitespace normalisation inside a block.
   */
  const BLOCK_TAGS = /^(P|DIV|LI|UL|OL|H[1-6]|BLOCKQUOTE|PRE|TABLE|TR|SECTION|ARTICLE|HEADER|FOOTER)$/;
  function textOf(el) {
    if (!el) return "";
    const out = [];
    (function walk(node) {
      for (const child of node.childNodes) {
        if (child.nodeType === Node.TEXT_NODE) {
          out.push(child.nodeValue);
        } else if (child.nodeType === Node.ELEMENT_NODE) {
          if (child.tagName === "BR") { out.push("\n"); continue; }
          const block = BLOCK_TAGS.test(child.tagName);
          if (block && out.length && !/\n$/.test(out.join("").slice(-1) || "")) out.push("\n");
          // Code blocks keep their own newlines verbatim.
          if (child.tagName === "PRE") { out.push(child.textContent); }
          else walk(child);
          if (block) out.push("\n");
        }
      }
    })(el);
    return out.join("")
      .replace(/\r/g, "")
      .replace(/[ \t]+\n/g, "\n")
      .replace(/\n{3,}/g, "\n\n")
      .trim();
  }

  function readRow(el) {
    const nameEl = el.querySelector(SEL.name);
    const textEl = el.querySelector(SEL.text);
    const name = nameEl ? nameEl.textContent.trim() : "";
    const text = textOf(textEl);
    const raw = el.innerText || "";
    return {
      id: rowId(el),
      name,
      text,
      // The row shows "generating..." / a stop button while the model is writing.
      busy: GENERATING_RE.test(raw) && !text,
      streaming: GENERATING_RE.test(raw),
      hasText: !!text
    };
  }

  function roleOf(name) {
    if (state.assistantName && name === state.assistantName) return "assistant";
    if (USER_NAME_RE.test(name)) return "user";
    // Unknown speaker: if it arrived right after we sent, it is the user's echo;
    // otherwise treat it as the assistant (the only other party in these chats).
    return "assistant";
  }

  function scan(force) {
    const feed = document.querySelector(SEL.feed);
    if (!feed) return;
    const els = feed.querySelectorAll(SEL.row);
    if (!els.length) return;

    if (!state.assistantName) {
      // The greeting is the first row and is always from the character.
      const first = readRow(els[0]);
      if (first.name && !USER_NAME_RE.test(first.name)) state.assistantName = first.name;
    }

    const t = now();
    for (const el of els) {
      const r = readRow(el);
      const prev = state.rows.get(r.id);
      const role = roleOf(r.name);

      if (!prev) {
        state.rows.set(r.id, {
          id: r.id, name: r.name, role, text: r.text,
          lastChangeAt: t, emittedAt: 0, emittedText: "", complete: false, firstSeenAt: t
        });
      }
      const rec = state.rows.get(r.id);
      rec.name = r.name;
      rec.role = role;
      rec.streaming = r.streaming;

      if (r.text !== rec.text) {
        rec.text = r.text;
        rec.lastChangeAt = t;
      }

      // Completion: have text, nothing saying "generating", and quiet for QUIET_MS.
      // A row that never streams still completes once it has text and is quiet.
      const quietFor = t - rec.lastChangeAt;
      const settled = rec.text && !r.streaming && quietFor >= QUIET_MS;
      const stalled = rec.text && r.streaming && quietFor >= 6000;   // stream died
      if (!rec.complete && (settled || (force && rec.text) || stalled)) {
        rec.complete = true;
        rec.emittedAt = t;
        rec.emittedText = rec.text;
        post("llm-message", {
          id: rec.id, name: rec.name, role: rec.role, text: rec.text,
          complete: true, at: new Date().toISOString(), seq: ++state.seq
        });
        continue;
      }

      // Partial updates while it writes.
      if (!rec.complete && rec.text && rec.text !== rec.emittedText && t - rec.emittedAt >= PARTIAL_MS) {
        rec.emittedAt = t;
        rec.emittedText = rec.text;
        post("llm-message", {
          id: rec.id, name: rec.name, role: rec.role, text: rec.text,
          complete: false, at: new Date().toISOString(), seq: ++state.seq
        });
      }
    }

    const generating = Array.from(els).some((el) => GENERATING_RE.test(el.innerText || ""));
    if (generating !== state.generating) {
      state.generating = generating;
      post("llm-status", statusPayload());
    }
  }

  function statusPayload() {
    const rows = document.querySelectorAll(SEL.row).length;
    return {
      ready: state.ready,
      generating: state.generating,
      rows,
      assistantName: state.assistantName,
      feed: !!document.querySelector(SEL.feed),
      input: !!document.querySelector(SEL.input),
      send: !!document.querySelector(SEL.send),
      url: location.href,
      title: document.title
    };
  }

  // ---------------------------------------------------------------------------
  // Sending
  // ---------------------------------------------------------------------------
  function setValue(el, text) {
    // Native setter so React-ish listeners see a real change, then input+change.
    const proto = Object.getPrototypeOf(el);
    const desc = Object.getOwnPropertyDescriptor(proto, "value");
    if (desc && desc.set) desc.set.call(el, text); else el.value = text;
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
  }

  function pressEnter(el) {
    const opts = { key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true, cancelable: true };
    el.dispatchEvent(new KeyboardEvent("keydown", opts));
    el.dispatchEvent(new KeyboardEvent("keypress", opts));
    el.dispatchEvent(new KeyboardEvent("keyup", opts));
  }

  function send(text) {
    const input = document.querySelector(SEL.input);
    if (!input) return { ok: false, error: "Perchance input (#messageInput) not found — is the generator frame loaded?" };
    const body = String(text == null ? "" : text);
    if (!body.trim()) return { ok: false, error: "empty message" };

    input.focus();
    setValue(input, body);
    const sendBtn = document.querySelector(SEL.send);
    if (sendBtn) {
      sendBtn.disabled = false;
      sendBtn.click();
    } else {
      pressEnter(input);
    }
    state.lastSendAt = now();
    state.pendingSends.push({ text: body, at: state.lastSendAt });
    if (state.pendingSends.length > 8) state.pendingSends.shift();

    // If the UI rejected the click (button gated on a real user gesture), fall
    // back to Enter, then report the truth rather than pretending it worked.
    const queued = (input.value || "").trim();
    if (queued === body.trim()) {
      pressEnter(input);
    }
    return { ok: true, sent: body };
  }

  // ---------------------------------------------------------------------------
  // Wiring
  // ---------------------------------------------------------------------------
  function boot() {
    const feed = document.querySelector(SEL.feed);
    if (!feed) {
      // The generator frame builds its UI asynchronously; retry briefly.
      if (!boot.tries) boot.tries = 0;
      if (++boot.tries < 40) return setTimeout(boot, 500);
      state.ready = false;
      post("llm-status", statusPayload());
      return;
    }
    state.ready = true;
    scan(true);

    const mo = new MutationObserver(() => scan(false));
    mo.observe(feed, { childList: true, subtree: true, characterData: true });

    // Completion is time-based, so a slow tick is required even with no mutations.
    setInterval(() => scan(false), 700);

    post("llm-status", statusPayload());
  }

  if (ext) {
    ext.runtime.onMessage.addListener((msg, sender, respond) => {
      if (!msg || msg.kind !== "eagler-perchance-to-page") return;
      try {
        switch (msg.type) {
          case "send":
            respond(send(msg.payload && msg.payload.text));
            break;
          case "status":
            respond(statusPayload());
            break;
          case "messages": {
            const out = Array.from(state.rows.values()).map((r) => ({
              id: r.id, name: r.name, role: r.role, text: r.text, complete: r.complete
            }));
            respond({ ok: true, messages: out, assistantName: state.assistantName });
            break;
          }
          case "stop": {
            // Best-effort: the stop control is a button inside the feed area.
            const btns = Array.from(document.querySelectorAll("button, div"));
            const stop = btns.find((b) => /stop response/i.test(b.textContent || ""));
            if (stop) { stop.click(); respond({ ok: true, stopped: true }); }
            else respond({ ok: false, error: "no stop control visible" });
            break;
          }
          default:
            respond({ ok: false, error: "unknown adapter command: " + msg.type });
        }
      } catch (e) {
        respond({ ok: false, error: String(e && e.message || e) });
      }
      return true;
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot, { once: true });
  } else {
    boot();
  }
})();
