/*
 * Eagler LLM Bridge — Minecraft 1.8 (protocol 47) wire-format helper.
 *
 * Loaded as a classic script in two places:
 *   - page/v1_8_parser.js  (MAIN-world content script, defines window.EaglerV18)
 *   - test harness         (Node: `require()` gives the same object)
 *
 * EaglercraftX 1.8 speaks vanilla Minecraft protocol 47. After the EAG handshake
 * (packets 0x01..0x09 documented below), every WebSocket frame is exactly one
 * vanilla packet: VarInt packet id followed by the packet body.
 *
 * This decoder is defensive: every field read is bounds-checked and packet
 * parsing is wrapped in try/catch by the caller, because a modified client or a
 * proxy may speak something slightly different.
 */
(function (root, factory) {
  var api = factory();
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  root.EaglerV18 = api;
})(typeof globalThis !== "undefined" ? globalThis : this, function () {
  "use strict";

  // ---------------------------------------------------------------------------
  // Binary reader
  // ---------------------------------------------------------------------------
  function Reader(src) {
    if (src instanceof Uint8Array) {
      this.bytes = src;
    } else if (src instanceof ArrayBuffer) {
      this.bytes = new Uint8Array(src);
    } else if (ArrayBuffer.isView(src)) {
      this.bytes = new Uint8Array(src.buffer, src.byteOffset, src.byteLength);
    } else {
      throw new TypeError("Reader expects ArrayBuffer or typed array");
    }
    this.view = new DataView(this.bytes.buffer, this.bytes.byteOffset, this.bytes.byteLength);
    this.pos = 0;
  }
  Reader.prototype = {
    remaining: function () { return this.bytes.length - this.pos; },
    need: function (n) {
      if (this.pos + n > this.bytes.length) throw new RangeError("packet underflow: need " + n + " at " + this.pos + "/" + this.bytes.length);
    },
    u8: function () { this.need(1); return this.view.getUint8(this.pos++); },
    i8: function () { this.need(1); return this.view.getInt8(this.pos++); },
    bool: function () { return this.u8() !== 0; },
    i16: function () { this.need(2); var v = this.view.getInt16(this.pos); this.pos += 2; return v; },
    u16: function () { this.need(2); var v = this.view.getUint16(this.pos); this.pos += 2; return v; },
    i32: function () { this.need(4); var v = this.view.getInt32(this.pos); this.pos += 4; return v; },
    i64: function () { this.need(8); var v = this.view.getBigInt64(this.pos); this.pos += 8; return v; },
    u64: function () { this.need(8); var v = this.view.getBigUint64(this.pos); this.pos += 8; return v; },
    f32: function () { this.need(4); var v = this.view.getFloat32(this.pos); this.pos += 4; return v; },
    f64: function () { this.need(8); var v = this.view.getFloat64(this.pos); this.pos += 8; return v; },
    varint: function () {
      var value = 0, bytes = 0, b;
      do {
        this.need(1);
        b = this.bytes[this.pos++];
        value |= (b & 0x7f) << (7 * bytes);
        if (++bytes > 5) throw new RangeError("VarInt too long");
      } while (b & 0x80);
      return value | 0; // values we care about are non-negative and < 2^31
    },
    string: function (max) {
      var len = this.varint();
      if (len < 0 || len > (max || 32767)) throw new RangeError("string too long: " + len);
      this.need(len);
      var s = "";
      // UTF-8 decode without TextDecoder dependency for small strings
      if (typeof TextDecoder !== "undefined") {
        s = new TextDecoder("utf-8").decode(this.bytes.subarray(this.pos, this.pos + len));
      } else {
        for (var i = 0; i < len; i++) s += String.fromCharCode(this.bytes[this.pos + i]);
      }
      this.pos += len;
      return s;
    },
    /** 1.8 block position: x(26) y(12) z(26) packed into a long. */
    position: function () {
      var v = this.u64();
      var x = Number(v >> 38n);
      var y = Number(v & 0xfffn);
      var z = Number((v >> 12n) & 0x3ffffffn);
      if (x >= 33554432) x -= 67108864;
      if (y >= 2048) y -= 4096;
      if (z >= 33554432) z -= 67108864;
      return { x: x, y: y, z: z };
    },
    /** Angle stored as a byte (1/256 turns). */
    angle: function () { return (this.u8() * 360) / 256; },
    take: function (n) {
      this.need(n);
      var out = this.bytes.subarray(this.pos, this.pos + n);
      this.pos += n;
      return out;
    },
    rest: function () { var out = this.bytes.subarray(this.pos); this.pos = this.bytes.length; return out; }
  };

  // ---------------------------------------------------------------------------
  // Chat component flattening
  // ---------------------------------------------------------------------------
  var TRANSLATE_FALLBACKS = {
    "chat.type.text": "%s: %s",
    "chat.type.announcement": "[%s] %s",
    "chat.type.emote": "* %s %s",
    "chat.type.admin": "[%s: %s]",
    "chat.type.achievement": "%s has just earned the achievement %s",
    "chat.type.advancement.task": "%s has made the advancement %s",
    "chat.type.advancement.challenge": "%s has completed the challenge %s",
    "chat.type.advancement.goal": "%s has reached the goal %s",
    "commands.message.display.incoming": "%s whispers to you: %s",
    "commands.message.display.outgoing": "You whisper to %s: %s",
    "death.attack.outOfWorld": "%s fell out of the world",
    "death.attack.generic": "%s died",
    "death.attack.player": "%s was slain by %s",
    "death.attack.mob": "%s was slain by %s",
    "death.attack.explosion.player": "%s was blown up by %s",
    "death.fell.accident.generic": "%s fell from a high place",
    "multiplayer.player.joined": "%s joined the game",
    "multiplayer.player.left": "%s left the game"
  };

  function stripFormatting(s) {
    if (typeof s !== "string") return "";
    // § colour/style codes. Keep the text, drop the codes.
    var out = s.replace(/\u00a7./g, "");
    // Eaglercraft sometimes uses &-codes in MOTD-style text; leave those alone.
    return out;
  }

  function componentToText(comp) {
    if (comp == null) return "";
    if (typeof comp === "string") return stripFormatting(comp);
    if (Array.isArray(comp)) {
      var parts = [];
      for (var i = 0; i < comp.length; i++) parts.push(componentToText(comp[i]));
      return parts.join("");
    }
    if (typeof comp === "object") {
      var text = typeof comp.text === "string" ? stripFormatting(comp.text) : "";
      var extras = Array.isArray(comp.extra) ? comp.extra.map(componentToText).join("") : "";
      if (comp.translate) {
        var args = Array.isArray(comp.with) ? comp.with.map(componentToText) : [];
        var fmt = TRANSLATE_FALLBACKS[comp.translate];
        var rendered = fmt || comp.translate;
        var ai = 0;
        rendered = rendered.replace(/%[sd]/g, function () {
          return ai < args.length ? args[ai++] : "%s";
        });
        text = stripFormatting(rendered) + text;
      }
      return text + extras;
    }
    return "";
  }

  var LEGACY_CODE_RE = /\u00a7[0-9a-fk-or]/gi;

  function decodeChatJson(jsonText) {
    if (typeof jsonText !== "string") return "";
    var trimmed = jsonText.trim();
    if (!trimmed) return "";
    if (trimmed[0] !== "{" && trimmed[0] !== "[" && trimmed[0] !== '"') {
      // Plain text (some servers send raw strings)
      return stripFormatting(trimmed).replace(LEGACY_CODE_RE, "").trim();
    }
    try {
      return componentToText(JSON.parse(trimmed)).replace(/\s+/g, " ").trim();
    } catch (e) {
      return stripFormatting(trimmed.replace(/^"|"$/g, "")).replace(LEGACY_CODE_RE, "").trim();
    }
  }

  // ---------------------------------------------------------------------------
  // Packet tables
  // ---------------------------------------------------------------------------
  // Post-handshake packet ids that matter for state reconstruction.
  var CLIENTBOUND = {
    0x00: "keep_alive",
    0x01: "join_game",
    0x02: "chat",
    0x03: "time_update",
    0x05: "spawn_position",
    0x06: "update_health",
    0x07: "respawn",
    0x08: "player_position_look",
    0x09: "held_item_change",
    0x2a: "change_game_state",
    0x38: "player_list_header_footer",
    0x39: "player_abilities",
    0x3b: "scoreboard_objective",
    0x3c: "update_score",
    0x3d: "display_scoreboard",
    0x3f: "plugin_message",
    0x40: "disconnect",
    0x45: "title",
    0x47: "player_list_item",
    0x48: "resource_pack_send",
    0x1e: "set_experience",
    0x12: "entity_velocity"
  };

  var SERVERBOUND = {
    0x00: "keep_alive",
    0x01: "chat",
    0x02: "use_entity",
    0x03: "player",
    0x04: "player_position",
    0x05: "player_look",
    0x06: "player_position_look",
    0x07: "player_digging",
    0x08: "player_block_placement",
    0x09: "held_item_change",
    0x0a: "animation",
    0x0b: "entity_action",
    0x0c: "steer_vehicle",
    0x0d: "close_window",
    0x0e: "click_window",
    0x0f: "confirm_transaction",
    0x10: "creative_inventory_action",
    0x13: "player_abilities",
    0x15: "client_settings",
    0x16: "client_status",
    0x17: "plugin_message"
  };

  /**
   * Eaglercraft handshake ("EAG") protocol ids — verified against the reference
   * server implementation (lax1dude/eaglerxserver, HandshakePacketTypes.java).
   * Note: several third-party proxies use an older/invented numbering; these are
   * the values the real server and client speak.
   */
  var EAG = {
    0x01: "client_version",   // C->S  the initial packet (also carries "auth" flag + username in !auth mode)
    0x02: "server_version",   // S->C  selected protocol/game version + server brand
    0x03: "version_mismatch", // S->C  server rejects our version list
    0x04: "request_login",    // C->S  username, server, password, cookie, capabilities
    0x05: "allow_login",      // S->C  assigned username + uuid + capabilities
    0x06: "deny_login",       // S->C  kick message
    0x07: "profile_data",     // C->S  e.g. skin blob ("EAG|Skins-1.8")
    0x08: "finish_login",     // C->S  end of client handshake
    0x09: "server_finish",    // S->C  handshake complete -> vanilla play begins
    0x0a: "redirect",         // S->C  login-state redirect to another server
    0xff: "error"             // S->C  error code + message
  };

  /** EAG protocol versions this client speaks (V2..V5 family; V3 is MC 1.8). */
  var EAG_PROTOCOL_VERSIONS = [5, 4, 3, 2];

  /** Capability bits used in request_login (EnumCapabilityType in the server). */
  var EAG_CAPABILITIES = {
    UPDATE: 0, VOICE: 1, REDIRECT: 2, NOTIFICATION: 3,
    PAUSE_MENU: 4, WEBVIEW: 5, COOKIE: 6, OPTIFINE_CIT: 8
  };

  /** Reads the u16 count + u16[] protocol/game version lists of packet 0x01. */
  function readVersionList(r) {
    var n = r.u16();
    if (n < 1 || n > 16) throw new RangeError("bad version list length " + n);
    var out = [];
    for (var i = 0; i < n; i++) out.push(r.u16());
    return out;
  }

  /** u8-length ASCII string (different from Minecraft's VarInt strings!). */
  function readAscii8(r) {
    var len = r.u8();
    var bytes = r.take(len);
    var s = "";
    for (var i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i]);
    return s;
  }

  /** Reads a VarInt with the server's 5-byte cap. */
  function readVarInt5(r) {
    return r.varint();
  }

  /**
   * Decode the initial client packet (0x01) — the packet that tells the server
   * which EAG protocol + Minecraft versions we speak.
   *
   * Layout (HandshakerInstance.handlePacketInit + WebSocketEaglerInitialHandler):
   *   u8   0x01
   *   u16  count of EAG protocol versions, then count * u16
   *   u16  count of Minecraft protocol versions, then count * u16
   *   u8 len + ASCII  client brand   ("EaglercraftX")
   *   u8 len + ASCII  client version ("u3")
   *   bool auth-handed (true when the client is doing online-mode auth)
   *   u8 len + ASCII  auth username (empty when auth-handed is false)
   */
  function decodeEagClientVersion(buf) {
    var r = new Reader(buf);
    if (r.u8() !== 0x01) return null;
    // The reference client writes a legacy-protocol byte (0x02) immediately
    // after the packet id; the server reads it as "b2 == 2" before the lists.
    var legacyProtocol = r.u8();
    var eagVersions = readVersionList(r);
    var mcVersions = readVersionList(r);
    var brand = readAscii8(r);
    var version = readAscii8(r);
    var auth = r.bool();
    var username = readAscii8(r);
    if (r.remaining() > 0) return null; // strict: real servers reject trailing bytes
    return {
      packet: "client_version",
      legacy_protocol: legacyProtocol,
      eag_protocol_versions: eagVersions,
      mc_protocol_versions: mcVersions,
      brand: brand,
      version: version,
      auth: auth,
      username: username || null,
      selected_eag: Math.max.apply(null, eagVersions),
      selected_mc: Math.max.apply(null, mcVersions)
    };
  }

  /**
   * Decode server_version (0x02):
   *   u8 0x02, u16 selected EAG protocol, u16 selected MC protocol,
   *   u8 len + ASCII server brand, u8 len + ASCII server version,
   *   u8 auth method, u16 salt len + salt, [V5 only] bool nickname selection
   */
  function decodeEagServerVersion(buf) {
    var r = new Reader(buf);
    if (r.u8() !== 0x02) return null;
    var eag = r.u16();
    var mc = r.u16();
    var brand = readAscii8(r);
    var version = readAscii8(r);
    var authMethod = r.u8();
    var saltLen = r.u16();
    r.take(saltLen);
    var nicknameSelection = null;
    if (r.remaining() > 0) nicknameSelection = r.bool();
    return {
      packet: "server_version",
      eag_protocol: eag,
      mc_protocol: mc,
      brand: brand,
      version: version,
      auth_method: authMethod,
      nickname_selection: nicknameSelection
    };
  }

  /**
   * Decode client request_login (0x04), V5 layout (varint-only tail used by V1):
   *   u8 len + ASCII username, u8 len + ASCII requested server,
   *   u8 len + bytes password, bool enable cookie, u8 len + cookie bytes,
   *   VarInt standard capability mask, then one VarInt per set bit (versions),
   *   u8 ext capability count [+ 16-byte uuid + VarInt version each]
   */
  function decodeEagRequestLogin(buf, protocol) {
    var r = new Reader(buf);
    if (r.u8() !== 0x04) return null;
    var username = readAscii8(r);
    var requestedServer = readAscii8(r);
    var pwLen = r.u8();
    r.take(pwLen);
    var out = { packet: "request_login", username: username, requested_server: requestedServer, protocol: protocol || null };
    if ((protocol || 5) >= 2) {
      var cookie = r.bool();
      var cookieLen = r.u8();
      out.cookie = cookie ? r.take(cookieLen).length : 0;
      var mask = readVarInt5(r);
      out.capability_mask = mask;
      out.capabilities = [];
      for (var bit = 0; bit < 32; bit++) {
        if (mask & (1 << bit)) {
          try { out.capabilities.push({ bit: bit, version: readVarInt5(r) }); } catch (e) { break; }
        }
      }
      if (r.remaining() > 0) {
        try {
          var ext = r.u8();
          out.extended_capabilities = ext;
        } catch (e) { /* ignore */ }
      }
    }
    return out;
  }

  /**
   * Decode server allow_login (0x05):
   *   u8 len + ASCII username, 16-byte UUID, VarInt capability mask,
   *   (bitCount) bytes of versions, u8 ext count [...]
   */
  function decodeEagAllowLogin(buf) {
    var r = new Reader(buf);
    if (r.u8() !== 0x05) return null;
    var username = readAscii8(r);
    var uuidBytes = r.take(16);
    var hex = "";
    for (var i = 0; i < 16; i++) hex += (uuidBytes[i] < 16 ? "0" : "") + uuidBytes[i].toString(16);
    var mask = readVarInt5(r);
    var bitCount = 0;
    for (var b = 0; b < 32; b++) if (mask & (1 << b)) bitCount++;
    try { r.take(bitCount); } catch (e) { /* tolerate */ }
    return {
      packet: "allow_login",
      username: username,
      uuid: hex.replace(/^(.{8})(.{4})(.{4})(.{4})(.{12})$/, "$1-$2-$3-$4-$5"),
      capability_mask: mask
    };
  }

  /** Decode deny_login (0x06): u16 length + UTF-8 message. */
  function decodeEagDenyLogin(buf) {
    var r = new Reader(buf);
    if (r.u8() !== 0x06) return null;
    var len = r.u16();
    var bytes = r.take(len);
    var msg = "";
    if (typeof TextDecoder !== "undefined") msg = new TextDecoder("utf-8").decode(bytes);
    else for (var i = 0; i < bytes.length; i++) msg += String.fromCharCode(bytes[i]);
    return { packet: "deny_login", message: stripFormatting(msg).trim(), raw: msg.slice(0, 2000) };
  }

  /**
   * Decode server error (0xFF): u8 error code, then a length-prefixed message
   * whose prefix width depends on the handshake protocol (u8 for V1, u16 after).
   */
  function decodeEagError(buf, protocol) {
    var r = new Reader(buf);
    if (r.u8() !== 0xff) return null;
    var code = r.u8();
    var len = (protocol || 3) === 1 ? r.u8() : r.u16();
    var bytes = r.take(len);
    var msg = "";
    if (typeof TextDecoder !== "undefined") msg = new TextDecoder("utf-8").decode(bytes);
    else for (var i = 0; i < bytes.length; i++) msg += String.fromCharCode(bytes[i]);
    return { packet: "error", code: code, code_name: EAG_ERRORS[code] || ("error_" + code), message: stripFormatting(msg).trim() };
  }

  var EAG_ERRORS = {
    0x01: "unknown_packet", 0x02: "invalid_packet", 0x03: "wrong_packet",
    0x04: "excessive_profile_data", 0x05: "duplicate_profile_data",
    0x06: "ratelimit_blocked", 0x07: "ratelimit_locked",
    0x08: "custom_message", 0x09: "authentication_required"
  };

  /** Decode version_mismatch (0x03): declared supported versions. */
  function decodeEagVersionMismatch(buf) {
    var r = new Reader(buf);
    if (r.u8() !== 0x03) return null;
    var eag = readVersionList(r);
    var mc = readVersionList(r);
    return { packet: "version_mismatch", server_eag_versions: eag, server_mc_versions: mc };
  }

  /**
   * Decode login-state redirect (0x0A): u16 length + UTF-8 address.
   */
  function decodeEagRedirect(buf) {
    var r = new Reader(buf);
    if (r.u8() !== 0x0a) return null;
    var len = r.u16();
    var bytes = r.take(len);
    var addr = "";
    if (typeof TextDecoder !== "undefined") addr = new TextDecoder("utf-8").decode(bytes);
    else for (var i = 0; i < bytes.length; i++) addr += String.fromCharCode(bytes[i]);
    return { packet: "redirect", address: addr };
  }

  /** Generic dispatch: decode any serverbound handshake packet we know. */
  function decodeEagClientbound(buf, protocol) {
    var u8 = buf instanceof Uint8Array ? buf : new Uint8Array(buf);
    if (!u8.length) return null;
    switch (u8[0]) {
      case 0x02: return decodeEagServerVersion(u8);
      case 0x03: return decodeEagVersionMismatch(u8);
      case 0x05: return decodeEagAllowLogin(u8);
      case 0x06: return decodeEagDenyLogin(u8);
      case 0x08: return { packet: "finish_login" };
      case 0x09: return { packet: "server_finish" };
      case 0x0a: return decodeEagRedirect(u8);
      case 0xff: return decodeEagError(u8, protocol);
      default: return null;
    }
  }

  /** Generic dispatch: decode any clientbound (client->server) handshake packet. */
  function decodeEagServerbound(buf, protocol) {
    var u8 = buf instanceof Uint8Array ? buf : new Uint8Array(buf);
    if (!u8.length) return null;
    switch (u8[0]) {
      case 0x01: return decodeEagClientVersion(u8);
      case 0x04: return decodeEagRequestLogin(u8, protocol);
      case 0x07: return { packet: "profile_data" };
      case 0x08: return { packet: "finish_login" };
      default: return null;
    }
  }

  /**
   * True when a frame starts like a handshake packet of the given direction.
   * The initial client packet always begins 0x01 0x00 .. (V2+ list starts with
   * a u16 count of 1..16, i.e. second byte 0x00 and a small third byte).
   */
  /**
   * Is this frame plausibly the FIRST handshake packet (client_version, 0x01)?
   * Only used while the connection is still in the pre-handshake state; after
   * that the sniffer relies on the explicit state machine below, never on
   * byte guessing (MC play packet 0x01 is chat, so heuristics are unsafe).
   */
  function isEagStart(buf, dir) {
    var u8 = buf instanceof Uint8Array ? buf : new Uint8Array(buf);
    if (dir === "clientbound" || dir === "s2c") {
      // server_version answers our client_version: u16 eag protocol follows.
      return u8.length >= 7 && u8[0] === 0x02;
    }
    // Reference client: 0x01 (client_version), 0x02 (legacy protocol),
    // then a u16 count whose high byte is 0.
    if (u8.length >= 8 && u8[0] === 0x01 && u8[1] === 0x02 && u8[2] === 0x00) return true;
    // Very old V1 clients: 0x01, 0x01, mc protocol byte...
    return u8.length >= 6 && u8[0] === 0x01 && u8[1] === 0x01;
  }

  /**
   * Build the handshake the bridge sends when acting as a client (mirror mode).
   * @param {{username:string, brand?:string, version?:string, mcVersions?:number[]}} o
   */
  function buildEagClientVersion(o) {
    var eagVersions = (o && o.eagVersions) || EAG_PROTOCOL_VERSIONS;
    var mcVersions = (o && o.mcVersions) || [47];
    var brand = (o && o.brand) || "Eagler-LLM-Bridge";
    var version = (o && o.version) || "1.0.0";
    // 0x01 = client_version, 0x02 = legacy protocol byte (what the real client
    // sends; servers check it before reading the version lists).
    var out = [0x01, 0x02];
    out.push((eagVersions.length >> 8) & 0xff, eagVersions.length & 0xff);
    for (var i = 0; i < eagVersions.length; i++) out.push((eagVersions[i] >> 8) & 0xff, eagVersions[i] & 0xff);
    out.push((mcVersions.length >> 8) & 0xff, mcVersions.length & 0xff);
    for (var j = 0; j < mcVersions.length; j++) out.push((mcVersions[j] >> 8) & 0xff, mcVersions[j] & 0xff);
    function ascii8(str) {
      str = String(str).slice(0, 255);
      out.push(str.length);
      for (var k = 0; k < str.length; k++) out.push(str.charCodeAt(k) & 0x7f);
    }
    ascii8(brand);
    ascii8(version);
    out.push(0);       // auth = false (offline mode)
    ascii8((o && o.username) || "");
    return new Uint8Array(out);
  }

  /**
   * Build request_login (0x04) for handshake protocol V5/V4/V3.
   *
   * EaglercraftXServer reads the offline username from client_version's
   * authUsername field; the name inside request_login is only honored when the
   * server advertised nicknameSelection=true (V5). Otherwise it must be sent as
   * a zero-length string, exactly like the reference client does.
   *
   *   buildEagRequestLogin("Name", "default", 5, { nicknameSelection: false })
   */
  function buildEagRequestLogin(username, requestedServer, protocol, opts) {
    var out = [0x04];
    function ascii8(str) {
      str = String(str || "").slice(0, 255);
      out.push(str.length);
      for (var k = 0; k < str.length; k++) out.push(str.charCodeAt(k) & 0x7f);
    }
    function varint(v) { v >>>= 0; for (;;) { var b = v & 0x7f; v >>>= 7; if (!v) { out.push(b); return; } out.push(b | 0x80); } }
    var nicknameSelection = (opts && opts.nicknameSelection !== undefined)
      ? !!opts.nicknameSelection
      : !!(username && String(username).length);
    ascii8(nicknameSelection ? username : "");
    ascii8(requestedServer || "");
    out.push(0);       // password length 0
    if ((protocol || 5) >= 2) {
      out.push(0);     // enableCookie = false
      out.push(0);     // cookie length 0
      var mask = (1 << EAG_CAPABILITIES.UPDATE) | (1 << EAG_CAPABILITIES.VOICE);
      varint(mask);
      varint(1);       // UPDATE version
      varint(1);       // VOICE version
      out.push(0);     // extended capability count
    }
    return new Uint8Array(out);
  }

  function buildEagProfileData(key, bytes) {
    var out = [0x07];
    var k = String(key).slice(0, 255);
    out.push(k.length);
    for (var i = 0; i < k.length; i++) out.push(k.charCodeAt(i) & 0x7f);
    out.push((bytes.length >> 8) & 0xff, bytes.length & 0xff);
    for (var j = 0; j < bytes.length; j++) out.push(bytes[j]);
    return new Uint8Array(out);
  }

  function buildEagFinishLogin() { return new Uint8Array([0x08]); }

  // ---------------------------------------------------------------------------
  // Decoders: clientbound (server -> client)
  // ---------------------------------------------------------------------------
  function decodeClientbound(id, r, out) {
    switch (id) {
      case 0x01: // Join Game
        out.entity_id = r.i32();
        out.gamemode = r.u8() & 0x07;
        out.hardcore = false; // hardcore flag lives in the high bits of the same byte; not tracked
        out.dimension = r.i8();
        out.difficulty = r.u8();
        out.max_players = r.u8();
        out.level_type = r.string(16);
        out.reduced_debug = r.bool();
        break;
      case 0x02: { // Chat Message
        var json = r.string(32767);
        out.position = r.u8();
        out.text = decodeChatJson(json);
        out.json = json.length > 4000 ? json.slice(0, 4000) : json;
        break;
      }
      case 0x03:
        out.world_age = Number(r.i64());
        out.time_of_day = Number(r.i64());
        break;
      case 0x05:
        out.spawn = r.position();
        break;
      case 0x06:
        out.health = r.f32();
        out.food = r.varint();
        out.saturation = r.f32();
        break;
      case 0x07:
        out.dimension = r.i32();
        out.difficulty = r.u8();
        out.gamemode = r.u8() & 0x07;
        out.level_type = r.string(16);
        break;
      case 0x08:
        out.x = r.f64();
        out.y = r.f64();
        out.z = r.f64();
        out.yaw = r.f32();
        out.pitch = r.f32();
        out.flags = r.u8();
        break;
      case 0x09:
        out.slot = r.i8();
        break;
      case 0x1e:
        out.xp_bar = r.f32();
        out.xp_level = r.varint();
        out.xp_total = r.varint();
        break;
      case 0x2a: { // Change Game State
        out.reason = r.u8();
        out.value = r.f32();
        break;
      }
      case 0x38: {
        out.header = decodeChatJson(r.string(32767));
        out.footer = decodeChatJson(r.string(32767));
        break;
      }
      case 0x39: {
        var flags = r.u8();
        out.invulnerable = (flags & 0x01) !== 0;
        out.flying = (flags & 0x02) !== 0;
        out.allow_flying = (flags & 0x04) !== 0;
        out.creative_mode = (flags & 0x08) !== 0;
        out.fly_speed = r.f32();
        out.walk_speed = r.f32();
        break;
      }
      case 0x3b: { // Scoreboard Objective
        out.name = r.string(16);
        out.mode = r.u8();
        if (out.mode < 2) {
          out.display_name = decodeChatJson(r.string(32));
          out.type = r.string(16);
        }
        break;
      }
      case 0x3c: { // Update Score
        out.entry = r.string(40);
        out.action = r.varint();
        out.objective = r.string(16);
        if (out.action === 0) {
          out.value = r.varint();
        }
        break;
      }
      case 0x3d: { // Display Scoreboard
        out.position = r.i8();
        out.objective = r.string(16);
        break;
      }
      case 0x3f: {
        out.channel = r.string(20);
        break;
      }
      case 0x40:
        out.reason = decodeChatJson(r.string(32767));
        break;
      case 0x45: { // Title
        out.action = r.varint();
        if (out.action === 0 || out.action === 1 || out.action === 2) {
          try { out.text = decodeChatJson(r.string(32767)); } catch (e) { out.text = ""; }
        }
        break;
      }
      case 0x47: {
        out.action = r.varint();
        out.count = r.varint();
        break;
      }
      default:
        return false;
    }
    return true;
  }

  // ---------------------------------------------------------------------------
  // Decoders: serverbound (client -> server)
  // ---------------------------------------------------------------------------
  function decodeServerbound(id, r, out) {
    switch (id) {
      case 0x01:
        out.text = r.string(100);
        break;
      case 0x02:
        out.target = r.varint();
        out.type = r.varint(); // 0 interact, 1 attack, 2 interact_at
        break;
      case 0x03:
        out.on_ground = r.bool();
        break;
      case 0x04:
        out.x = r.f64(); out.y = r.f64(); out.z = r.f64();
        out.on_ground = r.bool();
        break;
      case 0x05:
        out.yaw = r.f32(); out.pitch = r.f32();
        out.on_ground = r.bool();
        break;
      case 0x06:
        out.x = r.f64(); out.y = r.f64(); out.z = r.f64();
        out.yaw = r.f32(); out.pitch = r.f32();
        out.on_ground = r.bool();
        break;
      case 0x07: { // Player Digging
        out.status = r.i8(); // 0 start, 1 cancel, 2 finish, 5 shoot arrow etc.
        out.position = r.position();
        out.face = r.i8();
        break;
      }
      case 0x08: { // Block Placement
        out.position = r.position();
        out.face = r.i8();
        out.held_item = r.i16();
        out.cursor_x = r.i8(); out.cursor_y = r.i8(); out.cursor_z = r.i8();
        break;
      }
      case 0x09:
        out.slot = r.i16();
        break;
      case 0x0b: { // Entity Action
        out.entity_id = r.varint();
        out.action = r.varint();
        out.action_name = ["start_sneaking", "stop_sneaking", "leave_bed", "start_sprinting", "stop_sprinting", "start_horse_jump", "stop_horse_jump"][out.action] || ("action_" + out.action);
        break;
      }
      case 0x0e: { // Click Window (inventory automation)
        out.window_id = r.u8();
        out.slot = r.i16();
        out.button = r.i8();
        out.action_number = r.i16();
        out.mode = r.i8();
        break;
      }
      case 0x10:
        out.slot = r.i16();
        break;
      case 0x13: {
        var flags = r.u8();
        out.flying = (flags & 0x02) !== 0;
        break;
      }
      case 0x15: {
        out.locale = r.string(16);
        out.view_distance = r.i8();
        out.chat_mode = r.u8();
        out.chat_colors = r.bool();
        out.skin_parts = r.u8();
        break;
      }
      case 0x16:
        out.action = r.varint(); // 0 = perform respawn
        break;
      case 0x17:
        out.channel = r.string(20);
        break;
      default:
        return false;
    }
    return true;
  }

  // ---------------------------------------------------------------------------
  // Public entry points
  // ---------------------------------------------------------------------------

  /**
   * Decode a post-handshake vanilla packet.
   * @param {ArrayBuffer|Uint8Array} buf  one WebSocket frame
   * @param {"clientbound"|"serverbound"} dir
   * @returns {{id:number,name:string,data:object,ok:boolean,error?:string,length:number}}
   */
  function decodePacket(buf, dir) {
    var r = new Reader(buf);
    var length = r.bytes.length;
    var id;
    try {
      id = r.varint();
    } catch (e) {
      return { id: -1, name: "invalid", data: {}, ok: false, error: String(e), length: length };
    }
    var table = dir === "serverbound" ? SERVERBOUND : CLIENTBOUND;
    var name = table[id] || ("packet_0x" + id.toString(16));
    var out = {};
    var ok = false;
    try {
      ok = dir === "serverbound" ? decodeServerbound(id, r, out) : decodeClientbound(id, r, out);
    } catch (e) {
      return { id: id, name: name, data: out, ok: false, error: String(e), length: length };
    }
    return { id: id, name: name, data: out, ok: ok, length: length };
  }

  /**
   * Try to parse the Eaglercraft handshake stream (network version 3).
   * Returns the decoded serverbound login or null when the frame is not one.
   */
  function decodeEagLogin(buf) {
    var r = new Reader(buf);
    try {
      var id = r.varint();
      if (id !== 0x01) return null;
      var verCount = r.varint();
      var protocol = [];
      for (var i = 0; i < Math.min(verCount, 8); i++) protocol.push(r.varint());
      var gameCount = r.varint();
      var gameVersions = [];
      for (var j = 0; j < Math.min(gameCount, 8); j++) gameVersions.push(r.varint());
      var brand = r.string(64);
      var version = r.string(64);
      var username = r.string(64);
      return {
        packet: "cs_login",
        protocol_versions: protocol,
        game_versions: gameVersions,
        brand: brand,
        version: version,
        username: username
      };
    } catch (e) {
      return null;
    }
  }

  /** Decode the EAG identify packet (server -> client) if it is one. */
  function decodeEagIdentify(buf) {
    var r = new Reader(buf);
    try {
      if (r.varint() !== 0x02) return null;
      return {
        packet: "sc_identify",
        protocol_version: r.u16(),
        game_version: r.u16(),
        branding: r.string(64),
        version: r.string(64)
      };
    } catch (e) {
      return null;
    }
  }

  /** Decode an EAG disconnect packet (0xff) payload into plain text. */
  function decodeEagDisconnect(buf) {
    var r = new Reader(buf);
    try {
      if (r.varint() !== 0xff) return null;
      return { packet: "sc_disconnect", reason: decodeChatJson(r.string(32767)) };
    } catch (e) {
      return null;
    }
  }

  /**
   * Heuristic: does this frame look like the start of the EAG handshake?
   * Client login starts with 0x01 followed by a small protocol-version count.
   */
  function looksLikeHandshake(buf, dir) {
    var u8 = buf instanceof Uint8Array ? buf : new Uint8Array(buf);
    if (u8.length < 2 || u8.length > 4096) return false;
    var toServer = dir === "serverbound" || dir === "c2s";
    if (toServer) {
      return u8[0] === 0x01 && u8[1] >= 0x01 && u8[1] <= 0x08;
    }
    return u8[0] === 0x02 && u8.length >= 6;
  }

  /** True when a clientbound play packet is safe to decode by id alone. */
  function looksLikePlay(buf) {
    var u8 = buf instanceof Uint8Array ? buf : new Uint8Array(buf);
    if (u8.length < 2) return false;
    var id = u8[0]; // most of our ids are single-byte VarInts
    return CLIENTBOUND[id] !== undefined;
  }

  return {
    Reader: Reader,
    decodePacket: decodePacket,
    decodeChatJson: decodeChatJson,
    componentToText: componentToText,
    // EAG handshake (reference: lax1dude/eaglerxserver HandshakePacketTypes)
    EAG: EAG,
    EAG_PROTOCOL_VERSIONS: EAG_PROTOCOL_VERSIONS,
    EAG_CAPABILITIES: EAG_CAPABILITIES,
    decodeEagClientVersion: decodeEagClientVersion,
    decodeEagServerVersion: decodeEagServerVersion,
    decodeEagRequestLogin: decodeEagRequestLogin,
    decodeEagAllowLogin: decodeEagAllowLogin,
    decodeEagDenyLogin: decodeEagDenyLogin,
    decodeEagError: decodeEagError,
    decodeEagVersionMismatch: decodeEagVersionMismatch,
    decodeEagRedirect: decodeEagRedirect,
    decodeEagClientbound: decodeEagClientbound,
    decodeEagServerbound: decodeEagServerbound,
    buildEagClientVersion: buildEagClientVersion,
    buildEagRequestLogin: buildEagRequestLogin,
    buildEagProfileData: buildEagProfileData,
    buildEagFinishLogin: buildEagFinishLogin,
    isEagStart: isEagStart,
    looksLikePlay: looksLikePlay,
    CLIENTBOUND: CLIENTBOUND,
    SERVERBOUND: SERVERBOUND
  };
});
