/*
 * Live validation of the EAG handshake against REAL EaglercraftX servers.
 *
 * Uses Node's TLS stack to open the WebSocket by hand, then the bridge's own
 * builders/decoders (page/v1_8_parser.js) to perform the reference handshake:
 *
 *   C->S client_version(0x01)  S->C server_version(0x02)
 *   C->S request_login(0x04)   S->C allow_login(0x05) / deny_login(0x06) / error(0xFF)
 *
 * Any of those three answers proves the wire format is right.
 *
 *   node test/live-handshake.js                       # default sample list
 *   node test/live-handshake.js wss://host1 wss://host2
 */
"use strict";
const crypto = require("crypto");
const tls = require("tls");
const path = require("path");
const V = require(path.join(__dirname, "..", "page", "v1_8_parser.js"));

const DEFAULT_TARGETS = [
  "wss://play.heartsmp.net",
  "wss://mc.zyth.me",
  "wss://zentic.cc",
  "wss://tuff.ws",
  "wss://eagler.totalfreedom.tf"
];

const ORIGIN = process.env.PROBE_ORIGIN || "https://eaglercraft.com";
// Offline identity: the server takes this from client_version's authUsername and
// validates ^[A-Za-z0-9_]{3,16}$.
const USERNAME = (process.env.PROBE_USER || "BridgeBot" + Math.floor(Math.random() * 9000)).slice(0, 16);

function frame(payload, opcode = 0x2) {
  const data = Buffer.from(payload);
  const mask = crypto.randomBytes(4);
  let header;
  if (data.length < 126) {
    header = Buffer.from([0x80 | opcode, 0x80 | data.length]);
  } else if (data.length < 65536) {
    header = Buffer.alloc(4);
    header[0] = 0x80 | opcode;
    header[1] = 0x80 | 126;
    header.writeUInt16BE(data.length, 2);
  } else {
    header = Buffer.alloc(10);
    header[0] = 0x80 | opcode;
    header[1] = 0x80 | 127;
    header.writeBigUInt64BE(BigInt(data.length), 2);
  }
  const masked = Buffer.from(data.map((b, i) => b ^ mask[i & 3]));
  return Buffer.concat([header, mask, masked]);
}

function probe(url, timeoutMs = 9000) {
  return new Promise((resolve) => {
    const u = new URL(url);
    const host = u.hostname;
    const port = parseInt(u.port || "443", 10);
    const transcript = [];
    let settled = false;
    const done = (result) => {
      if (settled) return;
      settled = true;
      try { socket.destroy(); } catch (e) {}
      resolve({ url, ...result, transcript });
    };

    const key = crypto.randomBytes(16).toString("base64");
    const socket = tls.connect({ host, port, servername: host, timeout: timeoutMs }, () => {
      socket.write(
        `GET ${u.pathname || "/"} HTTP/1.1\r\n` +
        `Host: ${host}\r\n` +
        "Upgrade: websocket\r\nConnection: Upgrade\r\n" +
        `Sec-WebSocket-Key: ${key}\r\nSec-WebSocket-Version: 13\r\n` +
        `Origin: ${ORIGIN}\r\n\r\n`
      );
    });

    let hs = false;
    let buf = Buffer.alloc(0);
    let playMode = false;
    const playLog = [];
    let playFrames = 0;
    let seenUser = null;

    socket.on("data", (chunk) => {
      buf = Buffer.concat([buf, chunk]);
      if (!hs) {
        const i = buf.indexOf("\r\n\r\n");
        if (i < 0) return;
        const line = buf.subarray(0, i).toString().split("\r\n")[0];
        transcript.push({ step: "http", line });
        if (!/ 101 /.test(line)) return done({ ok: false, error: line });
        hs = true;
        buf = buf.subarray(i + 4);
        const cv = V.buildEagClientVersion({ username: USERNAME, brand: "EaglercraftX", version: "u3" });
        transcript.push({ step: "tx client_version", hex: Buffer.from(cv).toString("hex").slice(0, 60) });
        socket.write(frame(cv));
        // fall through: the same TCP segment may already hold a server frame
      }
      // Parse as many server frames as are complete
      for (;;) {
        if (buf.length < 2) return;
        const opcode = buf[0] & 0x0f;
        let len = buf[1] & 0x7f;
        let off = 2;
        if (len === 126) { if (buf.length < 4) return; len = buf.readUInt16BE(2); off = 4; }
        else if (len === 127) { if (buf.length < 10) return; len = Number(buf.readBigUInt64BE(2)); off = 10; }
        if (buf.length < off + len) return;
        const data = buf.subarray(off, off + len);
        buf = buf.subarray(off + len);

        if (opcode === 0x8) {
          const code = data.length >= 2 ? data.readUInt16BE(0) : null;
          transcript.push({ step: "close", code });
          return done({ ok: false, error: "closed by server", closeCode: code });
        }
        if (opcode !== 0x1 && opcode !== 0x2) continue;

        let msg = null;
        let decodeError = null;
        if (playMode) {
          try {
            const p = V.decodePacket(new Uint8Array(data), "clientbound");
            playLog.push(p.name);
            msg = { packet: "play:" + p.name };
          } catch (e) { msg = { packet: "play:undecoded" }; }
        } else {
          try { msg = V.decodeEagClientbound(new Uint8Array(data), 5); } catch (e) { decodeError = String(e); }
        }
        transcript.push({ step: "rx", len: data.length, hex: data.toString("hex").slice(0, 80), decoded: msg, decodeError });

        if (!msg) continue;
        if (msg.packet === "server_version") {
          const rl = V.buildEagRequestLogin(USERNAME, "default", msg.eag_protocol,
            { nicknameSelection: msg.nickname_selection === true });
          transcript.push({ step: "tx request_login", eag_protocol: msg.eag_protocol, hex: Buffer.from(rl).toString("hex").slice(0, 60) });
          socket.write(frame(rl));
        } else if (msg.packet === "allow_login") {
          seenUser = msg.username;
          const fin = V.buildEagFinishLogin ? V.buildEagFinishLogin() : [0x08];
          transcript.push({ step: "tx finish_login", hex: Buffer.from(fin).toString("hex") });
          socket.write(frame(fin));
        } else if (msg.packet === "server_finish") {
          transcript.push({ step: "play_start" });
          playMode = true;
          // handshake complete: ask for a couple of play packets to prove framing
          playFrames = 0;
          setTimeout(() => done({ ok: true, final: { packet: "play_start", username: seenUser, playPackets: playLog.slice(0, 8), playCount: playLog.length } }), 4000);
        } else if (msg.packet === "deny_login" || msg.packet === "error" || msg.packet === "version_mismatch") {
          return done({ ok: true, final: msg });
        }
      }
    });

    socket.on("error", (e) => done({ ok: false, error: e.code || e.message }));
    socket.on("timeout", () => done({ ok: false, error: "timeout" }));
    setTimeout(() => done({ ok: false, error: "overall timeout" }), timeoutMs + 1000);
  });
}

(async () => {
  const targets = process.argv.slice(2).length ? process.argv.slice(2) : DEFAULT_TARGETS;
  let decodedAny = false;
  for (const t of targets) {
    const r = await probe(t);
    const sv = r.transcript.find((x) => x.decoded && x.decoded.packet === "server_version");
    const fin = r.final;
    if (sv) decodedAny = true;
    console.log(
      (sv ? "  OK   " : "  --   ") + t +
      (sv ? `  server=${sv.decoded.brand} ${sv.decoded.version} eag=${sv.decoded.eag_protocol} mc=${sv.decoded.mc_protocol}` : "") +
      (fin ? `  -> ${fin.packet}${fin.username ? " (" + fin.username + ")" : ""}${fin.message ? ": " + fin.message.slice(0, 70) : ""}` : "") +
      (!sv ? "  " + (r.error || "") : "")
    );
    if (process.env.VERBOSE) console.log(JSON.stringify(r.transcript, null, 1));
  }
  console.log("\nusername:", USERNAME);
  console.log(decodedAny ? "RESULT: handshake decoded against real servers OK" : "\nRESULT: no real server answered");
  process.exit(decodedAny ? 0 : 1);
})();
