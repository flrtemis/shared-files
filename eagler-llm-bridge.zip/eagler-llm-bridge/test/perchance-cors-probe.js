/*
 * Which URLs may a MV3 content script talk to?
 *
 * The extension's content script runs on nite.games but must reach
 *   https://<hash>.perchance.org/...   (the Perchance generator frame)
 * fetched from the page's origin (not the extension's), so MV3 requires
 * connect-src / host_permissions entries; CORS also has to pass.
 *
 * Rather than guess, probe from a page: fetch the generator frame URL with and
 * without credentials and print what actually happens.
 */
"use strict";
const path = require("path");
const { chromium } = require(path.join(__dirname, "..", "node_modules", "playwright-core"));

const EXE = process.env.CHROME_BIN || "/home/user/.cache/ms-playwright/chromium-1194/chrome-linux/chrome";
const GEN = process.env.GEN || "https://perchance.org/g66gcru29s";

(async () => {
  const browser = await chromium.launch({ executablePath: EXE, headless: false, args: ["--no-sandbox"] });
  const page = await browser.newPage();
  await page.goto(GEN, { waitUntil: "domcontentloaded", timeout: 90000 });
  await page.waitForTimeout(7000);
  const frameUrl = (page.frames().find((f) => /\.perchance\.org\//.test(f.url())) || {}).url();
  console.log("generator frame:", frameUrl);

  // 1) Can the frame's own origin fetch itself (i.e. is it same-origin there)?
  const fromFrame = await page.frames().find((f) => /\.perchance\.org\//.test(f.url()))
    .evaluate(async () => {
      const r = await fetch(location.href, { method: "GET" }).catch((e) => ({ error: String(e) }));
      return r.error ? { error: r.error } : { status: r.status, len: (await r.text()).length };
    }).catch((e) => ({ error: String(e) }));

  // 2) Can a third-party origin (the top page) fetch the frame URL?
  const fromTop = await page.evaluate(async (u) => {
    const r = await fetch(u, { method: "GET" }).catch((e) => ({ error: String(e) }));
    return r.error ? { error: r.error } : { status: r.status, type: r.type };
  }, frameUrl).catch((e) => ({ error: String(e) }));

  console.log("fetch from inside the frame  :", JSON.stringify(fromFrame));
  console.log("fetch from the top page (CORS):", JSON.stringify(fromTop));
  await browser.close();
})();
