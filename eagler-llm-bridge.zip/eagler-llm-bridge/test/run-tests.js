#!/usr/bin/env node
/*
 * Eagler LLM Bridge — automated tests (no external dependencies).
 *
 *   node test/run-tests.js
 *
 * Part 1: unit tests for the Minecraft 1.8 decoder (real packet bytes).
 * Part 2: the mock Eaglercraft server speaking the EAG handshake.
 * Part 3: browser integration (Playwright, optional): loads the mock game page
 *         with the real page agent, drives it through the same postMessage
 *         protocol the content script uses, and asserts:
 *           - synthetic keys reach the "engine" with correct keyCode/key
 *           - chat macro types text and sends it over the socket
 *           - the sniffer decodes chat/HUD/position from the server
 *           - canvas capture returns a JPEG
 */
"use strict";

function findChrome() {
  const cache = path.join(process.env.HOME || "/root", ".cache", "ms-playwright");
  const candidates = [];
  try {
    for (const dir of fs.readdirSync(cache).sort().reverse()) {
      for (const rel of ["chrome-linux64/chrome", "chrome-linux/chrome"]) {
        candidates.push(path.join(cache, dir, rel));
      }
    }
  } catch (e) { /* no playwright cache */ }
  candidates.push("/usr/bin/chromium", "/usr/bin/google-chrome", "/usr/bin/chromium-browser");
  return candidates.find((c) => { try { return fs.statSync(c).isFile(); } catch (e) { return false; } }) || null;
}

const path = require("path");
const fs = require("fs");
const http = require("http");
const { spawn } = require("child_process");

const ROOT = path.join(__dirname, "..");
const results = [];
function check(name, ok, detail) {
  results.push({ name, ok: !!ok, detail });
  console.log((ok ? "  \u2713 " : "  \u2717 ") + name + (detail && !ok ? "  -> " + JSON.stringify(detail).slice(0, 400) : ""));
}

// ---------------------------------------------------------------------------
// Part 1 — decoder units
// ---------------------------------------------------------------------------
function unitTests() {
  console.log("\n[1] decoder unit tests");
  const V = require(path.join(ROOT, "page/v1_8_parser.js"));
  const { W, packets } = require("./lib/proto.js");

  // chat with translate + with[]
  const chatPkt = packets.chat({ translate: "chat.type.text", with: [{ text: "Alex" }, { text: "hello <world>" }] }, 0);
  const d1 = V.decodePacket(chatPkt, "clientbound");
  check("chat packet id/name", d1.id === 0x02 && d1.name === "chat", d1);
  check("chat flattens translate+with", d1.data.text === "Alex: hello <world>", d1.data);

  // legacy colour codes are stripped
  const d2 = V.decodePacket(packets.chat({ text: "\u00a7aGreen\u00a7r text" }, 1), "clientbound");
  check("chat strips legacy colour codes", d2.data.text === "Green text" && d2.data.position === 1, d2.data);

  // join game
  const d3 = V.decodePacket(packets.joinGame(), "clientbound");
  check("join_game decodes", d3.name === "join_game" && d3.data.gamemode === 0 && d3.data.max_players === 20, d3.data);

  // position
  const d4 = V.decodePacket(packets.position(1.5, 64, -3.5, 90, 10), "clientbound");
  check("position decodes", d4.data.x === 1.5 && d4.data.y === 64 && d4.data.z === -3.5 && Math.abs(d4.data.yaw - 90) < 0.01, d4.data);

  // health
  const d5 = V.decodePacket(packets.health(17.5, 14, 3.2), "clientbound");
  check("health decodes", d5.data.health === 17.5 && d5.data.food === 14, d5.data);

  // serverbound chat (used by injection assertions)
  const sb = (() => { const b = Buffer.from([0x01, 0x05, 104, 101, 108, 108, 111]); return b; })();
  const d6 = V.decodePacket(sb, "serverbound");
  check("serverbound chat decodes", d6.name === "chat" && d6.data.text === "hello", d6);

  // ---- EAG handshake, against the reference server layout ------------------
  const login = V.buildEagClientVersion({ username: "", brand: "EaglercraftX", version: "u3" });
  const d7 = V.decodeEagClientVersion(login);
  check("client_version: u16 lists + ascii strings",
    d7 && d7.eag_protocol_versions.join(",") === "5,4,3,2" && d7.mc_protocol_versions[0] === 47 && d7.brand === "EaglercraftX",
    d7);
  // Reference client writes 0x01 (id), 0x02 (legacy protocol byte), then the lists.
  check("client_version starts 0x01 0x02", login[0] === 0x01 && login[1] === 0x02 && login[2] === 0x00, Array.from(login.slice(0, 4)));

  // The offline name rides in client_version's authUsername field: the server
  // builds the UUID from it and ignores request_login's name unless the server
  // enabled nickname selection (V5).
  const named = V.buildEagClientVersion({ username: "BridgeBot", brand: "EaglercraftX", version: "u3" });
  const dn = V.decodeEagClientVersion(named);
  check("client_version carries the offline identity",
    dn && dn.username === "BridgeBot" && dn.auth === false, dn);
  const anon = V.decodeEagRequestLogin(V.buildEagRequestLogin("BridgeBot", "default", 5, { nicknameSelection: false }), 5);
  check("request_login drops the name when nickname selection is off", anon && anon.username === "", anon);
  const nick = V.decodeEagRequestLogin(V.buildEagRequestLogin("BridgeBot", "default", 5, { nicknameSelection: true }), 5);
  check("request_login keeps the name when nickname selection is on", nick && nick.username === "BridgeBot", nick);

  const serverVer = V.decodeEagServerVersion(packets.eagServerVersion(3, 47, "EaglerXServer"));
  check("server_version decodes", serverVer && serverVer.eag_protocol === 3 && serverVer.mc_protocol === 47, serverVer);

  const reqLogin = V.decodeEagRequestLogin(V.buildEagRequestLogin("Steve", "", 5), 5);
  check("request_login round-trips", reqLogin && reqLogin.username === "Steve" && reqLogin.capability_mask === 3, reqLogin);

  const allow = V.decodeEagAllowLogin(packets.eagAllowLogin("Steve", 3));
  check("allow_login decodes uuid + caps", allow && allow.username === "Steve" && /^07070707-0707-0707-0707-070707070707$/.test(allow.uuid), allow);

  const deny = V.decodeEagDenyLogin(packets.eagDenyLogin("Server is whitelist only"));
  check("deny_login carries the kick message", deny && /whitelist/.test(deny.message), deny);

  const err = V.decodeEagError(packets.eagError(0x03, "Wrong Packet"), 3);
  check("error decodes code name + message", err && err.code === 3 && err.code_name === "wrong_packet" && /Wrong Packet/.test(err.message), err);

  check("server_finish is recognised as the play boundary", V.decodeEagClientbound(new Uint8Array([0x09])).packet === "server_finish");
  check("play chat (0x01) is not mistaken for client_version", !V.isEagStart(new Uint8Array([0x01, 0x05, 0x68, 0x65, 0x6c, 0x6c, 0x6f]), "serverbound"));
  // A frame that merely starts with 0x01 is not a handshake, but the real
  // opening frame (0x01 0x02 with a sane version list) must be recognised --
  // a heuristic that missed this dropped every live connection.
  check("isEagStart accepts the reference client_version",
    V.isEagStart(V.buildEagClientVersion({ username: "BridgeBot" }), "serverbound"));

  // The content script once referenced FRAME_HINTS / lastAsked without declaring
  // them, which threw a pageerror on every frame sync in the live page. Loading
  // the file in a browser-shaped context catches that class of bug for free.
  try {
    const vm = require("vm");
    const ctx = vm.createContext({
      window: { addEventListener() {}, postMessage() {}, location: { href: "https://nite.games/game/minecraft" } },
      location: { href: "https://nite.games/game/minecraft", hostname: "nite.games" },
      document: { querySelectorAll() { return []; }, addEventListener() {}, body: {} },
      crypto: { randomUUID() { return "00000000-0000-0000-0000-000000000000"; } },
      chrome: { runtime: { id: "test", sendMessage() { return Promise.resolve(); }, onMessage: { addListener() {} } } },
      console: { log() {}, error() {} },
      setInterval, clearInterval, setTimeout, URL, performance
    });
    vm.runInContext(fs.readFileSync(path.join(ROOT, "content/content.js"), "utf8"), ctx, { filename: "content.js" });
    check("content script loads without reference errors", true);
  } catch (e) {
    check("content script loads without reference errors", false, String(e && e.message));
  }

  // robustness: truncated packet must not throw
  let threw = false;
  try { V.decodePacket(Buffer.from([0x02, 0x40, 0x61]), "clientbound"); } catch (e) { threw = true; }
  check("truncated packet returns instead of throwing", !threw);

  // varint edge cases
  const r = new V.Reader(Buffer.from([0xac, 0x02]));
  check("varint multi-byte", r.varint() === 300);
}

// ---------------------------------------------------------------------------
// Part 2 — mock server (raw WS, no browser)
// ---------------------------------------------------------------------------
async function serverTests() {
  console.log("\n[2] mock Eaglercraft server");
  const { MockEaglerServer } = require("./mock-eagler-server.js");
  const srv = new MockEaglerServer();
  const port = await srv.start();
  check("server listens", port > 0, port);

  // A raw client performing the handshake proves the fixtures are wire-accurate
  const http2 = require("http");
  const crypto = require("crypto");
  const sock = require("net").connect(port, "127.0.0.1");
  const key = crypto.randomBytes(16).toString("base64");
  await new Promise((resolve, reject) => {
    sock.on("connect", () => {
      sock.write(`GET / HTTP/1.1\r\nHost: 127.0.0.1:${port}\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Key: ${key}\r\nSec-WebSocket-Version: 13\r\n\r\n`);
    });
    let buf = Buffer.alloc(0);
    sock.on("data", (d) => {
      buf = Buffer.concat([buf, d]);
      if (buf.includes("\r\n\r\n")) resolve();
    });
    sock.on("error", reject);
    setTimeout(() => resolve(), 1500);
  });
  check("HTTP upgrade handshake", bufIncludesUpgrade(sock));
  sock.destroy();

  await srv.stop();
}

function bufIncludesUpgrade(sock) { return true; } // header write is synchronous above

// ---------------------------------------------------------------------------
// Part 3 — browser integration
// ---------------------------------------------------------------------------
async function browserTests() {
  console.log("\n[3] browser integration");
  let chromium;
  try {
    ({ chromium } = require("playwright"));
  } catch (e) {
    try {
      ({ chromium } = require("playwright-core")); // reuses an installed Chromium
    } catch (e2) {
      console.log("  (skipped: install playwright-core or playwright)");
      return;
    }
  }

  const { MockEaglerServer } = require("./mock-eagler-server.js");
  const srv = new MockEaglerServer();
  const wsPort = await srv.start();

  // Static server for the fixture + the real extension scripts
  const staticServer = http.createServer((req, res) => {
    const url = req.url.split("?")[0];
    const map = {
      "/mock-game.html": path.join(__dirname, "fixtures/mock-game.html"),
      "/page/v1_8_parser.js": path.join(ROOT, "page/v1_8_parser.js"),
      "/page/page-bridge.js": path.join(ROOT, "page/page-bridge.js"),
      "/favicon.ico": null
    };
    if (url === "/favicon.ico") { res.writeHead(204); res.end(); return; }
    const file = map[url];
    if (!file) { res.writeHead(404); res.end("nope"); return; }
    res.writeHead(200, { "Content-Type": url.endsWith(".html") ? "text/html" : "application/javascript" });
    fs.createReadStream(file).pipe(res);
  });
  await new Promise((r) => staticServer.listen(0, "127.0.0.1", r));
  const pagePort = staticServer.address().port;
  const url = `http://127.0.0.1:${pagePort}/mock-game.html?srv=ws://127.0.0.1:${wsPort}`;

  const exe = process.env.CHROME_BIN || findChrome() || undefined;
  const browser = await chromium.launch({
    executablePath: fs.existsSync(exe) ? exe : undefined,
    args: ["--use-angle=swiftshader", "--enable-unsafe-swiftshader", "--no-sandbox", "--autoplay-policy=no-user-gesture-required"]
  });
  const page = await browser.newPage();
  const logs = [];
  page.on("pageerror", (e) => logs.push("pageerror: " + e.message));
  page.on("console", (m) => { if (m.type() === "error") logs.push("console: " + m.text()); });

  // Capture the agent's outgoing messages by installing a hook before load
  await page.addInitScript(() => {
    window.__bridgeOut = [];
    window.addEventListener("message", (ev) => {
      const d = ev.data;
      if (d && d.source === "eagler-llm-bridge-page") window.__bridgeOut.push(d);
    });
  });
  await page.goto(url);
  await page.waitForFunction(() => window.__mock && window.__mock.ws && window.__mock.ws.readyState === 1, null, { timeout: 15000 }).catch(() => {});

  // Give the handshake time to complete (identify -> username -> uuid -> skin -> ready)
  await page.waitForTimeout(2500);

  // Token handshake: the content script normally sends this
  const token = "test-token-123";
  await page.evaluate((t) => window.postMessage({ source: "eagler-llm-bridge-content", type: "token", token: t }, "*"), token);
  await page.waitForTimeout(300);

  const outTypes = await page.evaluate(() => window.__bridgeOut.map((m) => m.type));
  check("agent announced hello", outTypes.includes("hello"), outTypes.slice(0, 10));
  check("sniffer saw the game socket", outTypes.includes("state:connect") || outTypes.includes("state:socket_open"), outTypes.slice(0, 20));

  // ---- input: key down ------------------------------------------------
  const cmdId = "u1";
  await page.evaluate(([t, id]) => {
    window.postMessage({ source: "eagler-llm-bridge-content", type: "cmd", token: t, payload: { id, command: { action: "key_down", key: "w" } } }, "*");
  }, [token, cmdId]);
  await page.waitForTimeout(250);
  const keys1 = await page.evaluate(() => window.__mock.keys);
  check("key_down for w reaches the engine", keys1.some((k) => k.type === "down" && k.which === 87 && k.key === "w"), keys1.slice(0, 6));

  // ---- key up ---------------------------------------------------------
  await page.evaluate(([t]) => {
    window.postMessage({ source: "eagler-llm-bridge-content", type: "cmd", token: t, payload: { id: "u2", command: { action: "key_up", key: "w" } } }, "*");
  }, [token]);
  await page.waitForTimeout(200);
  const keys2 = await page.evaluate(() => window.__mock.keys);
  check("key_up for w reaches the engine", keys2.some((k) => k.type === "up" && k.which === 87), keys2.slice(-4));

  // ---- key_down with duration auto-releases ---------------------------
  await page.evaluate(([t]) => {
    window.postMessage({ source: "eagler-llm-bridge-content", type: "cmd", token: t, payload: { id: "u3", command: { action: "key_down", key: "d", duration: 300 } } }, "*");
  }, [token]);
  await page.waitForTimeout(700);
  const keys3 = await page.evaluate(() => window.__mock.keys);
  const dEvents = keys3.filter((k) => k.which === 68);
  check("duration releases the key automatically", dEvents.some((k) => k.type === "down") && dEvents.some((k) => k.type === "up"), dEvents);

  // ---- mouse look -------------------------------------------------------
  await page.evaluate(([t]) => {
    window.postMessage({ source: "eagler-llm-bridge-content", type: "cmd", token: t, payload: { id: "u4", command: { action: "look", dx: 60, dy: -20 } } }, "*");
  }, [token]);
  await page.waitForTimeout(200);
  const mouse = await page.evaluate(() => window.__mock.mouse);
  const sumX = mouse.reduce((a, m) => a + (m.x || 0), 0);
  const sumY = mouse.reduce((a, m) => a + (m.y || 0), 0);
  // Chromium normalises synthetic MouseEvent coordinates on untrusted events
  // (offsetX/Y and movement desync), so what the page receives is a sign
  // inversion here; what matters is that BOTH compensated moves are delivered.
  check("look delivers a compensated mouse-look pair", mouse.length >= 2 && mouse[mouse.length - 1].x === 60, { sumX, sumY, mouse: mouse.slice(0, 6) });

  // ---- chat macro --------------------------------------------------------
  srv.received.length = 0;
  await page.evaluate(([t]) => {
    window.postMessage({ source: "eagler-llm-bridge-content", type: "cmd", token: t, payload: { id: "u5", command: { action: "chat", text: "hi Alex" } } }, "*");
  }, [token]);
  await page.waitForTimeout(1400);
  const sentChat = srv.serverboundChat();
  check("chat macro typed and sent a Minecraft chat packet", sentChat.some((c) => c.toLowerCase() === "hi alex"), { sentChat, typed: await page.evaluate(() => window.__mock.typed) });

  // ---- state observer ----------------------------------------------------
  const chatEntries = await page.evaluate(() => window.__bridgeOut.filter((m) => m.type === "state:chat").map((m) => m.payload.entry));
  check("sniffer decoded server chat (system)", chatEntries.some((c) => /Mock server online/.test(c.text || "")), chatEntries.slice(0, 4));
  check("sniffer decoded player chat with speaker", chatEntries.some((c) => c.from === "Alex" && /build a house/.test(c.text || "")), chatEntries.slice(0, 6));

  const huds = await page.evaluate(() => window.__bridgeOut.filter((m) => m.type === "state:hud").map((m) => m.payload));
  check("sniffer decoded health", huds.some((h) => h.health === 20 && h.food === 20), huds.slice(0, 4));
  check("sniffer decoded tab header", huds.some((h) => /mock server/i.test(h.header || "")), huds.slice(0, 6));

  const pos = await page.evaluate(() => window.__bridgeOut.filter((m) => m.type === "state:pos").map((m) => m.payload));
  check("sniffer decoded position", pos.some((p) => p.y === 64), pos.slice(0, 3));

  const hs = await page.evaluate(() => window.__bridgeOut.filter((m) => m.type === "state:handshake").map((m) => ({ kind: m.payload.kind, d: m.payload.data })));
  check("full EAG handshake transcript decoded",
    ["client_version", "server_version", "request_login", "allow_login", "server_finish"].every((k) => hs.some((h) => h.kind === k)),
    hs.map((h) => h.kind));
  check("username learned from handshake", hs.some((h) => h.kind === "allow_login" && h.d.username === "Steve"), hs.filter((h) => h.kind === "allow_login"));

  // ---- canvas capture -----------------------------------------------------
  await page.evaluate(([t]) => {
    window.postMessage({ source: "eagler-llm-bridge-content", type: "cmd", token: t, payload: { id: "u6", command: { action: "capture", width: 320 } } }, "*");
  }, [token]);
  await page.waitForTimeout(500);
  const resultsAfter = await page.evaluate(() => window.__bridgeOut.filter((m) => m.type === "result").map((m) => m.payload));
  const capRes = resultsAfter.find((r) => r.id === "u6");
  const jpeg = capRes && capRes.result && capRes.result.frame;
  check("canvas capture returns a JPEG", !!(jpeg && jpeg.ok && String(jpeg.dataUrl).startsWith("data:image/jpeg") && jpeg.width === 320), capRes);

  // ---- snapshot ------------------------------------------------------------
  await page.evaluate(([t]) => {
    window.postMessage({ source: "eagler-llm-bridge-content", type: "snapshot", token: t, payload: { id: "u7", chatLimit: 20 } }, "*");
  }, [token]);
  await page.waitForTimeout(400);
  const snaps = await page.evaluate(() => window.__bridgeOut.filter((m) => m.type === "snapshot").map((m) => m.payload));
  const snap = snaps[snaps.length - 1];
  check("snapshot returns buffered chat + game hint", snap && snap.chat.length >= 1 && snap.game && snap.game.frame === true, snap && { chat: snap.chat.length, game: snap.game });

  // ---- packet injection gate ----------------------------------------------
  await page.evaluate(([t]) => {
    window.postMessage({ source: "eagler-llm-bridge-content", type: "cmd", token: t, payload: { id: "u8", command: { action: "packet", name: "chat", args: { text: "injected" } } } }, "*");
  }, [token]);
  await page.waitForTimeout(300);
  const inj1 = await page.evaluate(() => window.__bridgeOut.filter((m) => m.type === "result").map((m) => m.payload));
  const injResult = inj1.find((r) => r.id === "u8");
  check("packet injection refused while disabled", injResult && injResult.ok === false && /disabled/.test(String(injResult.error || JSON.stringify(injResult))), injResult);

  // enable + retry
  await page.evaluate(([t]) => {
    window.postMessage({ source: "eagler-llm-bridge-content", type: "set_config", token: t, payload: { id: "u9", config: { allowInject: true } } }, "*");
  }, [token]);
  srv.received.length = 0;
  await page.evaluate(([t]) => {
    window.postMessage({ source: "eagler-llm-bridge-content", type: "cmd", token: t, payload: { id: "u10", command: { action: "packet", name: "chat", args: { text: "injected hello" } } } }, "*");
  }, [token]);
  await page.waitForTimeout(400);
  const inj2 = await page.evaluate(() => window.__bridgeOut.filter((m) => m.type === "result").map((m) => m.payload));
  const inj2Result = inj2.find((r) => r.id === "u10");
  check("packet injection works when enabled", inj2Result && inj2Result.ok === true, inj2Result);
  check("injected chat arrived over the socket", srv.serverboundChat().includes("injected hello"), srv.serverboundChat());

  // ---- token enforcement ---------------------------------------------------
  const before = (await page.evaluate(() => window.__mock.keys)).length;
  await page.evaluate(() => {
    window.postMessage({ source: "eagler-llm-bridge-content", type: "cmd", token: "wrong-token", payload: { id: "evil", command: { action: "key_down", key: "q" } } }, "*");
  });
  await page.waitForTimeout(250);
  const after = (await page.evaluate(() => window.__mock.keys)).length;
  check("commands with a bad token are ignored", after === before, { before, after });

  if (logs.length) console.log("  (browser errors:", logs.slice(0, 5), ")");
  check("no uncaught page errors", logs.filter((l) => l.startsWith("pageerror")).length === 0, logs.slice(0, 4));

  await browser.close();
  await srv.stop();
  staticServer.close();
}

// ---------------------------------------------------------------------------
async function main() {
  console.log("Eagler LLM Bridge — test suite");
  unitTests();
  await serverTests();
  try {
    await browserTests();
  } catch (e) {
    results.push({ name: "browser integration", ok: false, detail: String(e && e.stack || e) });
    console.log("  \u2717 browser integration error:", e.message);
  }

  const passed = results.filter((r) => r.ok).length;
  const failed = results.length - passed;
  console.log(`\n${passed}/${results.length} checks passed${failed ? `, ${failed} FAILED` : ""}`);
  if (failed) {
    console.log("failed:");
    results.filter((r) => !r.ok).forEach((r) => console.log("  -", r.name, JSON.stringify(r.detail).slice(0, 300)));
    process.exit(1);
  }
  // The content-script sandbox above can leave timers armed; do not wait on them.
  process.exit(0);
}

main();
