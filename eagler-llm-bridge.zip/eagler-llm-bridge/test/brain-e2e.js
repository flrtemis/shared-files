/*
 * The whole thing, end to end, with no real site involved:
 *
 *   Perchance-style AI chat  <->  extension  <->  bridge host  <->  agent loop
 *                                        \->  Minecraft (mock) world
 *
 * What this proves: a chat line produced by the "AI" turns into real input in
 * the game frame (the key arrives at the Minecraft socket layer), and the
 * per-cycle observation text comes back from the game.
 *
 *   xvfb-run -a -s "-screen 0 1280x900x24" node test/brain-e2e.js
 */
"use strict";
const fs = require("fs");
const http = require("http");
const path = require("path");
const { spawn } = require("child_process");
const { chromium } = require(path.join(__dirname, "..", "node_modules", "playwright-core"));

const ROOT = path.join(__dirname, "..");
const results = [];
const check = (n, ok, d) => {
  results.push({ n, ok: !!ok });
  console.log((ok ? "  ✓ " : "  ✗ ") + n + (ok ? "" : "  -> " + JSON.stringify(d).slice(0, 300)));
};

function get(u, method = "GET", body, timeout = 30000) {
  return new Promise((resolve) => {
    const data = body ? JSON.stringify(body) : null;
    const req = http.request(u, { method, timeout,
      headers: data ? { "content-type": "application/json", "content-length": Buffer.byteLength(data) } : {} },
      (res) => { let b = ""; res.on("data", (c) => (b += c)); res.on("end", () => { try { resolve(JSON.parse(b)); } catch (e) { resolve({ raw: b.slice(0, 200) }); } }); });
    req.on("error", (e) => resolve({ error: e.message }));
    req.on("timeout", () => { req.destroy(); resolve({ error: "timeout" }); });
    if (data) req.write(data);
    req.end();
  });
}

// A chat generator whose single reply is a command plan.
const BRAIN_HTML = (replyText) => `<!DOCTYPE html><html><head><meta charset="utf-8"><title>Brain</title></head>
<body>
<div id="messageFeed"></div>
<div id="bottom"><textarea id="messageInput"></textarea><button id="sendButton">send</button></div>
<script>
(() => {
  const feed = document.getElementById("messageFeed"), input = document.getElementById("messageInput");
  const REPLY = ${JSON.stringify(replyText)};
  window.__mockPerchance = { mode: "instant", sendCount: 0, lastSent: null, rows: 0, replyIndex: 0 };
  function addRow(name, text) {
    const r = document.createElement("div"); r.className = "message";
    r.setAttribute("data-id", String(++window.__mockPerchance.rows));
    r.innerHTML = '<div class="messageWrap"><div class="info"><div class="characterName"></div></div><div class="messageText"></div></div>';
    r.querySelector(".characterName").textContent = name;
    r.querySelector(".messageText").textContent = text || "";
    feed.appendChild(r); return r;
  }
  addRow("AI Assistant", "Ready. Tell me what to do next.");
  document.getElementById("sendButton").addEventListener("click", () => {
    const t = (input.value || "").trim(); if (!t) return;
    window.__mockPerchance.sendCount++; window.__mockPerchance.lastSent = t;
    addRow("Anon", t); input.value = "";
    setTimeout(() => addRow("AI Assistant", REPLY), 200);
  });
})();
</script>
</body></html>`;

(async () => {
  // ---- mock Minecraft server (real EAG handshake) --------------------------
  const { MockEaglerServer } = require("./mock-eagler-server.js");
  const mc = new MockEaglerServer();
  const mcPort = await mc.start();

  // ---- static server -------------------------------------------------------
  const brainReply = "walk: forward 1500\nsay: heading toward the trees";   // multi-line plan
  const server = http.createServer((req, res) => {
    const u = req.url.split("?")[0];
    if (u === "/brain.html") { res.writeHead(200, { "content-type": "text/html" }); res.end(BRAIN_HTML(brainReply)); return; }
    const map = {
      "/mock-game.html": path.join(__dirname, "fixtures/mock-game.html"),
      "/page/v1_8_parser.js": path.join(ROOT, "page/v1_8_parser.js"),
      "/page/page-bridge.js": path.join(ROOT, "page/page-bridge.js"),
      "/perchance-bridge.js": path.join(ROOT, "page/perchance-bridge.js")
    };
    if (u === "/favicon.ico") { res.writeHead(204); res.end(); return; }
    const f = map[u];
    if (!f) { res.writeHead(404); res.end(); return; }
    res.writeHead(200, { "content-type": u.endsWith(".html") ? "text/html" : "application/javascript" });
    fs.createReadStream(f).pipe(res);
  });
  await new Promise((r) => server.listen(0, "127.0.0.1", r));
  const port = server.address().port;

  const bridge = spawn(process.execPath, [path.join(ROOT, "llm/ws-bridge.js")], { cwd: ROOT, stdio: "ignore" });
  await new Promise((r) => setTimeout(r, 900));

  const exe = process.env.CHROME_BIN || "/home/user/.cache/ms-playwright/chromium-1194/chrome-linux/chrome";
  const ctx = await chromium.launchPersistentContext("/tmp/brain-" + Date.now(), {
    executablePath: exe, headless: false,
    args: ["--no-sandbox", "--use-angle=swiftshader", "--enable-unsafe-swiftshader",
      `--disable-extensions-except=${ROOT}`, `--load-extension=${ROOT}`,
      `--host-resolver-rules=MAP brain.perchance.org 127.0.0.1:${port}, MAP game.gnhustgames.org 127.0.0.1:${port}`]
  });

  // Tab 1: the "AI" (served on a perchance.org hostname so the real content
  // script matches it).
  // service-worker console (attach diagnostics)
  ctx.on("serviceworker", (w) => w.on("console", (m) => { const t = m.text(); if (/ensureMinecraftTab|BOOT-BUILD|error/i.test(t)) console.log("SW:", t.slice(0, 300)); }));
  // Tab 1: the game (mock Eaglercraft client + the real extension agent). Opened
  // first so its frame agent is the one that teaches the worker which tab is the
  // game — the same path used when the game is embedded somewhere unusual.
  const game = await ctx.newPage();
  await game.goto(`http://game.gnhustgames.org/mock-game.html?srv=ws://127.0.0.1:${mcPort}`);
  await game.waitForFunction(() => window.__mock && window.__mock.ws && window.__mock.ws.readyState === 1, null, { timeout: 20000 }).catch(() => {});
  await game.waitForTimeout(3500);

  // Tab 2: the "AI" (served on a perchance.org hostname so the real content
  // script matches it).
  const brain = await ctx.newPage();
  await brain.goto(`http://brain.perchance.org/brain.html`);
  await brain.waitForTimeout(1200);

  const health = await get("http://127.0.0.1:8787/health");
  check("extension connected to the host", health && health.extension === true, health);

  // The game tab must be the attached one; the agent picks nite.games normally,
  // so ask explicitly for this tab.
  const attach = await get("http://127.0.0.1:8787/command", "POST", { action: "attach" });
  console.log("attach:", JSON.stringify(attach).slice(0, 200));
  await game.bringToFront();
  await game.waitForTimeout(2500);

  const st = await get("http://127.0.0.1:8787/state?chatLimit=5");
  const state = (st && st.state) || {};
  check("game state is flowing (mock world joined)", state.connected === true, { connected: state.connected });

  const llmStatus = await get("http://127.0.0.1:8787/llm/status");
  check("AI chat attached", llmStatus && llmStatus.ok === true, llmStatus);

  // ---- the actual loop: observe -> ask -> parse -> act ---------------------
  const agent = spawn(process.execPath, [path.join(ROOT, "llm/perchance-agent.js"), "--once", "--timeout", "25000"],
    { cwd: ROOT, env: { ...process.env, BRIDGE_PORT: "8787" } });
  let out = "";
  agent.stdout.on("data", (d) => (out += d));
  agent.stderr.on("data", (d) => (out += d));
  const code = await new Promise((r) => agent.on("exit", r));

  console.log("\n--- agent output ---\n" + out.trim().slice(0, 1600) + "\n--------------------\n");
  check("agent loop ran a full cycle", code === 0, code);
  check("agent asked the AI and printed its reply", /AI \(\d+ ms\):/.test(out), out.slice(0, 200));
  check("reply parsed into a plan", /"action":"key_down"/.test(out), out.slice(-300));
  check("plan was applied to the game", /applied: [1-9]\d*\/[1-9]/.test(out), out.slice(-200));

  // The mock game recorded the chat macro: T opened the box, the text was typed
  // through the same handler, Enter sent it over the socket.
  await game.waitForTimeout(600);
  const macro = await game.evaluate(() => ({
    typed: window.__mock.typed,
    open: window.__mock.chatboxOpen,
    keys: window.__mock.keys.filter((k) => k.type === "down").map((k) => k.which).slice(-12)
  }));
  const socketChat = mc.received
    .map((b) => Buffer.from(b))
    .filter((b) => b[0] === 0x01 && b.length > 4)
    .map((b) => b.subarray(2).toString("utf8"));
  check("the AI's line went through the chat macro into the game",
    /heading toward the trees/.test(macro.typed) || socketChat.some((t) => /heading toward the trees/.test(t)),
    { macro, socketChat });

  await ctx.close();
  bridge.kill();
  server.close();

  const passed = results.filter((r) => r.ok).length;
  console.log(`\n${passed}/${results.length} brain e2e checks passed`);
  process.exit(passed === results.length ? 0 : 1);
})();
