#!/usr/bin/env node
/*
 * Mock Eaglercraft server used by the automated tests.
 *
 * Speaks the real EAG handshake (network version 3) and Minecraft 1.8
 * packets on a genuine WebSocket, so the bridge's sniffer, decoder and the
 * packet-injection path are exercised end to end without needing a public
 * server. Also records every serverbound packet for assertions.
 *
 *   node test/mock-eagler-server.js          # listens on 127.0.0.1:8799
 */
"use strict";
const http = require("http");
const { attach } = require("./lib/mini-ws.js");
const { packets } = require("./lib/proto.js");

const PORT = parseInt(process.env.MOCK_PORT || "8799", 10);

class MockEaglerServer {
  constructor(port) {
    // Optional explicit port: callers that run several mocks (or reuse a
    // fixture URL) must not race the environment variable at module load.
    this.port = port || PORT;
    this.received = [];     // raw serverbound frames
    this.sent = [];         // raw clientbound frames
    this.sockets = new Set();
    this.chatSeq = 0;
    this.timers = [];
  }

  start() {
    this.server = http.createServer((req, res) => { res.writeHead(200); res.end("mock eagler server"); });
    this.wsBus = attach(this.server);
    this.wsBus.on("connection", (conn) => this._onConn(conn));
    return new Promise((resolve) => this.server.listen(this.port, "127.0.0.1", () => resolve(this.port)));
  }

  stop() {
    this.timers.forEach(clearInterval);
    for (const s of this.sockets) s.close();
    return new Promise((resolve) => this.server.close(resolve));
  }

  _send(sock, buf) { this.sent.push(buf); sock.send(buf); }

  _onConn(sock) {
    this.sockets.add(sock);
    let loggedIn = false;
    let playing = false;

    // Handshake state machine matching lax1dude/eaglerxserver:
    //   C->S client_version(0x01)  S->C server_version(0x02)
    //   C->S request_login(0x04)   S->C allow_login(0x05)
    //   C->S profile_data(0x07)
    //   C->S finish_login(0x08)    S->C server_finish(0x09) -> play
    sock.onmessage = (buf) => {
      this.received.push(buf);
      const id = buf[0];

      if (!playing) {
        if (id === 0x01) {
          // Verify the client sent the real layout: 0x01 0x02 <count> ...
          this.loginOk = buf[1] === 0x02;
          if (!this.loginOk) { this._send(sock, packets.eagError(0x02, "Invalid Login Packet")); sock.close(); return; }
          loggedIn = true;
          this._send(sock, packets.eagServerVersion(3, 47));
          return;
        }
        if (id === 0x04) { this._send(sock, packets.eagAllowLogin(this.username || "Steve")); return; }
        if (id === 0x07) { this.skinSeen = true; return; }
        if (id === 0x08 && loggedIn) {
          this._send(sock, packets.eagServerFinish());
          playing = true;
          this._enterPlay(sock);
          return;
        }
        return;
      }
      // Play: keepalive + chat are the only ids the mock reacts to.
      if (id === 0x00) {
        const { W } = require("./lib/proto.js");
        this._send(sock, new W().varint(0x00).varint(1).done());
      }
    };

    sock.onclose = () => this.sockets.delete(sock);
  }

  _enterPlay(sock) {
    this.playStarted = Date.now();
    this._send(sock, packets.joinGame());
    this._send(sock, packets.position(0.5, 64, 0.5, 90, 10));
    this._send(sock, packets.health(20, 20, 5));
    this._send(sock, packets.xp(0.35, 7, 300));
    this._send(sock, packets.listHeaderFooter("Welcome to the mock server", "tps: 20"));
    this._send(sock, packets.objective("kills", "Kills"));

    // Chat stream: one system line, then a player line, then a reply opportunity
    this.timers.push(setTimeout(() => {
      this._send(sock, packets.chat({ text: "Mock server online.", color: "yellow" }, 1));
    }, 300));

    this.timers.push(setTimeout(() => {
      this._send(sock, packets.chat({
        translate: "chat.type.text",
        with: [{ text: "Alex" }, { text: "anyone want to build a house?" }]
      }, 0));
    }, 900));

    this.timers.push(setTimeout(() => {
      this._send(sock, packets.title("Mock World"));
      this._send(sock, packets.score("Alex", 3, "kills"));
    }, 1400));
  }

  /** Push a chat line on demand (used by tests to check streaming). */
  say(text, from) {
    const comp = from
      ? { translate: "chat.type.text", with: [{ text: from }, { text }] }
      : { text };
    for (const s of this.sockets) this._send(s, packets.chat(comp, from ? 0 : 1));
  }

  serverboundChat() {
    return this.received
      .filter((b) => b[0] === 0x01)
      .map((b) => packets.parseServerbound(b))
      .filter((p) => p.name === "chat")
      .map((p) => p.text);
  }
}

module.exports = { MockEaglerServer };

if (require.main === module) {
  const s = new MockEaglerServer();
  s.start().then((port) => {
    console.log("mock Eaglercraft server on ws://127.0.0.1:" + port);
    setInterval(() => s.say("tick " + new Date().toISOString().slice(17, 19), null), 5000);
  });
}
