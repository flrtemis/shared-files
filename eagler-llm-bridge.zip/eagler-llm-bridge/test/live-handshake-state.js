/*
 * Live proof that the REAL nite.games client's handshake is decoded by the
 * extension's parser, in the live page, through the shipped code path.
 *
 *   xvfb-run -a -s "-screen 0 1280x800x24" node test/live-handshake-state.js
 *
 * Reads GET /state from the bridge host and reports the protocol identity the
 * sniffer learned (server brand/version, EAG protocol, username, play phase).
 */
"use strict";

function findChrome() {
  const cache = path.join(process.env.HOME || "/root", ".cache", "ms-playwright");
  const candidates = [];
  try {
    for (const dir of fs.readdirSync(cache).sort().reverse()) {
      for (const rel of ["chrome-linux64/chrome", "chrome-linux/chrome"]) {
        candidates.push(path.join(cache, dir, rel));
      }
    }
  } catch (e) { /* no playwright cache */ }
  candidates.push("/usr/bin/chromium", "/usr/bin/google-chrome", "/usr/bin/chromium-browser");
  return candidates.find((c) => { try { return fs.statSync(c).isFile(); } catch (e) { return false; } }) || null;
}

const path = require("path");
const fs = require("fs");
const http = require("http");
const { spawn } = require("child_process");
const { chromium } = require(path.join(__dirname, "..", "node_modules", "playwright-core"));

const EXT = path.join(__dirname, "..");
const HOST = "http://127.0.0.1:8787";
const EXE = process.env.CHROME_BIN || findChrome() || undefined;

function getJson(url) {
  return new Promise((resolve) => {
    const req = http.get(url, { timeout: 4000 }, (res) => {
      let body = "";
      res.on("data", (c) => (body += c));
      res.on("end", () => {
        try { resolve(JSON.parse(body)); } catch (e) { resolve(null); }
      });
    });
    req.on("error", () => resolve(null));
    req.on("timeout", () => { req.destroy(); resolve(null); });
  });
}

(async () => {
  let ok = false;
  // The extension talks to the bridge host; start it like the e2e test does.
  const bridge = spawn(process.execPath, [path.join(EXT, "llm/ws-bridge.js")], {
    cwd: EXT, stdio: ["ignore", "pipe", "pipe"], env: { ...process.env, BRIDGE_PORT: "8787" }
  });
  bridge.stderr.on("data", () => {});
  await new Promise((r) => setTimeout(r, 900));
  const browser = await chromium.launchPersistentContext(
    "/tmp/live-hs-profile-" + Date.now(),
    {
      executablePath: fs.existsSync(EXE) ? EXE : undefined,
      headless: false,
      args: [
        "--no-sandbox", "--use-angle=swiftshader", "--enable-unsafe-swiftshader",
        "--disable-extensions-except=" + EXT, "--load-extension=" + EXT,
        "--autoplay-policy=no-user-gesture-required", "--window-size=1280,800"
      ]
    }
  );
  try {
    const page = await browser.newPage();
    await page.goto("https://nite.games/game/minecraft", { waitUntil: "domcontentloaded", timeout: 90000 });

    const deadline = Date.now() + 90000;
    let state = null;
    while (Date.now() < deadline) {
      await page.waitForTimeout(3000);
      const res = await getJson(HOST + "/state?chatLimit=5");
      state = res && res.state ? res.state : (res && res.lastState) || null;
      if (state && state.serverBrand) break;
    }

    if (!state) { console.log("FAIL: bridge host never answered /state"); process.exit(1); }
    const snap = state && state.state ? state.state : state;
    state = snap && Object.keys(snap).length ? snap : state;
    console.log(JSON.stringify({
      connected: state.connected,
      handshakeDone: state.handshakeDone,
      protocol: state.protocol,
      serverBrand: state.serverBrand,
      serverVersion: state.serverVersion,
      username: state.username,
      server: state.server
    }, null, 1));

    ok = !!(state.serverBrand && state.protocol > 0 && state.handshakeDone);
    console.log(ok
      ? "\nRESULT: live nite.games handshake decoded by the extension"
      : "\nRESULT: handshake identity not learned (see fields above)");
  } finally {
    await browser.close();
    try { bridge.kill(); } catch (e) {}
  }
  process.exit(ok ? 0 : 1);
})();
