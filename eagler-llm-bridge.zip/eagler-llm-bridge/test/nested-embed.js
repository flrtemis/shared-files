// Nested-embed regression: nite.games-style page -> wrapper iframe -> game.
// Proves attach + live state work when the game is two levels down.
const path = "/home/user/eagler-llm-bridge";
const { chromium } = require(path + "/node_modules/playwright-core");
const http = require("http"), fs = require("fs");
const { MockEaglerServer } = require(path + "/test/mock-eagler-server.js");

(async () => {
  const mc = new MockEaglerServer(8858);
  await mc.start();

  const server = http.createServer((q, r) => {
    const u = q.url.split("?")[0];
    if (u === "/outer") {
      r.writeHead(200, { "content-type": "text/html" });
      return r.end(`<!doctype html><title>embed page</title>
        <h1>games hub</h1><iframe src="/inner" style="width:920px;height:620px"></iframe>`);
    }
    if (u === "/inner") {
      r.writeHead(200, { "content-type": "text/html" });
      return r.end(`<!doctype html><title>wrapper</title>
        <iframe src="http://game.gnhustgames.org/mock-game.html?srv=ws://127.0.0.1:8858"
                style="width:900px;height:600px"></iframe>`);
    }
    const map = {
      "/mock-game.html": path + "/test/fixtures/mock-game.html",
      "/page/v1_8_parser.js": path + "/page/v1_8_parser.js",
      "/page/page-bridge.js": path + "/page/page-bridge.js"
    };
    if (u === "/favicon.ico") { r.writeHead(204); return r.end(); }
    const f = map[u]; if (!f) { r.writeHead(404); return r.end(); }
    r.writeHead(200, { "content-type": u.endsWith(".html") ? "text/html" : "application/javascript" });
    fs.createReadStream(f).pipe(r);
  });
  await new Promise((r) => server.listen(8859, "127.0.0.1", r));

  const ctx = await chromium.launchPersistentContext("/tmp/h19-" + Date.now(), {
    executablePath: "/home/user/.cache/ms-playwright/chromium-1194/chrome-linux/chrome",
    headless: false,
    args: ["--no-sandbox", "--use-angle=swiftshader", "--enable-unsafe-swiftshader",
      `--disable-extensions-except=${path}`, `--load-extension=${path}`,
      "--host-resolver-rules=MAP hub.nite.games 127.0.0.1:8859, MAP game.gnhustgames.org 127.0.0.1:8859"]
  });

  const page = await ctx.newPage();
  await page.goto("http://hub.nite.games/outer");
  await page.waitForTimeout(6000);
  const sw = ctx.serviceWorkers()[0];

  const out = await sw.evaluate(async () => {
    let attach = null;
    try { attach = await self.__eaglerBridge.runCommand({ action: "attach" }); }
    catch (e) { attach = { error: String(e) }; }
    await new Promise((r) => setTimeout(r, 3000));
    let state = null;
    try { state = await self.__eaglerBridge.runCommand({ action: "get_state" }); }
    catch (e) { state = { error: String(e) }; }
    const log = (self.__msgLog || []).filter((m) => /state:|page-frame|frame/.test(m.type || ""));
    const last = (self.__msgLog || []).slice(-12);
    return { attach, agents: self.__eaglerBridge.store.listAgents().map((a) => a.url), state, log: log.slice(-8), last };
  });

  const checks = [];
  const ck = (name, ok, extra) => { checks.push({ name, ok }); console.log(`  ${ok ? "✓" : "✗"} ${name}${ok ? "" : "  -> " + JSON.stringify(extra).slice(0, 220)}`); };

  ck("attach found the tab by itself (no tabId given)", out.attach && out.attach.ok, out.attach);
  ck("the game frame registered an agent", out.agents.some((u) => /gnhustgames/.test(u)), out.agents);
  console.log("  recent worker messages:", JSON.stringify(out.log));
  ck("game state flows from the nested frame", !!(out.state && out.state.state && out.state.state.connected), out.state && out.state.state);

  console.log(`\n${checks.filter((c) => c.ok).length}/${checks.length} nested-embed checks passed`);
  await ctx.close(); server.close(); await mc.stop(); process.exit(0);
})();
