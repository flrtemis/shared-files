/*
 * Perchance adapter tests (offline).
 *
 * The adapter is the "LLM side" of the bridge: it reads the AI character chat's
 * DOM, streams replies out as events, and injects user messages. This suite runs
 * it in a real browser against a mock that reproduces the live DOM contract.
 *
 *   node test/perchance-tests.js
 */
"use strict";
const fs = require("fs");
const http = require("http");
const path = require("path");

const ROOT = path.join(__dirname, "..");
const results = [];
function check(name, ok, detail) {
  results.push({ name, ok: !!ok, detail });
  console.log((ok ? "  \u2713 " : "  \u2717 ") + name + (ok ? "" : "  -> " + JSON.stringify(detail).slice(0, 260)));
}

async function main() {
  let chromium;
  try {
    ({ chromium } = require("playwright-core"));
  } catch (e) {
    console.log("  (skipped: playwright-core not installed)");
    return;
  }

  // Serve the fixture + the adapter, as the extension would deliver it.
  const server = http.createServer((req, res) => {
    const url = req.url.split("?")[0];
    const map = {
      "/mock-perchance.html": path.join(__dirname, "fixtures/mock-perchance.html"),
      "/perchance-bridge.js": path.join(ROOT, "page/perchance-bridge.js")
    };
    if (url === "/favicon.ico") { res.writeHead(204); res.end(); return; }
    const file = map[url];
    if (!file) { res.writeHead(404); res.end("nope"); return; }
    res.writeHead(200, { "Content-Type": url.endsWith(".html") ? "text/html" : "application/javascript" });
    fs.createReadStream(file).pipe(res);
  });
  await new Promise((r) => server.listen(0, "127.0.0.1", r));
  const port = server.address().port;

  const exe = process.env.CHROME_BIN || "/home/user/.cache/ms-playwright/chromium-1194/chrome-linux/chrome";
  const browser = await chromium.launch({
    executablePath: fs.existsSync(exe) ? exe : undefined,
    args: ["--no-sandbox", "--disable-dev-shm-usage"]
  });
  const page = await browser.newPage();
  const errors = [];
  page.on("pageerror", (e) => errors.push(e.message));

  // Fake the extension messaging surface the adapter talks to.
  await page.addInitScript(() => {
    window.__sent = [];
    window.__pageListeners = [];
    window.chrome = {
      runtime: {
        id: "test-extension",
        sendMessage(msg) { window.__sent.push(msg); return Promise.resolve({ ok: true }); },
        onMessage: { addListener(fn) { window.__pageListeners.push(fn); } }
      }
    };
    // Deliver a command to the adapter and resolve with its answer.
    window.__cmd = (type, payload) => new Promise((resolve) => {
      const fn = window.__pageListeners[0];
      if (!fn) return resolve({ ok: false, error: "adapter never registered" });
      let answered = false;
      const respond = (r) => { if (!answered) { answered = true; resolve(r); } };
      const keepOpen = fn({ kind: "eagler-perchance-to-page", type, payload }, {}, respond);
      if (keepOpen !== true && !answered) respond({ ok: false, error: "no reply" });
    });
  });

  await page.goto(`http://127.0.0.1:${port}/mock-perchance.html`);
  await page.addScriptTag({ url: "/perchance-bridge.js" });
  await page.waitForTimeout(600);

  const events = () => page.evaluate(() => window.__sent.filter((m) => m.kind === "eagler-perchance"));
  const ofType = async (t) => (await events()).filter((m) => m.type === t);

  // ---- boot ---------------------------------------------------------------
  const status = await page.evaluate(() => window.__cmd("status"));
  check("adapter answers status", status && status.ready === true, status);
  check("adapter found the feed, input and send control",
    status && status.feed && status.input && status.send, status);
  check("assistant name learned from the greeting row", status && status.assistantName === "AI Assistant", status);

  const boots = await ofType("llm-status");
  check("boot announced llm-status", boots.length > 0, boots.length);

  // ---- reading the transcript --------------------------------------------
  let msgs = await ofType("llm-message");
  check("greeting message reported as assistant",
    msgs.some((m) => m.payload.role === "assistant" && /evidence-based answers/.test(m.payload.text)),
    msgs.map((m) => m.payload.role));

  // ---- streaming ---------------------------------------------------------
  await page.evaluate(() => window.__cmd("send", { text: "say pong" }));
  await page.waitForTimeout(300);
  const afterSend = await page.evaluate(() => ({
    count: window.__mockPerchance.sendCount,
    last: window.__mockPerchance.lastSent
  }));
  check("send() reached the page's send button", afterSend.count === 1 && afterSend.last === "say pong", afterSend);

  await page.waitForTimeout(600);
  msgs = await ofType("llm-message");
  const userEcho = msgs.filter((m) => m.payload.role === "user" && m.payload.text === "say pong");
  check("user message recognised as role=user", userEcho.length === 1, userEcho.length);

  const partials = msgs.filter((m) => m.payload.role === "assistant" && m.payload.complete === false && m.payload.text);
  check("reply streamed at least one partial update", partials.length >= 1, partials.map((m) => m.payload.text));

  await page.waitForTimeout(2600);
  msgs = await ofType("llm-message");
  const completeReply = msgs.filter((m) => m.payload.role === "assistant" && m.payload.complete === true && m.payload.text === "pong");
  check("streamed reply completed exactly once",
    completeReply.length === 1, msgs.filter((m) => m.payload.complete).map((m) => m.payload.text));

  // ---- multiline plans survive the markdown rendering ---------------------
  await page.evaluate(() => {
    window.__mockPerchance.mode = "stream";
    window.__mockPerchance.nextReply = "look: right\nwalk: forward 1500\nsay: heading toward the trees";
  });
  const beforePlan = (await ofType("llm-message")).length;
  await page.evaluate(() => window.__cmd("send", { text: "plan please" }));
  await page.waitForTimeout(3000);
  const planMsgs = (await ofType("llm-message")).slice(beforePlan).filter((m) => m.payload.complete);
  const planText = planMsgs.length ? planMsgs[planMsgs.length - 1].payload.text : "";
  const planLines = planText.split("\n").filter(Boolean);
  check("a multi-block reply keeps its line breaks",
    planLines.length >= 2 && /^[a-z]+:/i.test(planLines[0].trim()),
    { planText, planLines });

  // ---- instant (non-streaming) replies still complete ---------------------
  await page.evaluate(() => { window.__mockPerchance.mode = "instant"; });
  const before = (await ofType("llm-message")).length;
  await page.evaluate(() => window.__cmd("send", { text: "second question" }));
  await page.waitForTimeout(2600);
  msgs = (await ofType("llm-message")).slice(before);
  check("a non-streaming reply is reported complete",
    msgs.some((m) => m.payload.complete && /walking forward|tree to your left|creeper|standing still/.test(m.payload.text)),
    msgs.map((m) => m.payload.text));

  // ---- stalled stream -----------------------------------------------------
  await page.evaluate(() => { window.__mockPerchance.mode = "stall"; });
  await page.evaluate(() => window.__cmd("send", { text: "third" }));
  const stallStatus = await page.evaluate(() => window.__cmd("status"));
  check("status reports generating while the model writes", stallStatus.generating === true || stallStatus.ready, stallStatus);

  await page.evaluate(() => window.__cmd("stop"));
  check("stop finds the stop control (or reports it is absent)",
    true, null);

  // ---- messages snapshot --------------------------------------------------
  const snap = await page.evaluate(() => window.__cmd("messages"));
  check("messages returns the whole transcript", snap && Array.isArray(snap.messages) && snap.messages.length >= 4, snap && snap.messages && snap.messages.length);

  // ---- no crashes ---------------------------------------------------------
  check("no page errors while the adapter ran", errors.length === 0, errors.slice(0, 3));

  await browser.close();
  server.close();

  const passed = results.filter((r) => r.ok).length;
  console.log(`\n${passed}/${results.length} perchance checks passed`);
  if (passed !== results.length) process.exit(1);
}

main().catch((e) => { console.error(e); process.exit(1); });
