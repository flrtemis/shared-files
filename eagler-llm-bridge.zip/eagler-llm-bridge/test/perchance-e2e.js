/*
 * End-to-end: extension + bridge host + a Perchance-style chat tab.
 *
 * Loads the real unpacked extension, opens the mock chat page (which the
 * manifest's Perchance content script matches by origin — we serve it on
 * 127.0.0.1 and inject the adapter the same way chrome.scripting does), asks the
 * bridge host to send a message, and watches the reply arrive back over HTTP.
 *
 *   xvfb-run -a -s "-screen 0 1280x900x24" node test/perchance-e2e.js
 */
"use strict";
const fs = require("fs");
const http = require("http");
const path = require("path");
const { spawn } = require("child_process");
const { chromium } = require(path.join(__dirname, "..", "node_modules", "playwright-core"));

const ROOT = path.join(__dirname, "..");
const results = [];
const check = (n, ok, d) => { results.push({ n, ok: !!ok }); console.log((ok ? "  ✓ " : "  ✗ ") + n + (ok ? "" : "  -> " + JSON.stringify(d).slice(0, 240))); };

function get(u, method = "GET", body) {
  return new Promise((resolve) => {
    const data = body ? JSON.stringify(body) : null;
    const req = http.request(u, { method, timeout: 25000, headers: data ? { "content-type": "application/json", "content-length": Buffer.byteLength(data) } : {} }, (res) => {
      let b = ""; res.on("data", (c) => (b += c));
      res.on("end", () => { try { resolve(JSON.parse(b)); } catch (e) { resolve({ raw: b.slice(0, 200) }); } });
    });
    req.on("error", (e) => resolve({ error: e.message }));
    req.on("timeout", () => { req.destroy(); resolve({ error: "timeout" }); });
    if (data) req.write(data);
    req.end();
  });
}

(async () => {
  const bridge = spawn(process.execPath, [path.join(ROOT, "llm/ws-bridge.js")], { cwd: ROOT, stdio: "ignore" });
  await new Promise((r) => setTimeout(r, 900));

  const server = http.createServer((req, res) => {
    const u = req.url.split("?")[0];
    const map = {
      "/mock-perchance.html": path.join(__dirname, "fixtures/mock-perchance.html"),
      "/perchance-bridge.js": path.join(ROOT, "page/perchance-bridge.js")
    };
    if (u === "/favicon.ico") { res.writeHead(204); res.end(); return; }
    const f = map[u];
    if (!f) { res.writeHead(404); res.end(); return; }
    res.writeHead(200, { "content-type": u.endsWith(".html") ? "text/html" : "application/javascript" });
    fs.createReadStream(f).pipe(res);
  });
  await new Promise((r) => server.listen(0, "127.0.0.1", r));
  const port = server.address().port;

  const exe = process.env.CHROME_BIN || "/home/user/.cache/ms-playwright/chromium-1194/chrome-linux/chrome";
  const ctx = await chromium.launchPersistentContext("/tmp/pc-e2e-" + Date.now(), {
    executablePath: exe, headless: false,
    args: [
      "--no-sandbox",
      `--disable-extensions-except=${ROOT}`, `--load-extension=${ROOT}`,
      // The manifest matches *://*.perchance.org/*, so the mock must be served on
      // that hostname for the real content-script path to run. Map it to loopback.
      `--host-resolver-rules=MAP mock.perchance.org 127.0.0.1:${port}`
    ]
  });

  const page = await ctx.newPage();
  // The manifest's content script injects page/perchance-bridge.js at document_idle.
  await page.goto(`http://mock.perchance.org/mock-perchance.html`);
  await page.waitForTimeout(1500);

  // The adapter posts to chrome.runtime, so the extension must be listening.
  const health = await get("http://127.0.0.1:8787/health");
  check("bridge host running", health && health.ok === true, health);
  check("extension connected to the host", health && health.extension === true, health);

  // The LLM side
  const status = await get("http://127.0.0.1:8787/llm/status");
  check("host reports the LLM chat attached", status && status.ok === true, status);

  const ask = await get("http://127.0.0.1:8787/llm/ask", "POST", { text: "say pong", waitMs: 20000 });
  check("POST /llm/ask delivered the message", ask && ask.ok === true, ask);
  check("POST /llm/ask returned the AI reply", ask && !ask.timedOut && /pong/i.test(ask.text || ""), ask);

  const llm = await get("http://127.0.0.1:8787/llm?limit=5");
  check("GET /llm lists the replies", llm && llm.ok && (llm.replies || []).length > 0, llm);

  await ctx.close();
  bridge.kill();
  server.close();

  const passed = results.filter((r) => r.ok).length;
  console.log(`\n${passed}/${results.length} perchance e2e checks passed`);
  process.exit(passed === results.length ? 0 : 1);
})();
