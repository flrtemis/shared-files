/*
 * Eagler LLM Bridge — offscreen audio document.
 *
 * `chrome.tabCapture.getMediaStreamId` must be called from an extension page
 * with DOM access. This hidden document does exactly that, then hands the
 * stream id back to the service worker, which does the actual recording via
 * navigator.mediaDevices.getUserMedia({audio: {mandatory: {...}}}).
 *
 * Nothing here reaches the network. The bridge records at most a few seconds
 * per interval and only when "Audio transcription" is enabled by the user.
 */
(async () => {
  "use strict";

  const ext = chrome;

  function reply(msg) {
    try { ext.runtime.sendMessage(Object.assign({ kind: "eagler-bridge-offscreen" }, msg)); } catch (e) { /* worker asleep */ }
  }

  ext.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!msg || msg.kind !== "eagler-bridge-offscreen-req") return;

    if (msg.type === "capture-stream-id") {
      try {
        const streamId = ext.tabCapture.getMediaStreamId({ targetTabId: msg.tabId }, () => {});
        // Chrome returns the id synchronously in MV3 when targetTabId is given
        sendResponse({ ok: true, streamId });
      } catch (e) {
        sendResponse({ ok: false, error: String(e && e.message || e) });
      }
      return;
    }

    if (msg.type === "record") {
      // Record a short window and return PCM/duration so the worker can feed
      // it to the Web Speech API (worker has speechSynthesis+recognition? no —
      // recognition lives in this document, which is why we do it here).
      recordWindow(msg.tabId, msg.ms || 4000).then((r) => sendResponse(r)).catch((e) => sendResponse({ ok: false, error: String(e) }));
      return true;
    }

    if (msg.type === "status") {
      sendResponse({ ok: true, ready: true });
      return;
    }
    sendResponse({ ok: false, error: "unknown" });
  });

  // ---------------------------------------------------------------------------
  // Speech recognition (best-effort; Chrome's implementation is server-backed,
  // so the results are labelled "unverified" in the bridge state)
  // ---------------------------------------------------------------------------
  let recognizer = null;

  function startRecognition() {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) return null;
    const rec = new SR();
    rec.continuous = true;
    rec.interimResults = false;
    rec.lang = "en-US";
    rec.onresult = (ev) => {
      for (let i = ev.resultIndex; i < ev.results.length; i++) {
        if (ev.results[i].isFinal) {
          reply({ type: "transcript", text: ev.results[i][0].transcript.trim(), confidence: "unverified" });
        }
      }
    };
    rec.onerror = (e) => reply({ type: "speech-error", error: e.error || String(e) });
    rec.onend = () => {
      // Restart unless stopped
      if (recognizer === rec && !rec.__stopped) {
        try { rec.start(); } catch (e) { /* ignore */ }
      }
    };
    try { rec.start(); } catch (e) { return null; }
    return rec;
  }

  async function recordWindow(tabId, ms) {
    // 1) Ask tabCapture for a stream id
    const streamId = await new Promise((resolve, reject) => {
      try {
        ext.tabCapture.getMediaStreamId({ targetTabId: tabId }, (id) => {
          if (ext.runtime.lastError) reject(new Error(ext.runtime.lastError.message));
          else resolve(id);
        });
      } catch (e) { reject(e); }
    });

    // 2) Open it as a stream and keep the audio graph alive, muted to the user
    const stream = await navigator.mediaDevices.getUserMedia({
      audio: { mandatory: { chromeMediaSource: "tab", chromeMediaSourceId: streamId } },
      video: false
    });

    const ctx = new AudioContext();
    const src = ctx.createMediaStreamSource(stream);
    const analyser = ctx.createAnalyser();
    analyser.fftSize = 2048;
    src.connect(analyser);

    // 3) While recording, kick the speech recognizer (it hears the page's
    //    output because the offscreen doc is the tab's capture sink only if
    //    we route it — instead we use a MediaStream track on a hidden element)
    const audioEl = document.createElement("audio");
    audioEl.srcObject = stream;
    audioEl.muted = true;
    await audioEl.play().catch(() => {});

    if (!recognizer) recognizer = startRecognition();

    const start = performance.now();
    const levels = [];
    while (performance.now() - start < ms) {
      const buf = new Uint8Array(analyser.frequencyBinCount);
      analyser.getByteFrequencyData(buf);
      let sum = 0;
      for (let i = 0; i < buf.length; i++) sum += buf[i] * buf[i];
      levels.push(Math.sqrt(sum / buf.length));
      await new Promise((r) => setTimeout(r, 100));
    }
    const peak = Math.max.apply(null, levels.map((v) => v || 0));
    const rms = Math.sqrt(levels.reduce((a, v) => a + v * v, 0) / Math.max(1, levels.length));

    // Keep the recognizer running if the caller wants continuous transcription;
    // otherwise tear the capture down so the tab's tab-share indicator clears.
    if (!window.__eaglerKeepRecording) {
      stream.getTracks().forEach((t) => t.stop());
      ctx.close().catch(() => {});
      if (recognizer) { recognizer.__stopped = true; try { recognizer.stop(); } catch (e) {} recognizer = null; }
      audioEl.srcObject = null;
    }

    return { ok: true, ms, rms: Math.round(rms * 1000) / 1000, peak: Math.round(peak), speaking: rms > 4 };
  }

  reply({ type: "offscreen-ready" });
})();
