/*
 * Eagler LLM Bridge — content script (ISOLATED world) on nite.games.
 *
 * Responsibilities:
 *  - inject page/v1_8_parser.js + page/page-bridge.js into the TOP page in the
 *    MAIN world (before the React app mounts), and into the game frame via
 *    chrome.scripting (that frame is gnhustgames.org, a different origin — this
 *    is the CORS-adjacent part of the brief: host_permissions let us script it);
 *  - relay messages between the background service worker and each page agent,
 *    stamping every command with a per-frame secret token so page scripts
 *    cannot forge commands;
 *  - forward state pushes and canvas frames to the worker.
 */
(() => {
  "use strict";
  if (window.__EAGLER_LLM_BRIDGE_CONTENT__) return;
  window.__EAGLER_LLM_BRIDGE_CONTENT__ = true;

  // crypto.randomUUID only exists in secure contexts; a game served over plain
  // http (a LAN embed, a dev server) would otherwise kill this script on load.
  function makeToken() {
    try {
      if (crypto && crypto.randomUUID) return crypto.randomUUID();
    } catch (e) { /* not a secure context */ }
    const b = new Uint8Array(16);
    try { crypto.getRandomValues(b); } catch (e) { for (let i = 0; i < 16; i++) b[i] = (Math.random() * 256) | 0; }
    return Array.from(b, (x) => x.toString(16).padStart(2, "0")).join("");
  }
  const TOKEN = makeToken();
  const GAME_FRAME_RE = /gnhustgames\.org$/i;
  // Substrings that identify the game iframe among the page's (often ad-laden)
  // iframes. Keep it as data so findGameFrame can stay a cheap string scan.
  const FRAME_HINTS = ["eaglercraft", "minecraft", "gnhustgames", "nite.games/embed"];
  const agents = new Set();            // windows that introduced themselves
  const gameAgents = new Set();        // subset: the actual game frame(s)
  const frameKeys = new WeakMap();
  let frameSeq = 0;
  let lastAsked = 0;                   // throttle for inject-frames requests

  const ext = (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.id) ? chrome : null;

  function sendToWorker(type, payload) {
    if (!ext) return;
    try {
      const p = ext.runtime.sendMessage({ kind: "eagler-bridge", type, payload });
      if (p && p.catch) p.catch(() => {});
    } catch (e) { /* worker asleep */ }
  }

  function frameKeyOf(win) {
    if (!frameKeys.has(win)) frameKeys.set(win, "f" + (++frameSeq));
    return frameKeys.get(win);
  }

  // ---------------------------------------------------------------------------
  // Token delivery: the MAIN-world agent listens for this exact envelope.
  // ---------------------------------------------------------------------------
  function sendToken(win) {
    try {
      win.postMessage({ source: "eagler-llm-bridge-content", type: "token", token: TOKEN }, "*");
    } catch (e) { /* ignore */ }
  }

  // ---------------------------------------------------------------------------
  // Frame discovery: the game frame is a different origin, so injection is
  // performed by the service worker (chrome.scripting); here we only detect
  // when the iframe appears or reloads and ask for a fresh injection.
  // ---------------------------------------------------------------------------
  function findGameFrame() {
    const frames = Array.from(document.querySelectorAll("iframe"));
    for (const f of frames) {
      const src = (f.getAttribute("src") || "").toLowerCase();
      if (FRAME_HINTS.some((h) => src.includes(h))) return f;
    }
    let best = null, area = 0;
    for (const f of frames) {
      const r = f.getBoundingClientRect();
      const src = (f.getAttribute("src") || "").toLowerCase();
      if (/google|doubleclick|googletag|adsystem/.test(src)) continue;
      const a = r.width * r.height;
      if (a > area) { area = a; best = f; }
    }
    return best;
  }

  function syncFrames(force) {
    const f = findGameFrame();
    if (!f) return;
    const now = Date.now();
    if (!force && now - lastAsked < 2000) return;
    lastAsked = now;
    // The worker owns chrome.scripting for the frame; it has the tabId.
    sendToWorker("inject-frames", { src: f.getAttribute("src") || "" });
    // The frame agent only hears its own window; the worker injects a relay
    // that passes the token, but we also post it to our own top-page agent.
    sendToken(window);
    try {
      if (f.contentWindow) sendToken(f.contentWindow);
    } catch (e) { /* cross-origin: worker path handles it */ }
  }

  // ---------------------------------------------------------------------------
  // MAIN world <-> worker bridge
  // ---------------------------------------------------------------------------
  const GAME_FRAME_TYPES = new Set([
    "state:chat", "state:handshake", "state:connect", "state:socket_open",
    "state:disconnect", "state:socket_error", "state:game", "state:hud",
    "state:pos", "state:score", "state:move", "state:chat_sent", "state:injected",
    "sniffer:ready", "mirror:open", "mirror:ready", "mirror:closed", "mirror:error",
    "mirror:send_result", "mirror:frame", "packet", "frame", "frame:auto", "transcript"
  ]);

  window.addEventListener("message", (ev) => {
    const msg = ev.data;
    if (!msg || msg.source !== "eagler-llm-bridge-page") return;
    const payload = msg.payload || {};
    const frameKey = frameKeyOf(ev.source);
    const isTop = ev.source === window;

    switch (msg.type) {
      case "hello":
        agents.add(ev.source);
        if (payload.frame === true) gameAgents.add(ev.source);
        sendToWorker("page-hello", { frameKey, top: isTop, url: payload.url, hasParser: payload.hasParser, frame: payload.frame });
        return;

      case "result":
      case "status_result":
        if (payload && payload.id) acked.add(payload.id);
        sendToWorker("page-result", Object.assign({ frameKey }, payload));
        return;

      case "snapshot":
      case "changes":
        sendToWorker("page-result", Object.assign({ frameKey }, payload));
        return;

      case "frame":
        // Capture replies carry {ok,dataUrl,width,height}; commands.js reads the
        // same object back through the pending-result path.
        sendToWorker("page-frame", { frameKey, frame: payload.raw || payload, captureId: payload.id });
        return;

      case "frame:auto":
        sendToWorker("page-frame", { frameKey, frame: payload });
        return;

      default:
        if (GAME_FRAME_TYPES.has(msg.type) || msg.type.indexOf("state:") === 0) {
          sendToWorker("page-event", { frameKey, type: msg.type, payload });
        } else {
          sendToWorker("page-event", { frameKey, type: msg.type, payload });
        }
    }
  });

  // Command ids that have produced an agent reply: stops the relay retry loop.
  const acked = new Set();

  // Commands from the worker -> the right frame agent.
  // Execution commands go to the game frame only; token/config broadcasts go to
  // every agent (the top page hosts a relay-only agent).
  const BROADCAST_TYPES = new Set(["token", "set_config"]);

  function relay(msg) {
    const { type, payload, frameKey } = msg;
    let targets;
    if (BROADCAST_TYPES.has(type)) {
      targets = Array.from(agents);
    } else {
      targets = Array.from(gameAgents.size ? gameAgents : agents);
    }
    let delivered = 0;
    for (const src of targets) {
      if (frameKey && frameKeyOf(src) !== frameKey) continue;
      try {
        src.postMessage({ source: "eagler-llm-bridge-content", type, token: TOKEN, payload }, "*");
        delivered++;
      } catch (e) { /* ignore */ }
    }
    return delivered;
  }

  if (ext) {
    ext.runtime.onMessage.addListener((msg, sender, sendResponse) => {
      if (!msg || msg.kind !== "eagler-bridge-to-page") return;

      if (msg.type === "ping") {
        sendResponse({ ok: true, agents: agents.size, token: TOKEN, url: location.href });
        return;
      }
      if (msg.type === "token") {
        sendToken(window);
        sendResponse({ ok: true, token: TOKEN });
        return;
      }
      if (msg.type === "relay") {
        const payload = msg.payload || {};
        const delivered = relay(payload);
        sendResponse({ ok: delivered > 0, delivered });
        if (delivered > 0) return;

        // Retry until an agent answers, not merely until one is listening: an
        // agent can be present and still refuse (no token yet, wrong phase, not
        // the game frame), and at boot the agent is injected a moment *after*
        // the token, so the first relay often lands on a page with no listener.
        let tries = 0;
        const t = setInterval(() => {
          if (++tries > 8) return clearInterval(t);
          if (acked) return clearInterval(t);
          if (relay(payload) > 0 && tries <= 1) {
            sendToWorker("relay-late", { type: payload.type });
          }
        }, 500);
        return;
      }
      if (msg.type === "dom-snapshot") {
        sendResponse({ ok: true, html: (document.body ? document.body.innerHTML : "").slice(0, 20000) });
        return;
      }
      sendResponse({ ok: false, error: "unknown" });
    });
  }

  // ---------------------------------------------------------------------------
  // Top-page MAIN-world injection (runs at document_start)
  // ---------------------------------------------------------------------------
  function injectTopPage() {
    if (!ext) return;
    try {
      const doc = document;
      if (!doc.documentElement) return;
      const parser = doc.createElement("script");
      parser.src = ext.runtime.getURL("page/v1_8_parser.js");
      const agent = doc.createElement("script");
      agent.src = ext.runtime.getURL("page/page-bridge.js");
      const parent = doc.head || doc.documentElement;
      parent.insertBefore(agent, parent.firstChild);
      parent.insertBefore(parser, agent);
    } catch (e) { /* ignore */ }
  }

  injectTopPage();
  sendToken(window);
  sendToWorker("content-ready", { url: location.href });
  setTimeout(() => syncFrames(true), 300);
  setInterval(() => syncFrames(false), 2000);
  try {
    new MutationObserver((records) => {
      // Only a frame appearing matters. Reacting to every mutation fed a loop:
      // the injected <script> tags are themselves mutations, so each injection
      // triggered another one. Ignore script-only changes and keep the 2 s
      // ceiling from doing the actual pacing.
      for (const r of records) {
        for (const n of r.addedNodes) {
          if (n && n.tagName === "IFRAME") return syncFrames(false);
        }
      }
    }).observe(document.documentElement, { childList: true, subtree: true });
  } catch (e) { /* ignore */ }
})();
