// Runs at document_start in every GAME frame only (manifest: all_frames on the
// game hosts). Two jobs:
//   1) put the agent in place before the client opens its WebSocket, so the
//      hook sees the connect; late injection can never replay it
//   2) forward the frame agent's messages to the top document, where the single
//      content script relays them to the worker (a middle wrapper frame has no
//      content script at all, and chrome.runtime is not available in MAIN world)
(() => {
  "use strict";
  const ext = (() => { try { return chrome.runtime; } catch (e) { return null; } })();
  if (!ext || !ext.getURL) return;

  const doc = document;
  function inject() {
    try {
      const parent = doc.head || doc.documentElement;
      if (!parent) return;
      if (doc.querySelector('script[data-eagler-frame-boot]')) return;
      const parser = doc.createElement("script");
      parser.src = ext.getURL("page/v1_8_parser.js");
      parser.dataset.eaglerFrameBoot = "1";
      const agent = doc.createElement("script");
      agent.src = ext.getURL("page/page-bridge.js");
      agent.dataset.eaglerFrameBoot = "1";
      parent.insertBefore(parser, parent.firstChild);
      parent.insertBefore(agent, parser.nextSibling);
    } catch (e) { /* ignore */ }
  }
  inject();

  // Pass the token on as soon as it arrives from the worker (the top-frame
  // content script cannot reach this frame when the hosts differ).
  window.addEventListener("message", (ev) => {
    const m = ev.data;
    if (!m || m.source !== "eagler-llm-bridge-content" || m.type !== "token") return;
    if (!m.viaExtension) return;
    window.postMessage(m, "*");
  });
})();
