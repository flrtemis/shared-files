/* Eagler LLM Bridge — options page. */
(() => {
  "use strict";
  const $ = (id) => document.getElementById(id);
  const FIELDS = ["host", "autoConnect", "autoAttach", "captureFps", "captureWidth", "pushEvents", "allowInject", "allowMirror"];

  function load() {
    chrome.storage.local.get("settings").then((got) => {
      const s = got.settings || {};
      const defaults = { host: "127.0.0.1:8787", autoConnect: true, autoAttach: true, captureFps: 0.5, captureWidth: 480, pushEvents: true, allowInject: false, allowMirror: false };
      const merged = { ...defaults, ...s };
      $("host").value = merged.host;
      $("autoConnect").checked = !!merged.autoConnect;
      $("autoAttach").checked = !!merged.autoAttach;
      $("captureFps").value = merged.captureFps;
      $("captureWidth").value = merged.captureWidth;
      $("pushEvents").checked = merged.pushEvents !== false;
      $("allowInject").checked = !!merged.allowInject;
      $("allowMirror").checked = !!merged.allowMirror;
    });
  }

  async function save() {
    const patch = {
      host: $("host").value.trim() || "127.0.0.1:8787",
      autoConnect: $("autoConnect").checked,
      autoAttach: $("autoAttach").checked,
      captureFps: Math.max(0.2, Math.min(5, parseFloat($("captureFps").value) || 0.5)),
      captureWidth: Math.max(160, Math.min(1280, parseInt($("captureWidth").value, 10) || 480)),
      pushEvents: $("pushEvents").checked,
      allowInject: $("allowInject").checked,
      allowMirror: $("allowMirror").checked
    };
    chrome.runtime.sendMessage({ kind: "eagler-bridge-ui-req", type: "set_settings", patch }, () => {});
    // Push capture/privileged config down to the live page agent
    chrome.tabs.query({}, (tabs) => {
      for (const t of tabs) {
        if (/nite\.games/.test(t.url || "")) {
          chrome.tabs.sendMessage(t.id, {
            kind: "eagler-bridge-to-page",
            type: "relay",
            payload: {
              type: "set_config",
              payload: { id: "opt", config: { captureFps: patch.captureFps, captureWidth: patch.captureWidth, allowInject: patch.allowInject, allowMirror: patch.allowMirror } }
            }
          }).catch(() => {});
        }
      }
    });
    const saved = $("saved");
    saved.classList.add("show");
    setTimeout(() => saved.classList.remove("show"), 1200);
  }

  FIELDS.forEach((f) => {
    const el = $(f);
    if (!el) return;
    el.addEventListener("change", save);
  });

  $("test").addEventListener("click", () => {
    $("test").disabled = true;
    $("test").textContent = "Testing…";
    chrome.runtime.sendMessage({ kind: "eagler-bridge-ui-req", type: "self_test" }, (r) => {
      $("test").disabled = false;
      $("test").textContent = "Run self-test";
      const out = $("out");
      out.style.display = "block";
      out.textContent = r ? JSON.stringify(r, null, 2) : "no response (is a nite.games tab open?)";
    });
  });

  load();
})();
