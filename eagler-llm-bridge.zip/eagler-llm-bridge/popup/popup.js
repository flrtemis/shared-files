/* Eagler LLM Bridge — popup UI. Talks only to the extension's own worker. */
(() => {
  "use strict";

  const $ = (id) => document.getElementById(id);
  const dot = $("dot");

  function uiReq(type, extra) {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ kind: "eagler-bridge-ui-req", type, ...(extra || {}) }, (res) => resolve(res || { ok: false, error: "no response" }));
    });
  }

  function fmt(n, d) {
    return typeof n === "number" ? (Math.round(n * Math.pow(10, d || 1)) / Math.pow(10, d || 1)) : n;
  }

  async function refresh() {
    const s = await uiReq("get_state");
    if (!s.ok) { $("out").style.display = "block"; $("out").textContent = s.error || "state error"; return; }

    $("ver").textContent = "v" + (chrome.runtime.getManifest().version || "");
    $("vi").textContent = chrome.runtime.getManifest().version || "";

    $("sock").textContent = s.connected ? "connected" : "offline";
    $("toggle").textContent = s.connected ? "Disconnect" : "Connect";
    dot.className = "dot " + (s.connected ? "on" : "err");

    const st = s.store || {};
    $("agent").textContent = (st.agents && st.agents.length) ? st.agents.length + " agent(s)" : "not loaded";
    $("conn").textContent = st.connected ? "in game" : (st.handshakeDone ? "play" : "idle");
    $("conn").className = "v " + (st.connected ? "" : "muted");
    $("fps").textContent = st.capture && st.capture.lastAt ? (st.capture.fps || 0) + "/s" : "none";
    $("vitals").textContent = st.hud && (st.hud.health != null || st.hud.food != null)
      ? `${fmt(st.hud.health, 0)} ❤ / ${st.hud.food ?? "?"} 🍗`
      : "—";
    $("user").textContent = st.username || "—";

    const tabInfo = await chrome.tabs.query({ active: true, currentWindow: true });
    const t = tabInfo && tabInfo[0];
    $("tab").textContent = t && /nite\.games/.test(t.url || "") ? "active" : "not on nite.games";

    // Chat tail
    if (st.chat && st.chat.length) {
      const rows = st.chat.slice(-14).map((c) => {
        const who = c.from ? `<span class="who">${escapeHtml(c.from)}</span>` : `<span class="muted">${c.kind || "sys"}</span>`;
        return `<div>${who}${c.from ? ": " : " "}${escapeHtml(c.text || "")}</div>`;
      });
      $("chat").innerHTML = rows.join("");
      $("chat").scrollTop = $("chat").scrollHeight;
    }
  }

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }

  $("toggle").addEventListener("click", async () => {
    const s = await uiReq("get_state");
    await uiReq(s.connected ? "disconnect" : "connect");
    $("toggle").disabled = true;
    setTimeout(() => { $("toggle").disabled = false; refresh(); }, 700);
    refresh();
  });

  $("attach").addEventListener("click", async () => {
    $("attach").disabled = true;
    $("attach").textContent = "…";
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    const r = await uiReq("attach", { tabId: tabs && tabs[0] ? tabs[0].id : null });
    $("attach").disabled = false;
    $("attach").textContent = "Attach";
    showOut(r);
    refresh();
  });

  $("test").addEventListener("click", async () => {
    $("test").disabled = true;
    $("test").textContent = "Testing…";
    const r = await uiReq("self_test");
    $("test").disabled = false;
    $("test").textContent = "Run self-test";
    showOut(r);
    refresh();
  });

  $("shot").addEventListener("click", async () => {
    const r = await uiReq("snapshot");
    const data = r && r.snapshot && r.snapshot.frame;
    showOut({ ok: !!data, note: data ? "captured" : "no frame yet — wait for the game to render", frame: data ? "(see preview below)" : null });
    if (data && data.dataUrl) {
      let img = document.getElementById("preview");
      if (!img) {
        img = document.createElement("img");
        img.id = "preview";
        img.style.cssText = "width:100%;border-radius:8px;margin-top:10px;border:1px solid #1d2637";
        document.body.appendChild(img);
      }
      img.src = data.dataUrl;
    }
  });

  function showOut(obj) {
    const out = $("out");
    out.style.display = "block";
    out.textContent = JSON.stringify(obj, null, 2).slice(0, 4000);
  }

  $("opts").addEventListener("click", (e) => { e.preventDefault(); chrome.runtime.openOptionsPage(); });
  $("host").addEventListener("click", (e) => {
    e.preventDefault();
    chrome.tabs.create({ url: "http://127.0.0.1:8787/" });
  });

  refresh();
  setInterval(refresh, 1200);
})();
